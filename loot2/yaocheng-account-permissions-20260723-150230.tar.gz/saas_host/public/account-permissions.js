(function(global){
'use strict';

var ROOT_ID='yaochengAccountPermissions';
var MODULE_LABELS={day1:'单日大研学',multiday:'多日大研学',dispatch:'派车宝'};
var ROLE_LABELS={tenant_admin:'客户超级管理员',day1_admin:'单日模块管理员',user:'业务操作员',viewer:'查看人员'};
var ROLE_HELP={tenant_admin:'管理本单位账号和全部已开通模块',day1_admin:'默认管理单日大研学',user:'默认可录入和维护业务资料',viewer:'默认只查看数据'};
var ACCESS_LABELS={manager:'管理',editor:'编辑',viewer:'查看',none:'无权限'};
var manager=null;

function escapeHtml(value){return String(value==null?'':value).replace(/[&<>"']/g,function(ch){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch];});}
function roleLabel(role){return ROLE_LABELS[role]||role||'-';}
function roleHelp(role){return ROLE_HELP[role]||'';}
function accessOptions(selected,disabled){return Object.keys(ACCESS_LABELS).map(function(key){return '<option value="'+key+'"'+(key===selected?' selected':'')+'>'+ACCESS_LABELS[key]+'</option>';}).join('');}
function defaultAccess(role,moduleKey){
  if(role==='tenant_admin')return 'manager';
  if(role==='day1_admin')return moduleKey==='day1'?'manager':'none';
  if(role==='viewer')return 'viewer';
  return 'editor';
}
function ensureStyles(){
  if(document.getElementById('yaochengAccountPermissionsStyles'))return;
  var style=document.createElement('style');style.id='yaochengAccountPermissionsStyles';style.textContent='\
#'+ROOT_ID+'[hidden]{display:none!important}#'+ROOT_ID+'{position:fixed;inset:0;z-index:2200;display:flex;align-items:center;justify-content:center;padding:18px;background:rgba(1,14,28,.72);box-sizing:border-box}#'+ROOT_ID+' *{box-sizing:border-box}#'+ROOT_ID+' .yc-ap-dialog{width:min(1120px,100%);max-height:min(88vh,900px);overflow:auto;border:1px solid #cbd9e5;border-radius:18px;background:#f7fafc;color:#203248;box-shadow:0 28px 90px rgba(0,8,20,.42)}#'+ROOT_ID+' .yc-ap-head{position:sticky;top:0;z-index:2;display:flex;align-items:flex-start;justify-content:space-between;gap:16px;padding:20px 22px;border-bottom:1px solid #dbe5ee;background:#fff}#'+ROOT_ID+' h2,#'+ROOT_ID+' h3{margin:0}#'+ROOT_ID+' .yc-ap-head p{margin:6px 0 0;color:#64748b;font-size:13px}#'+ROOT_ID+' button{min-height:36px;border:1px solid #cbd9e5;border-radius:9px;background:#fff;color:#24364d;padding:7px 12px;font-weight:700;cursor:pointer}#'+ROOT_ID+' button:hover{border-color:#13a8a3}#'+ROOT_ID+' button:disabled{cursor:not-allowed;opacity:.55}#'+ROOT_ID+' .yc-ap-primary{border-color:#07978f;background:#07978f;color:#fff}#'+ROOT_ID+' .yc-ap-danger{border-color:#efc3c3;color:#c93d43}#'+ROOT_ID+' .yc-ap-body{padding:18px 22px 24px}#'+ROOT_ID+' .yc-ap-note{margin-bottom:14px;padding:11px 13px;border:1px solid #cfe3e2;border-radius:10px;background:#edf8f7;color:#345b60;font-size:12px;line-height:1.65}#'+ROOT_ID+' .yc-ap-section{margin-top:14px;padding:16px;border:1px solid #dbe5ee;border-radius:13px;background:#fff}#'+ROOT_ID+' .yc-ap-section-title{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px}#'+ROOT_ID+' .yc-ap-grid{display:grid;grid-template-columns:1fr 1fr 1.15fr;gap:10px}#'+ROOT_ID+' label{display:grid;gap:5px;color:#5a6c80;font-size:11px;font-weight:800}#'+ROOT_ID+' input,#'+ROOT_ID+' select{width:100%;min-height:38px;border:1px solid #cbd9e5;border-radius:8px;background:#fff;color:#203248;padding:7px 9px;font:inherit}#'+ROOT_ID+' input:focus,#'+ROOT_ID+' select:focus{outline:2px solid rgba(19,184,178,.2);border-color:#07978f}#'+ROOT_ID+' .yc-ap-new-modules{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:9px;margin-top:10px}#'+ROOT_ID+' .yc-ap-form-actions{display:flex;justify-content:flex-end;margin-top:12px}#'+ROOT_ID+' .yc-ap-summary{color:#64748b;font-size:12px}#'+ROOT_ID+' .yc-ap-table-wrap{overflow:auto}#'+ROOT_ID+' table{width:100%;border-collapse:collapse;font-size:12px}#'+ROOT_ID+' th,#'+ROOT_ID+' td{padding:10px 8px;border-bottom:1px solid #e5ebf2;text-align:left;vertical-align:middle;white-space:nowrap}#'+ROOT_ID+' th{color:#607287;background:#f7fafc;font-size:11px}#'+ROOT_ID+' td select{min-width:92px;min-height:34px}#'+ROOT_ID+' .yc-ap-role small{display:block;margin-top:3px;color:#7b8999;font-size:10px}#'+ROOT_ID+' .yc-ap-actions{display:flex;gap:6px}#'+ROOT_ID+' .yc-ap-status{display:inline-flex;border-radius:999px;padding:4px 8px;background:#eaf7f1;color:#287b58;font-weight:800}#'+ROOT_ID+' .yc-ap-status.off{background:#f5f1f1;color:#8a6262}#'+ROOT_ID+' .yc-ap-empty{padding:24px;text-align:center;color:#7b8999}#'+ROOT_ID+' .yc-ap-error{display:none;margin-bottom:12px;padding:9px 11px;border:1px solid #fecaca;border-radius:9px;background:#fff1f2;color:#b42318;font-size:12px}#'+ROOT_ID+' .yc-ap-reset{display:none;margin-top:14px;padding:14px;border:1px solid #d7e3ee;border-radius:11px;background:#f8fbfd}#'+ROOT_ID+' .yc-ap-reset.show{display:block}#'+ROOT_ID+' .yc-ap-reset-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px}#'+ROOT_ID+' .yc-ap-reset-actions{display:flex;justify-content:flex-end;gap:7px;margin-top:10px}@media(max-width:760px){#'+ROOT_ID+'{padding:8px;align-items:flex-end}#'+ROOT_ID+' .yc-ap-dialog{max-height:94vh;border-radius:16px 16px 0 0}#'+ROOT_ID+' .yc-ap-head,#'+ROOT_ID+' .yc-ap-body{padding:15px}#'+ROOT_ID+' .yc-ap-grid,#'+ROOT_ID+' .yc-ap-new-modules,#'+ROOT_ID+' .yc-ap-reset-grid{grid-template-columns:1fr}#'+ROOT_ID+' th,#'+ROOT_ID+' td{padding:8px 6px}#'+ROOT_ID+' .yc-ap-actions{flex-direction:column}}';
  document.head.appendChild(style);
}
function ensureShell(){
  var root=document.getElementById(ROOT_ID);if(root)return root;
  root=document.createElement('div');root.id=ROOT_ID;root.hidden=true;root.innerHTML='\
  <div class="yc-ap-dialog" role="dialog" aria-modal="true" aria-labelledby="ycApTitle">\
    <div class="yc-ap-head"><div><h2 id="ycApTitle">账号与权限</h2><p>管理本单位员工账号，并按模块分配管理、编辑、查看或无权限。</p></div><button type="button" data-yc-ap-close aria-label="关闭账号与权限">关闭</button></div>\
    <div class="yc-ap-body">\
      <div class="yc-ap-error" id="ycApError" role="alert"></div>\
      <div class="yc-ap-note"><b>使用建议：</b>负责人使用客户超级管理员；项目经理按模块设置管理权限；计调使用编辑权限；领导或财务可设置查看权限。员工离职后直接停用账号，无需多人共用管理员密码。</div>\
      <section class="yc-ap-section"><div class="yc-ap-section-title"><h3>新增账号</h3><span class="yc-ap-summary">账号数量受客户授权名额限制</span></div>\
        <div class="yc-ap-grid"><label>账号<input id="ycApNewUsername" autocomplete="off" placeholder="例如：jiediao01"></label><label>初始密码<input id="ycApNewPassword" type="password" autocomplete="new-password" placeholder="至少 6 位"></label><label>基础身份<select id="ycApNewRole"><option value="user">业务操作员</option><option value="viewer">查看人员</option><option value="day1_admin">单日模块管理员</option><option value="tenant_admin">客户超级管理员</option></select></label></div>\
        <div class="yc-ap-new-modules" id="ycApNewModules"></div><div class="yc-ap-form-actions"><button type="button" class="yc-ap-primary" id="ycApCreate">新增账号</button></div>\
      </section>\
      <section class="yc-ap-section"><div class="yc-ap-section-title"><h3>员工列表</h3><span class="yc-ap-summary" id="ycApSummary">正在读取…</span></div><div class="yc-ap-table-wrap" id="ycApUserList"><div class="yc-ap-empty">正在读取账号…</div></div>\
        <div class="yc-ap-reset" id="ycApReset"><b>重置密码：<span id="ycApResetName"></span></b><div class="yc-ap-reset-grid"><label>新密码<input id="ycApResetPassword" type="password" autocomplete="new-password" placeholder="至少 6 位"></label><label>确认新密码<input id="ycApResetConfirm" type="password" autocomplete="new-password" placeholder="再次输入"></label></div><div class="yc-ap-reset-actions"><button type="button" id="ycApResetCancel">取消</button><button type="button" class="yc-ap-primary" id="ycApResetSave">确认重置</button></div></div>\
      </section>\
    </div>\
  </div>';
  document.body.appendChild(root);return root;
}

function AccountPermissions(options){
  this.update(options);ensureStyles();this.root=ensureShell();this.users=[];this.modules=[];this.userRoles={};this.resetUserId=0;this.busy=false;this.bind();this.applyTriggerVisibility();
}
AccountPermissions.prototype.update=function(options){options=options||{};this.api=options.api||this.api;this.currentUser=options.currentUser||this.currentUser;this.toast=options.toast||this.toast||function(){};this.trigger=typeof options.trigger==='string'?document.querySelector(options.trigger):options.trigger||this.trigger;this.applyTriggerVisibility();};
AccountPermissions.prototype.isAdmin=function(){return !!(this.currentUser&&this.currentUser.role==='tenant_admin');};
AccountPermissions.prototype.applyTriggerVisibility=function(){if(!this.trigger)return;var visible=this.isAdmin();this.trigger.hidden=!visible;this.trigger.setAttribute('aria-hidden',visible?'false':'true');};
AccountPermissions.prototype.bind=function(){
  var self=this;if(this.root.dataset.bound)return;this.root.dataset.bound='1';
  this.root.addEventListener('click',function(event){
    if(event.target===self.root||event.target.closest('[data-yc-ap-close]')){self.close();return;}
    var save=event.target.closest('[data-yc-ap-save]');if(save){self.saveRoles(Number(save.dataset.ycApSave));return;}
    var reset=event.target.closest('[data-yc-ap-reset]');if(reset){self.openReset(Number(reset.dataset.ycApReset));return;}
    var toggle=event.target.closest('[data-yc-ap-toggle]');if(toggle){self.toggleUser(Number(toggle.dataset.ycApToggle),toggle.dataset.active==='1');}
  });
  document.getElementById('ycApCreate').addEventListener('click',function(){self.createUser();});
  document.getElementById('ycApNewRole').addEventListener('change',function(){self.applyNewRoleDefaults();});
  document.getElementById('ycApResetCancel').addEventListener('click',function(){self.closeReset();});
  document.getElementById('ycApResetSave').addEventListener('click',function(){self.submitReset();});
  document.addEventListener('keydown',function(event){if(event.key==='Escape'&&!self.root.hidden){if(document.getElementById('ycApReset').classList.contains('show'))self.closeReset();else self.close();}});
};
AccountPermissions.prototype.setError=function(message){var box=document.getElementById('ycApError');box.textContent=message||'';box.style.display=message?'block':'none';};
AccountPermissions.prototype.notify=function(message,isError){try{this.toast(message,!!isError);}catch(error){}if(isError)this.setError(message);};
AccountPermissions.prototype.open=function(){if(!this.isAdmin())return false;this.previousFocus=document.activeElement;this.root.hidden=false;this.setError('');this.closeReset();this.load();setTimeout(function(){var close=document.querySelector('#'+ROOT_ID+' [data-yc-ap-close]');if(close)close.focus();},0);return true;};
AccountPermissions.prototype.close=function(){this.root.hidden=true;this.closeReset();this.setError('');if(this.previousFocus&&typeof this.previousFocus.focus==='function')this.previousFocus.focus();};
AccountPermissions.prototype.load=async function(){
  if(this.busy)return;this.busy=true;document.getElementById('ycApSummary').textContent='正在读取…';document.getElementById('ycApUserList').innerHTML='<div class="yc-ap-empty">正在读取账号…</div>';
  try{
    var result=await Promise.all([this.api('/api/users'),this.api('/api/modules')]);this.users=result[0].items||[];this.modules=(result[1].items||[]).filter(function(item){return MODULE_LABELS[item.key];});
    var self=this;var pairs=await Promise.all(this.users.map(async function(user){try{var data=await self.api('/api/users/'+user.id+'/module-roles');return [user.id,data.roles||{}];}catch(error){var fallback={};self.modules.forEach(function(module){fallback[module.key]=defaultAccess(user.role,module.key);});return [user.id,fallback];}}));
    this.userRoles={};pairs.forEach(function(pair){self.userRoles[pair[0]]=pair[1];});this.renderNewModules();this.renderUsers();
  }catch(error){this.notify(error.message||'账号读取失败',true);document.getElementById('ycApUserList').innerHTML='<div class="yc-ap-empty">账号读取失败，请稍后重试。</div>';}
  finally{this.busy=false;}
};
AccountPermissions.prototype.renderNewModules=function(){
  var role=document.getElementById('ycApNewRole').value||'user';var box=document.getElementById('ycApNewModules');box.innerHTML=this.modules.map(function(module){var access=defaultAccess(role,module.key);return '<label>'+escapeHtml(MODULE_LABELS[module.key])+'<select data-yc-ap-new-module="'+escapeHtml(module.key)+'"'+(role==='tenant_admin'?' disabled':'')+'>'+accessOptions(access)+'</select></label>';}).join('');
};
AccountPermissions.prototype.applyNewRoleDefaults=function(){this.renderNewModules();};
AccountPermissions.prototype.renderUsers=function(){
  var self=this;document.getElementById('ycApSummary').textContent='共 '+this.users.length+' 个账号';if(!this.users.length){document.getElementById('ycApUserList').innerHTML='<div class="yc-ap-empty">暂无员工账号</div>';return;}
  var moduleHeads=this.modules.map(function(module){return '<th>'+escapeHtml(MODULE_LABELS[module.key])+'</th>';}).join('');
  var rows=this.users.map(function(user){
    var fixed=user.role==='tenant_admin';var roles=self.userRoles[user.id]||{};var moduleCells=self.modules.map(function(module){var value=fixed?'manager':(roles[module.key]||defaultAccess(user.role,module.key));return '<td><select data-yc-ap-role-for="'+user.id+'" data-module="'+escapeHtml(module.key)+'"'+(fixed?' disabled':'')+'>'+accessOptions(value)+'</select></td>';}).join('');
    var actions='<button type="button" data-yc-ap-reset="'+user.id+'">重置密码</button>';if(Number(user.id)!==Number(self.currentUser.id))actions+=' <button type="button" class="'+(user.is_active?'yc-ap-danger':'')+'" data-yc-ap-toggle="'+user.id+'" data-active="'+(user.is_active?'1':'0')+'">'+(user.is_active?'停用':'启用')+'</button>';if(!fixed)actions=' <button type="button" class="yc-ap-primary" data-yc-ap-save="'+user.id+'">保存权限</button> '+actions;
    return '<tr><td><b>'+escapeHtml(user.username)+'</b></td><td class="yc-ap-role">'+escapeHtml(roleLabel(user.role))+'<small>'+escapeHtml(roleHelp(user.role))+'</small></td>'+moduleCells+'<td><span class="yc-ap-status '+(user.is_active?'':'off')+'">'+(user.is_active?'启用':'停用')+'</span></td><td><div class="yc-ap-actions">'+actions+'</div></td></tr>';
  }).join('');
  document.getElementById('ycApUserList').innerHTML='<table><thead><tr><th>账号</th><th>基础身份</th>'+moduleHeads+'<th>状态</th><th>操作</th></tr></thead><tbody>'+rows+'</tbody></table>';
};
AccountPermissions.prototype.collectNewRoles=function(){var roles={};document.querySelectorAll('#ycApNewModules [data-yc-ap-new-module]').forEach(function(select){roles[select.dataset.ycApNewModule]=select.value;});return roles;};
AccountPermissions.prototype.createUser=async function(){
  if(this.busy)return;var username=document.getElementById('ycApNewUsername').value.trim(),password=document.getElementById('ycApNewPassword').value,role=document.getElementById('ycApNewRole').value;if(!username){this.notify('请输入员工账号',true);return;}if(password.length<6){this.notify('初始密码至少 6 位',true);return;}var button=document.getElementById('ycApCreate');button.disabled=true;button.textContent='新增中…';this.setError('');
  try{var created=await this.api('/api/users',{method:'POST',body:{username:username,password:password,role:role}});if(role!=='tenant_admin'){try{await this.api('/api/users/'+created.id+'/module-roles',{method:'PATCH',body:{roles:this.collectNewRoles()}});}catch(roleError){this.notify('账号已新增，但模块权限保存失败：'+roleError.message,true);await this.load();return;}}document.getElementById('ycApNewUsername').value='';document.getElementById('ycApNewPassword').value='';this.notify('员工账号已新增');await this.load();}catch(error){this.notify(error.message||'账号新增失败',true);}finally{button.disabled=false;button.textContent='新增账号';}
};
AccountPermissions.prototype.saveRoles=async function(userId){
  var roles={};document.querySelectorAll('[data-yc-ap-role-for="'+userId+'"]').forEach(function(select){roles[select.dataset.module]=select.value;});this.setError('');try{await this.api('/api/users/'+userId+'/module-roles',{method:'PATCH',body:{roles:roles}});this.notify('模块权限已保存，该员工需重新登录后生效');await this.load();}catch(error){this.notify(error.message||'权限保存失败',true);}
};
AccountPermissions.prototype.openReset=function(userId){var user=this.users.find(function(item){return Number(item.id)===Number(userId);});if(!user)return;this.resetUserId=userId;document.getElementById('ycApResetName').textContent=user.username;document.getElementById('ycApResetPassword').value='';document.getElementById('ycApResetConfirm').value='';document.getElementById('ycApReset').classList.add('show');setTimeout(function(){document.getElementById('ycApResetPassword').focus();},0);};
AccountPermissions.prototype.closeReset=function(){this.resetUserId=0;var panel=document.getElementById('ycApReset');if(panel)panel.classList.remove('show');};
AccountPermissions.prototype.submitReset=async function(){var password=document.getElementById('ycApResetPassword').value,confirmPassword=document.getElementById('ycApResetConfirm').value;if(password.length<6){this.notify('新密码至少 6 位',true);return;}if(password!==confirmPassword){this.notify('两次输入的新密码不一致',true);return;}var button=document.getElementById('ycApResetSave');button.disabled=true;try{await this.api('/api/users/'+this.resetUserId+'/password',{method:'POST',body:{new_password:password}});this.closeReset();this.notify('员工密码已重置');}catch(error){this.notify(error.message||'密码重置失败',true);}finally{button.disabled=false;}};
AccountPermissions.prototype.toggleUser=async function(userId,isActive){var user=this.users.find(function(item){return Number(item.id)===Number(userId);});if(!user)return;var action=isActive?'停用':'启用';if(!global.confirm('确定'+action+'账号「'+user.username+'」？'))return;try{await this.api('/api/users/'+userId+'/'+(isActive?'disable':'enable'),{method:'POST',body:{}});this.notify('员工账号已'+action);await this.load();}catch(error){this.notify(error.message||action+'失败',true);}};

global.YaochengAccountPermissions={
  init:function(options){if(manager)manager.update(options);else manager=new AccountPermissions(options||{});return manager;},
  open:function(){return manager?manager.open():false;},
  close:function(){if(manager)manager.close();}
};
})(window);
