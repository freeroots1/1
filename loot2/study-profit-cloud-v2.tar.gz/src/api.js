const apiUrl = (path = '') => `${import.meta.env.BASE_URL}api${path}`

export const getProjects = () => fetch(apiUrl('/projects')).then((response) => response.json())
