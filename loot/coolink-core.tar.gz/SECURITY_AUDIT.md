# Cool Link 安全审阅报告

审阅日期：2026-08-22（UTC+8）
工作目录：`/Users/aimx210/WorkBuddy/Claw/coolink`
审阅范围：provider 实现、前端 admin 面板、反爬防盗机制、凭证存储与下发、日志/限流/认证
审阅方法：纯代码审计（未运行、未改代码）

---

## 严重度分布

| 级别 | 数量 |
|---|---|
| CRITICAL | 2 |
| HIGH | 6 |
| MEDIUM | 8 |
| LOW | 4 |

---

## CRITICAL

### C-1. 运营者网盘 BDUSS / auth_token 等完整凭证随 fetch 下发到用户浏览器

- **文件**：`server/server.js:1356-1402`
- **代码**：
  ```js
  if (provider === 'uc' && siteSettings.cookies.uc)      target._cookie = ucSenderCookie(siteSettings.cookies.uc);
  if (provider === 'baidu' && siteSettings.cookies.baidu) target._cookie = buildBaiduCookie(siteSettings.cookies.baidu);
  if (provider === 'pan123' && siteSettings.cookies.pan123) target._cookie = siteSettings.cookies.pan123;
  if (provider === 'mcloud' && siteSettings.cookies.mcloud) target._cookie = siteSettings.cookies.mcloud;
  if (provider === 'xunlei' && siteSettings.cookies.xunlei) target._cookie = siteSettings.cookies.xunlei;
  // ...
  if (target._cookie) { result.cookie = target._cookie;
    if (provider === 'baidu') { result.baidu_sender_cookie = target._cookie; result.baidu_account_cookie = target._cookie; }
    if (provider === 'pan123') { result.pan123_account_cookie = target._cookie; }
    if (provider === 'mcloud') { result.mcloud_account_cookie = target._cookie; }
    if (provider === 'xunlei') { result.xunlei_account_cookie = target._cookie; }
  }
  ```
  同时 `lib/utils.js:7-15` 的 `quarkSenderCookie` 把 `__puus` 加入了白名单（2026-08-20 修复 412 时加入），导致白名单实际等于完整运营者登录会话。
- **问题**：`/api/quark/baidu/uc/pan123/mcloud/xunlei/fetch` 和 `/api/prepare-download` 直接把运营者网盘的完整登录态（含 `BDUSS`、`STOKEN`、`auth_token`、`ORCHES-I-ACCOUNT-ENCRYPT`、`__puus`、`token=Bearer*** 回显给浏览器。这包括**123盘 Bearer token**（可直调 `/b/api/file/*` 接口）。
- **攻击路径**：
  1. 页面 `/feedback` 内联脚本（`public/index.html:140-255`）有 `innerHTML` 注入点——配合 C-2 漏洞可执行任意前端 JS；
  2. 一旦 XSS 成立，页面 `fetch('/api/quark/fetch', …)` → 拿到运营者 BDUSS/STOKEN/token → 在攻击者服务器上伪造请求，把运营者网盘所有文件拖出、改密码、清空、勒索；
  3. 无 XSS 时，任何浏览过页面的攻击者只要能调用 fetch 端点（例如通过伪造前端请求、利用 CSP bypass）也能拿到 cookie；
  4. 用户浏览器本身也可能被恶意扩展/中间人脚本窃取本地存储的 cookie 值。
- **风险后果**：运营者所有 6 网盘账号完全沦陷，包括运营者自己存的文件。
- **修复建议**：
  1. **根本修复**：删除 `result.cookie` / `result.<provider>_account_cookie` / `result.<provider>_sender_cookie` 所有外发字段；下载直链应由后端做 `fetch(download_url, {redirect:'follow'})` 后**流式代理**回用户，而不是把登录态 cookie 下发；
  2. 若暂不能代理，采用**短期签名授权令牌**（如每次 fetch 生成 5 分钟有效期的 URL-sign，由运营者 cookie 生成 HMAC，用户拿签名 URL 直接去 CDN 拉），cookie 不出服务器；
  3. `quarkSenderCookie` 白名单必须**仅**包含 `__sdid/Video-Auth/__kuus/__uus`，**绝不**包含 `__puus`。要解决 412 应走服务端带 cookie 重拿 `file/download` 的方式，而不是把 `__puus` 下发；
  4. `ucSenderCookie` 同此，`BDUSS_BFESS` 不应当下发；
  5. `pan123_account_cookie = token=<Bearer JWT>` 是最高危，立即删除；`mcloud_account_cookie` 同样。

---

### C-2. `/api/feedback` 反馈列表存在 XSS 向量，且反馈是站内公开可见

- **文件**：`public/index.html:193-197`
- **代码**：
  ```js
  var html = arr.map(function (f) {
    return '<div id="pandel-fb-item">...' +
           '<span class="fb-name">' + escapeHtml(n) + '</span>' +
           '<span class="fb-time">' + fmt(f.created_at) + '</span></div>' +
           '<div class="fb-txt">' + escapeHtml(f.content || '') + '</div></div>';
  }).join('');
  listEl.innerHTML = title + html;
  ```
  虽然调用了 `escapeHtml`，但 `title` 直接拼接数字，且 `innerHTML` 整体注入模式本身就是高危（一旦某个字段漏 escape 或 escapeHtml 有遗漏，全部反馈 XSS）。
- **文件**：`server/server.js:2747-2760` — 后端**无鉴权、无 CSP 头、无 rate-limit 之外的任何输入校验**，只截断到 500 字，不查 HTML 标签/URL/script。攻击者可提交 `<img src=x onerror=…>`、`javascript:` URL、data URL 等载荷，虽然 escapeHtml 对 `&<>"'` 有处理，但**如果前端某处未 escape**（例如未来加富文本渲染），载荷已入库。
- **攻击路径**：攻击者在反馈框中提交精心构造的内容，其他用户打开 `/feedback` 弹窗触发 JS 执行 → 窃取 admin_token（HttpOnly 但跨域可被读）→ 攻击者调用 `/api/admin/settings` 拿到所有 cookie 预览，或调 `/api/quark/fetch` 直接拿到运营者凭证（结合 C-1）。
- **修复建议**：
  1. 后端写入 feedbacks.json 前**strip HTML 到纯文本**（正则移除 `<script>`、事件属性、`javascript:` URL）；
  2. 前端改用 `textContent` 而非 `innerHTML` 拼接；
  3. 加 CSP 响应头：`script-src 'self' 'nonce-…'`（需先让 admin 面板 nonce-化）；
  4. 反馈**不公开**最近 10 条（至少脱敏），改为仅后台可见；
  5. `/api/feedback` POST 加 rate-limit（已加 5/min/IP，但建议再加 user-agent/IP 联合）。

---

## HIGH

### H-1. `data/settings.json` 明文备份泄露运营者全部 Cookie + 123盘账号密码

- **文件**：`server/server.js:283-288`
  ```js
  if (!(saved && saved.enc === true)) {
    try { fs.copyFileSync(SETTINGS_FILE, SETTINGS_FILE + '.plain.bak'); } catch {}
  }
  ```
- **问题**：
  1. 迁移明文旧配置时把**原始明文 Cookie 备份**到 `data/settings.json.plain.bak`——一旦该文件未被清理，攻击者通过任何 RCE/SSRF 读文件方式都能拿到所有 6 网盘运营者 Cookie 及 123 盘账号密码；
  2. 即便正常 `settings.json` 是 AES-256-GCM 加密，但密钥派生用的**salt 是硬编码常量** `pandel-settings-v1`（`server/server.js:258`），意味着密钥只取决于 `ADMIN_PASSWORD`——如果 ADMIN_PASSWORD 泄露（默认 `admin123`），所有 cookie 立刻解密；
  3. scrypt 参数 `N:16384, r:8, p:1` 偏弱（建议 N≥2^20）。
- **攻击路径**：
  1. 直接 `ls data/` 发现 `settings.json.plain.bak`，读取；
  2. 通过 nginx 静态文件路径穿越或错误配置拿到 `data/` 下任意文件；
  3. 拿到默认密码 `admin123`（见 H-3）→ 用 `ADMIN_PASSWORD=admin123` 派生密钥→ 解密当前 `settings.json`。
- **修复建议**：
  1. **立刻**删除服务器上所有 `*.plain.bak` 文件；
  2. 密钥派生改为**每实例随机 salt**，存在 `data/settings.key`（文件权限 600）中；启动时读取 salt + ADMIN_PASSWORD 派生；
  3. scrypt 参数 N 提到 2^20；
  4. `ADMIN_PASSWORD` 强制通过环境变量设置（启动时若未设置，直接退出，而不是用默认值+打印警告）。

---

### H-2. 后台登录默认密码 `admin123` + 单密码全平台无二次验证

- **文件**：`server/server.js:134-135`
  ```js
  const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';
  if (!process.env.ADMIN_PASSWORD) console.log('⚠️ 未设置 ADMIN_PASSWORD 环境变量，正在使用默认密码（生产环境务必修改）');
  ```
  登录端点 `server.js:3355-3380` 只比对字符串密码，无验证码、无 TOTP、无 IP 白名单。
- **问题**：
  1. 默认密码硬编码，部署时忘记设环境变量就直接 `admin123` 全平台沦陷；
  2. 后台路径虽隐蔽（`/panel-x7k9f2`），但登录接口返回 `code:0,msg:'ok'` 且设 `Access-Control-Allow-Origin: '*'`（见 H-4），任何跨域页面都能暴力调用 `/api/admin/login`。
- **攻击路径**：扫描器或社工直接 POST `/panel-x7k9f2/api/admin/login` 尝试 `admin123`；跨域脚本枚举常见弱密码。
- **修复建议**：
  1. 若未设 `ADMIN_PASSWORD`，进程直接 `process.exit(1)`，不打印明文警告到 stdout（stdout 可能被日志收集）；
  2. 加 IP 白名单（环境变量 `ADMIN_IP_WHITELIST`），白名单外拒绝登录；
  3. 加 TOTP 二步验证；
  4. 登录限流从 5 次/15 分钟改成**账号密码对维度**（同一密码失败 3 次即锁 30 分钟）。

---

### H-3. Cookie 明文预览 `cookiePreview` 泄露前 20 字符 + 长度

- **文件**：`server/server.js:3669-3680`
  ```js
  cookiePreview[p] = v ? v.slice(0, 20) + '…(' + v.length + '字)' : '';
  ```
- **问题**：
  1. 对 123盘：`cookies.pan123` 格式为 `token=<JWT>`。JWT 前 20 字符通常是 `token=eyJhbGciOi***` 或 `eyJhbGciOiJ1cz...`，含 `alg`/`typ`，攻击者可用**已知前缀重放攻击**（JWT 前段结构公开，但部分 token 的签名可能因长度可推断）；
  2. **长度泄露**：`v.length + '字'` 让攻击者确知 Cookie 完整长度 → 缩小暴力空间；
  3. 对百度 BDUSS（长度约 50-60 字符），前 20 字符虽不足以单独验证，但**结合已知 Cookie 前缀模式**（BDUSS 无固定前缀）仍可能帮助攻击者做**部分 cookie 填充攻击**。
- **修复建议**：完全移除 `cookiePreview` 字段，或改为仅 `✓ 已配置`，不要回显任何 Cookie 片段或长度。

---

### H-4. 后台登录成功响应 `Access-Control-Allow-Origin: '*'`

- **文件**：`server/server.js:3375-3380`
  ```js
  res.writeHead(200, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Set-Cookie': `admin_token=${adminSession.token}; Path=/; Max-Age=43200; SameSite=Lax; HttpOnly`,
  });
  ```
- **问题**：`Access-Control-Allow-Origin: '*'` 与 `Set-Cookie` 同时存在**无效**（浏览器规范要求 ACAO 不能是 `*` 才能设置 credentials cookie），但**其他 admin 端点没有这个头**（由 `sendJson` 走 `corsOrigin` 白名单），意味着 admin 登录响应头与其他 admin 端点不一致。攻击者可利用不同浏览器/代理行为差异跨域抓取 `admin_token`。
- 更重要的是：如果某次 nginx/CDN 缓存了该响应，`*` 头可能被错误传播到其他 admin 端点，彻底击穿 CORS 白名单。
- **攻击路径**：恶意网站 `evil.com` 上 JS 调用 `fetch('/api/admin/login', {credentials:'include'})` → 若浏览器行为差异允许设置 cookie，则 `admin_token` 被植入 `evil.com` 域 → 后续跨域请求 admin API 全通。
- **修复建议**：
  1. 登录响应也用 `corsOrigin` 白名单机制，**绝不**返回 `*`；
  2. 登录接口要求 `SameSite=Strict` 或 `SameSite=Lax` + 前端加 CSRF token；
  3. admin 面板页面本身也加 CSP 头。

---

### H-5. execFile 参数注入 — 迅雷/百度 Playwright 脚本参数无过滤

- **文件**：`server/providers/resolve-other.js:534-546, 633-657, 912-929, 964-982`
- **代码片段**：
  ```js
  const args = [XUNLEI_SCRIPT, shareId, pwd || ''];
  if (parentId) { args.push('--parent', parentId); }
  if (passCodeToken) { args.push('--token', passCodeToken); }
  execFile(XUNLEI_PY, args, { timeout: 60000, ... }, ...)
  ```
  `xunleiTransfer`（633-657）：`args = [XUNLEI_DL_PY, String(shareId || ''), String(pwd || '')]` 同样直接拼参数。
  `baiduTransfer`（912-929）：`[BAIDU_TRANSFER_PY, clean, String(pwd || ''), String(fsId || '')]`。
- **问题**：
  1. 虽然 `execFile` 不经过 shell，**但 Python 脚本 `sys.argv[1]`/`sys.argv[2]` 又被拼接进 URL**：`server/tools/xunlei_page.py:44-45`
     ```python
     url = ('https://api-pan.xunlei.com/drive/v1/share?share_id=' + urllib.request.quote(share_id) +
            '&pass_code=' + urllib.request.quote(passcode) + '...')
     ```
     `urllib.request.quote` 会处理大部分字符，但传入的 `passcode` 来自用户 body（`server.js:2707`），攻击者可以构造超长 shareId（如 1MB 字符串）或含换行/特殊字符的值，导致：
     - URL 长度 DOS（迅雷 API 拒绝，但 Python 已发送请求）；
     - 请求头污染（若 shareId 被拼进 header，例如 Python 脚本中）；
  2. `maxBuffer: 4 * 1024 * 1024`（4MB），但**无输入长度上限**——攻击者发 100MB 的 shareId body，Node 侧 `readBody` 5MB 上限能挡一部分，但 shareId 是 URL 的一部分会被传进 `execFile`，且 Python 侧无二次校验；
  3. 100% CPU 攻击：大量并发 `xunleiTransfer` 每个 spawn Chromium（60s timeout × 多并发）→ 服务器崩溃。
- **攻击路径**：POST `/api/xunlei/restore-files` body `{"url":"https://pan.xunlei.com/s/<1GB垃圾>", "file_name":"..."}` → Python 进程 spawn 多个浏览器实例 → OOM / 磁盘写满。
- **修复建议**：
  1. 后端**在进入 execFile 前**校验 `shareId` 长度 ≤ 32 字符、`pwd` ≤ 8 字符、`fileName` ≤ 256 字符、且只允许 `[A-Za-z0-9_.\-]` 白名单；
  2. Python 脚本端**同样做输入校验**；
  3. 加**并发令牌桶**：同一时刻最多 1 个 Playwright 进程运行；
  4. 加 `maxBuffer` 到 256KB（JSON 输出不会很大）。

---

### H-6. `xunleiRefreshToken` / `xunleiCaptchaToken` / JWT 明文落盘 + 固定路径

- **文件**：`server/server.js:2466`
  ```js
  require('fs').writeFileSync('/home/ubuntu/pwand-playwright/xunlei_jwt_cache.json', JSON.stringify({ jwt: j.access_token, ts: Math.floor(Date.now() / 1000) }, null, 2));
  ```
  以及 `tools/xunlei_page.py:18`：
  ```python
  TOKEN_CACHE = '/home/ubuntu/pwand-playwright/xunlei_token.json'
  ```
- **问题**：
  1. **硬编码绝对路径** `/home/ubuntu/pwand-playwright/*`，脱离部署环境不可用且路径可被猜测；
  2. 文件**无权限保护**（默认 644 或更高）；文件内容**无加密**——只要服务器上其他进程/用户有读权限，就能拿到迅雷 refresh_token / captcha_token / access_token；
  3. refresh_token 长期有效，一旦泄露攻击者可任意刷新访问运营者迅雷云盘。
- **修复建议**：
  1. 文件权限 `0600`；
  2. 内容同样走 `aes-256-gcm` 加密存储（与 settings 同密钥体系）；
  3. 路径改到 `data/xunlei_jwt.json`（应用内 data 目录），不硬编码 `/home/ubuntu/*`；
  4. 或干脆走 `settings.json` 加密存储（已在 `siteSettings.xunleiRefreshToken` 字段），删掉冗余的磁盘缓存。

---

## MEDIUM

### M-1. 今日密码 `genCode()` 仅 1000-9999（4 位数字），全平台暴力破解成本几乎为零

- **文件**：`server/quark-auto.js:90-93`
  ```js
  function genCode() {
    return String(1000 + Math.floor(Math.random() * 9000));
  }
  ```
- **问题**：
  1. `Math.random()` 非密码学安全（已被多实例共享的种子问题影响）；
  2. 4 位数字空间仅 9000 种，1 秒即可跑完（`/api/daily-tasks/complete` 无密码猜错限流）；
  3. `/api/daily-tasks/complete` 端点（`server.js:3003-3041`）只做**精确字符串比对** `input !== code`，无失败次数限流，无延迟反馈。
- **攻击路径**：POST `/api/daily-tasks/complete` 快速迭代 9000 次（每 100ms 一次，约 15 秒）→ 解锁所有小文件/大文件/网盘下载权限 → 无限制下载。
- **修复建议**：
  1. `genCode()` 改用 `crypto.randomInt(100000, 999999)` 至少 6 位；
  2. 或改成 **12 字符字母数字**（`crypto.randomBytes(8).toString('hex')`）；
  3. `/api/daily-tasks/complete` 加**每任务每 IP 5 次/10 分钟**失败限流，或加验证码；
  4. 返回响应加**恒时比较**（`crypto.timingSafeEqual`），防止时序侧信道。

---

### M-2. `device_id` 是 8 字节随机 hex（128 位熵），但 cookie 无 `HttpOnly`，且仅用于 quota

- **文件**：`server/server.js:653-668`
  ```js
  did = crypto.randomBytes(8).toString('hex');  // 16 hex chars
  ...
  headers['Set-Cookie'] = `device_id=${res._deviceId}; Path=/; Max-Age=2592000; SameSite=Lax`;
  ```
- **问题**：
  1. cookie 非 `HttpOnly`——**XSS 后可直接篡改 device_id**；攻击者可伪造 `device_id` 为一个新设备，绕过每日额度限制（`/api/ip-quota`）；
  2. `device_id` 长度仅 16 hex 字符，熵 128 bit 足够，但**用户浏览器存储该 cookie 后，同 IP 多浏览器共享额度失效**（每个浏览器随机生成自己的 device_id，绕过每日 20 次/2GB 限制）。
- **攻击路径**：用户换浏览器/清 cookie → 新 device_id → 新配额 → 反复操作，绕过限额。
- **修复建议**：
  1. `device_id` cookie 加 `HttpOnly`（虽然前端也要读，但可换成 `document.cookie` 无法读的**签名 cookie**）；
  2. 或让 `device_id` 绑定**浏览器指纹**（`navigator.userAgent + canvas fingerprint + timezone`），用户清 cookie 仍无法完全绕；
  3. 限额维度改成 `IP + device_id` 双绑定：同一 IP 的 device_id 数 ≥ 3 时触发验证。

---

### M-3. CORS 白名单仅白名单站点，但**直连 IP 请求不受限**

- **文件**：`server/server.js:705-720`
  ```js
  const CORS_ALLOWED = (process.env.CORS_ORIGINS || 'https://coolink.cc.cd,http://coolink.cc.cd')
    .split(',').map((s) => s.trim()).filter(Boolean);
  function corsOrigin(req) {
    const origin = req.headers.origin || '';
    if (!origin) return null;  // 同源/无浏览器（curl）→ 不需要 ACAO
    ...
  }
  ```
- **问题**：
  1. 无 `Origin` 头时（curl、Python requests、Postman、浏览器直接 IP 访问）→ `corsOrigin` 返回 `null`，`sendJson` 不设置 ACAO 头 → 但响应**依然正常返回**，攻击者通过 API 客户端（非浏览器）可**完全绕过** CORS 限制；
  2. Cloudflare Tunnel 若被配置错误直连服务器 IP（绕过 tunnel），攻击者直接用 curl 调用 `/api/admin/*`（若知道路径）或 `/api/quark/fetch` 拿 cookie。
- **攻击路径**：攻击者获取服务器真实 IP（Cloudflare 泄露、IP 扫描、`curl ifconfig.me` 探测等）→ `curl http://<真实IP>:3000/api/quark/fetch ...` → 拿到运营者 cookie（H-1 漏洞直接触发）。
- **修复建议**：
  1. nginx 层加 `if ($host != "coolink.cc.cd") { return 403; }` 拒绝非官方域名请求；
  2. Node 层对 `/api/admin/*` 和 `/api/*/fetch` 强制要求 `Host` 头为白名单域名；
  3. Cloudflare Tunnel **必须**配置 `--metrics localhost:xxxx` 并监控，检测直连流量。

---

### M-4. `parsePassword === '1234'` 时密码墙完全失效（demo 后门）

- **文件**：`server/server.js:2681-2688`
  ```js
  if (
    siteSettings.parsePassword &&
    siteSettings.parsePassword !== '1234' &&
    /^\/api\/(quark|baidu|uc|xunlei|pan123|mcloud)\/(fetch|restore-files)$/.test(pathname) &&
    !q.unlocked
  ) {
    return sendJson(res, 403, ...);
  }
  ```
  同时 `server.js:3208-3214` `/api/download` 端点：
  ```js
  if (!q.unlocked) return sendJson(res, 403, { ... hint: '扫码或复制口令到网盘转存，获取解析密码后再下载（demo 密码 1234）' });
  ```
- **问题**：管理员**忘记改密码**时（即保留默认 `PARSE_PASSWORD = '1234'`），所有 `/api/*/fetch` 无需密码直接放行。虽然 `/api/download` 仍会拦，但 `/api/quark/fetch` 等**直接拿直链的端点**完全开放。
- **攻击路径**：直接 curl `/api/quark/fetch` → 无 password 校验 → 拿到直链 + cookie。
- **修复建议**：
  1. **删除 `'1234'` 后门判断**，密码墙应始终生效；
  2. 管理员首次部署必须强制设置 `parsePassword`，否则服务启动失败；
  3. 或把 demo 密码改为明显的 `__DEMO_MODE__` 常量并在启动时输出到日志 + stdout + 面板警示。

---

### M-5. `/api/search/check-links` 任意 URL HEAD 请求——SSRF

- **文件**：`server/server.js:3183-3198`
  ```js
  if (pathname === '/api/search/check-links' && req.method === 'POST') {
    const body = await readBody(req);
    const urls = Array.isArray(body.urls) ? body.urls : [body.url];
    const results = await Promise.all(urls.filter(Boolean).map(async (u) => {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 6000);
      const resp = await fetchTimeout(u, { method: 'HEAD', redirect: 'follow', signal: ctrl.signal });
      ...
    }));
  }
  ```
- **问题**：
  1. 完全无 URL 白名单，攻击者可传 `http://169.254.169.254/latest/meta-data/`（云元数据）、`http://localhost:3000/api/admin/settings`（内网）、`http://<内网服务>`；
  2. `redirect: 'follow'` 允许跳转到任意地址；
  3. `urls` 数组无长度上限，`Promise.all` 并发→SSRF 爆破；
  4. 虽然搜索已禁用（`search.enabled=false`），但**端点本身未关闭**，任何能调 API 的用户都能用。
- **攻击路径**：`POST /api/search/check-links` body `{"urls":["http://169.254.169.254/latest/meta-data/iam/security-credentials/"]}` → 拿到 AWS/GCP 实例凭证。
- **修复建议**：
  1. **直接删除或关闭**该端点（搜索已禁用，无用途）；
  2. 若保留，加 URL 白名单（仅允许 `https://pan.*`、`https://yun.*` 等网盘域名），且禁止 `10./172.16-31./192.168./169.254./127.` 等内网段；
  3. 加数量上限（≤ 10）和速率限制。

---

### M-6. `sanitizeSettings` 的 `cookiePreview` 泄露前 20 字符（admin 端点）

- **文件**：`server/server.js:3669-3680` 同 H-3
- 这里重复指出：`/api/admin/settings` GET（`server.js:3460-3466`）返回 `cookiePreview` 字段 → **任何已登录 admin 会话都可看到 cookie 前缀 + 长度**。结合 admin 会话是 HttpOnly cookie 存储，如果被 XSS 打到 admin 页面，可读出。
- **修复建议**：同 H-3，完全移除 `cookiePreview`。

---

### M-7. 移动云盘 `MC_KEY` 硬编码 + 无盐 AES-128-CBC

- **文件**：`server/providers/resolve-other.js:744-745`
  ```js
  const MC_KEY = Buffer.from('PVGDwmcvfs1uV3d1', 'utf8');
  ...
  const cipher = cryptoLib.createCipheriv('aes-128-cbc', MC_KEY, iv);
  ```
- **问题**：
  1. `MC_KEY = 'PVGDwmcvfs1uV3d1'` 是**移动云盘公开已知的 16 字节静态密钥**（share139-proxy 项目同源），任何攻击者都拥有此密钥；
  2. 这意味着所有 `dlFromOutLinkV3` 请求体对攻击者**可完全解密和伪造**——攻击者可构造虚假下载请求，让运营者账号替他人下载/转存（消耗运营者流量）；
  3. 更严重的是，响应体也同密钥加密——**移动云盘服务器响应中的 CDN 直链/`presentURL` 可被中间人解密**。
- **风险说明**：这是上游协议层面的问题，非本应用独有；但对运营者账号**无保护力**，任何知道此密钥的人都能模拟下载请求。
- **修复建议**：
  1. 无根本修复（这是上游协议缺陷）；
  2. 应用层可通过**限制 `/api/mcloud/fetch` 频率** + **记录每次下载**缓解流量滥用；
  3. 在 admin 后台增加"最近下载记录"面板，异常行为告警。

---

### M-8. 123盘 API 签名算法完全暴露在代码中（`pan123Sign`）

- **文件**：`server/providers/resolve-other.js:18-56`
  ```js
  const SIGN_TABLE = ['a','d','e','f','g','h','l','m','y','i','j','n','o','p','k','q','r','s','t','u','b','c','v','w','s','z'];
  function pan123Sign(path, mode) { ... }
  ```
- **问题**：签名算法 `SIGN_TABLE` 和 `crc32` 拼接方式**完全暴露在源码中**，攻击者可复刻签名逻辑，**伪装成本应用**对 123 盘 API 发起请求。结合 H-1 的 token 泄露风险，攻击者可直接用运营者 token 调 `/b/api/file/upload_request` 等接口，把任意文件**秒传到运营者 123 账号**（污染账号）。
- **说明**：123 盘 API 签名本身是**客户端可逆向的已知算法**（无服务端密钥），因此这不是应用独有漏洞，但**token 保护至关重要**——一旦 token 泄露（H-1/C-1），攻击者拥有完全权限。
- **修复建议**：核心仍是**保护好 `cookies.pan123` token**（见 C-1），token 不出服务器、不缓存明文、定期轮换。

---

## LOW

### L-1. `data/` 目录日志泄露 URL 前 60 字符

- **文件**：`server/server.js:1115, 1430, 3574-3578`
  ```js
  const u = String(body && (body.url || body.share_url || '') || '').slice(0, 60);
  pushAdminLog('parse_err', `[${classifyError(e.message)}] ${provider} 解析失败: ${String(e.message || '').slice(0, 100)} | url=${u}`);
  ```
- **问题**：URL 前 60 字符含**分享 ID + 可能含 pwd=提取码**；`data/logs/*` 和 `data/actions/*` 落盘。这些文件**无权限保护**（Node 默认），服务器同用户其他进程可读。
- **修复建议**：对 URL 中的 `pwd=` 参数值做 mask（如 `pwd=****`），对 share_id 保留首 8 字符。

---

### L-2. `/api/encode` 用 MD5 生成短 ID，可预测

- **文件**：`server/server.js:2770-2781`
  ```js
  const id = crypto.createHash('md5').update(target).digest('hex').slice(0, 12);
  return sendJson(res, 200, { id, qrcode_url: `/api/qrcode?target=...`, page_url: `/?target=${encodeURIComponent(target)}`, target });
  ```
- **问题**：`target` 直接回显在响应和 URL 参数中，短 ID 只是展示用，风险较低。但若 `target` 是敏感分享链接，URL 参数会**记录到浏览器历史/Referer/nginx access log**。
- **修复建议**：响应中 `target` 字段可选脱敏，或改用 `HMAC(target)` 生成不可逆 ID。

---

### L-3. `crypto.randomBytes(8)` 生成 device_id 熵足够，但 `Math.random()` 用于生成短链/nonce 不安全

- **文件**：`server/server.js:2774, 2775`（`y()` 前端函数）+ 前端 `admin-main.v3.js:1`（`y()` 使用 `Math.random().toString(36)`）
- **问题**：前端 nonce 用于签名防重放（`X-Req-Nonce`），但 `Math.random()` 是可预测 PRNG，签名防重放效果打折扣。
- **修复建议**：改用 `crypto.randomUUID()` 或 `crypto.getRandomValues()` 生成 nonce。

---

### L-4. `/api/qrcode` 无内容长度限制，可被滥用做放大攻击

- **文件**：`server/server.js:3267-3288`
- **问题**：`text` 参数无长度上限，攻击者可传 100KB 文本让 Node 生成 360x360 PNG（实际 PNG 大小有限制），或传超长生成巨大 SVG 响应体。
- **修复建议**：限制 `text.length ≤ 2000`。

---

## 反爬防盗机制审阅小结

| 反爬机制 | 现状 | 漏洞/绕过点 |
|---|---|---|
| 每日密码（4 位数字） | `genCode()` 1000-9999 | **M-1** 暴力破解成本 ≈ 0 |
| 密码墙强制 | `parsePassword !== '1234'` 才强制 | **M-4** 保留默认密码时完全绕过 |
| 直链时效/IP 绑定 | 转存直链 `expires_at` 无后端验证 | 直链是 CDN URL，第三方拿到后可直接复用 |
| cookie 下发限流 | 10/min/IP（downloader-cookie）| **C-1** 仍下发完整 cookie，限流无意义 |
| IP 限流 | `RATE_LIMITS` 每个接口 5-60/min | **H-5** 并发令牌缺失，可被 Playwright 爆破；**M-3** 直连 IP 绕过 CORS |
| UA 识别 | 仅访问统计时排除 `HeadlessChrome` | 解析 API 无 UA 校验，任意 UA 可调用 |
| 后台路径隐蔽 | `/panel-x7k9f2` | **M-3** 唯一保护，一旦泄露全靠登录密码；**H-2** 默认密码 |
| 登录限流 | 5 次/15 分钟/IP | 跨域登录（H-4）可绕过 |
| admin session | IP 绑定 + 12h 有效期 | 同 IP 多设备共享 session 风险 |

---

## 修复优先级建议

### P0（立即）
1. **C-1**：删除所有 `result.cookie` / `*_account_cookie` / `*_sender_cookie` 外发字段；改走服务端代理下载。
2. **C-1**：`quarkSenderCookie` 白名单移除 `__puus`；`ucSenderCookie` 移除 `BDUSS_BFESS`。
3. **H-1**：删除 `data/settings.json.plain.bak`；检查服务器是否还有其他明文 cookie 备份。
4. **H-2**：`ADMIN_PASSWORD` 强制环境变量，不设则退出；立即更换为强密码。
5. **H-4**：删除登录响应中的 `Access-Control-Allow-Origin: '*'`。

### P1（本周）
6. **M-1**：`genCode()` 升级到 6 位数字或 12 字符 hex；complete 接口加限流。
7. **M-4**：删除 `'1234'` 后门判断。
8. **M-5**：关闭或限制 `/api/search/check-links`。
9. **M-3**：nginx 加 `Host` 头校验；拒绝非官方域名请求。
10. **H-6**：`xunlei_jwt_cache.json` / `xunlei_token.json` 加密 + 权限 600。
11. **H-5**：Playwright 参数做白名单校验 + 加并发令牌。

### P2（本月）
12. **H-3/M-6**：移除 `cookiePreview`。
13. **M-2**：`device_id` 加 `HttpOnly`，或多维度绑定。
14. **C-2**：反馈存储纯文本 + CSP 头。
15. **L-1**：URL 中的 pwd 参数在日志中 mask。

---

## 附：服务器部署安全（无法本地验证，需现场检查）

以下项目需**在服务器 115.159.226.161 上**实际核查（本审计未直连）：

| 项目 | 需确认项 |
|---|---|
| nginx | `log_format` 是否记录 `$request_body`；是否禁掉 `PUT/DELETE/PATCH/OPTIONS`；是否设 `add_header X-Content-Type-Options nosniff; X-Frame-Options DENY; X-XSS-Protection: 1;`；是否设 CSP |
| pandl.service | `User=ubuntu` 是否非 root；`ProtectHome=read-only`；`NoNewPrivileges=yes`；是否暴露除 3000 外端口 |
| Cloudflare Tunnel | 是否禁掉 80/443 直连（`ufw deny 80,443`）；tunnel credentials 是否轮转 |
| data/ 目录 | `chmod -R 700 data/`；防 nginx 静态托管误映射到 `/data/*` |
| Cloudflare WAF | 是否开启对 `/panel-*` 路径的规则保护 |

---

*报告结束*
