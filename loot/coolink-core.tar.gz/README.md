# Cool Link · 网盘直链解析

网盘解析站 demo：**自研 UI 与「四道墙 + 每日任务」机制**，并接入**真实的网盘直链解析**——用你自己的账号 Cookie 调网盘官方接口拿直链（非 mock）。

## 运行

```bash
bash /Users/aimx210/WorkBuddy/Claw/coolink/start.sh
# 浏览器打开 http://localhost:3000
```

零依赖：后端 Node 原生 `http` + `fetch`，前端 Vue3（本地 `vendor/`，无 CDN）。**无需 `npm install`、无需备案**。

## 真实解析怎么用（重点）

1. 点右上「⚙ 账号配置」，填入**你自己的**网盘 Cookie：
   - **夸克**：登录 pan.quark.cn → F12 → Network → 找 `list` 请求 → 复制完整 `Cookie`（须含 `__puus`）
   - **百度**：登录 pan.baidu.com → F12 → Application → Cookies → 复制 `BDUSS`
2. 首页粘贴网盘分享链接（夸克 `pan.quark.cn/s/xxx` / 百度 `pan.baidu.com/s/xxx?pwd=xxx`）
3. 解析**不拦截**；只有点「下载 / 推 aria2」那一步才弹任务墙：需先完成「去网盘保存」任务或输入解析密码（**demo 为 `1234`**，对应真实场景里去网盘保存压缩包拿的 4 位密码）
4. 点「解析直链」→ 真实返回文件直链 → 可「复制」或「推 aria2」

## 设计对应

| 参考设计 | 本 demo |
|---|---|
| 视觉（实际是 emerald/slate 浅色主题，非深空蓝黑） | 采用真实 CSS 配色（`#10b981` 主色、`#f8fafc` 底、12px 圆角、Inter 字体） |
| 解析密码墙 | `/api/search/auth/unlock`（demo 密码 `1234`） |
| 大文件次数 / 小文件流量 / 单文件大小「四道墙」 | 配额系统，但**统一作用在「下载」环节**（解析自由出直链、不拦），每日任务发放额度 |
| 每日任务换额度 | `/api/daily-tasks/*` |
| 搜资源 | `/api/search`（mock 资源列表） |
| 扫链解析（出直链，不拦） | `/api/parse`（**真实**，夸克/百度已接入） |
| 下载环节才弹四道墙 | `/api/download`（密码墙 / 小文件流量 / 大小上限 / 大文件次数） |

## 真实解析实现（合法，用自己账号）

- **夸克**：`sharepage/token` → `sharepage/detail` 列文件 → **免转存直链** `file/download`（带 `stoken` 直接以分享者身份拉 `download_url`，**不占自己网盘空间**）；仅当免转存失败（少数加密/大文件）才回退到转存 `sharepage/save` → `file/download`。`__puus` Cookie 自动续期。参考开源 [gopeed-extension-quark](https://github.com/muyan556/gopeed-extension-quark)。
  - ⚠️ **修复记录**：原版会先「转存到自己网盘」再下，网盘容量不足时夸克返回 `32003: capacity limit[{0}]`。已改为默认**免转存**，从根上规避该错。
- **百度**：`share/wxlist` → `share/tplconfig`(sign) → `api/sharedownload` 拿 `dlink`（用 `BDUSS` Cookie）。参考开源 [gopeed-extension-baiduwp](https://github.com/code-hasaki/gopeed-extension-baiduwp)。
- **123盘 / 移动云盘 / 迅雷 / UC**：架构已预留，返回清晰提示；按上述开源项目（如 [netdisk-fast-download](https://github.com/qaiu/netdisk-fast-download)）接入各自私有接口即可（同样用你自己的 Cookie）。

实测证据：带假 cookie 调用，服务端**真实返回夸克 `41006`、百度 `errno=-130`**，证明请求确已打向 `pan.quark.cn` / `pan.baidu.com` 官方接口，链路非 mock。

## aria2 推送（可选）

设置里填 aria2 RPC 地址（如 `http://127.0.0.1:6800/jsonrpc`）与 token，解析后点「推 aria2」即用专业下载器多线程拉取。

## 合规说明

所有解析均使用**你自己的网盘账号 Cookie**，调用网盘官方/公开接口，与 Gopeed 等开源项目声明一致：**合法合规、仅供学习**。请勿用于下载侵权资源。

## 已知限制

- Cookie 仅存于内存，重启服务端即失效（demo 用途）
- 仅夸克 / 百度真实接入；其余网盘需按开源实现补全各自私有接口
- 单机内存存储，无数据库；配额按设备（cookie `device_id`）隔离、跨天重置
