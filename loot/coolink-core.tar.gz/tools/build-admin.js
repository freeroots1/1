// 构建脚本（终极版）：把 vue 全局版(UMD) + admin.js 全部内联进 admin.html
// 全部是普通 <script>（非 ESM）→ 浏览器必定执行，零外部依赖、零 import、零缓存问题
'use strict';
const fs = require('fs');
const path = require('path');

const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const htmlFile = path.join(PUBLIC_DIR, 'admin.html');
const jsFile = path.join(PUBLIC_DIR, 'admin.js');
const vueFile = path.join(PUBLIC_DIR, 'vendor', 'vue.global.prod.js');

const vue = fs.readFileSync(vueFile, 'utf8');      // UMD：var Vue=function...（挂全局）
const js = fs.readFileSync(jsFile, 'utf8');        // 普通脚本：window.mountAdmin

// admin.js 里若还有 const createApp = window.Vue... 引用，保持原样（window.Vue 由 UMD 提供）

const inlineScript = `
<!-- ===== 内联 Vue 全局版（UMD，挂 window.Vue）===== -->
<script>
${vue}
</script>
<!-- ===== 内联后台应用（普通脚本，定义 window.mountAdmin）===== -->
<script>
${js}
</script>
<!-- ===== 启动后台（必须调用 mountAdmin！）===== -->
<script>
(function () {
  try {
    if (typeof window.mountAdmin === 'function') window.mountAdmin();
    else document.getElementById('app').innerHTML = '<div style="color:red;padding:40px;font-family:monospace;font-size:13px">后台启动失败: mountAdmin 未定义</div>';
  } catch (e) {
    var app = document.getElementById('app');
    if (app) app.innerHTML = '<div style="color:red;padding:40px;font-family:monospace;font-size:13px">后台启动失败:<br>' + (e && e.stack ? e.stack.split('\\n').slice(0,5).join('<br>') : e.message) + '</div>';
  }
})();
</script>
`;

let html = fs.readFileSync(htmlFile, 'utf8');
// 幂等：先移除所有已内联的 script 块（vue/admin/启动），避免重复构建越积越大
html = html.replace(/<!-- ===== 内联 Vue 全局版[\s\S]*?<\/script>\n/g, '\n');
html = html.replace(/<!-- ===== 内联后台应用[\s\S]*?<\/script>\n/g, '\n');
html = html.replace(/<!-- ===== 启动后台[\s\S]*?<\/script>\n/g, '\n');
html = html.replace(/<script>\s*var Vue=function[\s\S]*?<\/script>\n/g, '\n');
html = html.replace(/<script>\s*\/\* coolink 管理后台前端[\s\S]*?<\/script>\n/g, '\n');
html = html.replace(/<script>\s*\(function \(\) \{\s*try \{\s*if \(typeof window\.mountAdmin[\s\S]*?<\/script>\n/g, '\n');
html = html.replace(/<script type="module">[\s\S]*?<\/script>\n/g, '\n');
// 在 </body> 前插入内联
html = html.replace('</body>', inlineScript + '\n</body>');
fs.writeFileSync(htmlFile, html);

console.log('✅ 终极内联完成：vue 全局版 + admin.js 全部内联（普通 script，零 ESM）');
console.log('   admin.html 大小:', (html.length / 1024).toFixed(1), 'KB');
console.log('   window.Vue:', vue.includes('var Vue') || vue.includes('globalThis.Vue') ? '✅' : '⚠️');
console.log('   mountAdmin:', js.includes('function mountAdmin') ? '✅' : '⚠️');
