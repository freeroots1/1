#!/usr/bin/env node
/**
 * Cool Link 自动化脚本：每日轮换解析密码 + 同步推广口令
 *
 * 真实完整流程（完整变现闭环）：
 *   ① 生成新的 4 位解析密码
 *   ② 把密码写进一个 txt / 压缩包
 *   ③ 用网盘官方上传接口，把压缩包传到自己的夸克/移动云盘（需运营者 Cookie）
 *   ④ 在网盘联盟后台生成带追踪 UID 的推广分享链接 + 口令
 *   ⑤ 更新网站后台配置：parsePassword + promo.{provider}.link/passcode
 * 本脚本实现 ①⑤（通过 admin API），②③④ 因需网盘上传接口 + 联盟后台，留下清晰骨架。
 *
 * 用法：
 *   node tools/rotate-password.js            # 轮换密码并写回后台
 *   node tools/rotate-password.js --dry-run  # 只生成密码、打印，不写后台
 *
 * 定时调度（macOS launchd 示例，见文件末尾注释）：
 *   launchctl 每天凌晨 3 点触发一次。
 */
'use strict';

const BASE = process.env.PANDL_BASE || 'http://localhost:3000';
const ADMIN_PASSWORD = process.env.PANDL_ADMIN_PASSWORD || 'admin123';
const DRY_RUN = process.argv.includes('--dry-run');

function genPassword() {
  // 4 位数字解析密码
  return String(Math.floor(1000 + Math.random() * 9000));
}

async function api(path, opts = {}) {
  const r = await fetch(BASE + path, opts);
  const ct = r.headers.get('content-type') || '';
  if (ct.includes('json')) return { json: await r.json(), resp: r };
  return { json: null, resp: r };
}

function extractCookie(resp) {
  const setCookies = resp.headers.getSetCookie ? resp.headers.getSetCookie() : [];
  for (const sc of setCookies) {
    const m = sc.match(/^([^=]+)=([^;]*)/);
    if (m && m[1] === 'admin_token') return `${m[1]}=${m[2]}`;
  }
  return '';
}

async function main() {
  const newPwd = genPassword();
  console.log(`[rotate-password] 新解析密码 = ${newPwd}`);

  if (DRY_RUN) {
    console.log('[rotate-password] dry-run：已生成密码，未写回后台。');
    return;
  }

  // ① 登录 admin
  const login = await api('/api/admin/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password: ADMIN_PASSWORD }),
  });
  if (!login.json || login.json.code !== 0) {
    console.error('[rotate-password] 后台登录失败：', login.json && login.json.msg);
    process.exit(1);
  }
  const cookie = extractCookie(login.resp);

  // ② 拉取当前设置，只改 parsePassword（保留 promo 等其它配置）
  const cur = await api('/api/admin/settings', { headers: { Cookie: cookie } });
  const curSettings = (cur.json && cur.json.data) || {};

  // ③ 写回新密码（真实场景这里还会带上新的 promo.link/passcode）
  const patch = {
    parsePassword: newPwd,
  };
  // TODO: 真实场景在此调用网盘上传接口，得到新分享链接后一并更新：
  //   patch.promo = { quark: { passcode: '...', link: 'https://pan.quark.cn/s/xxx', qrUrl: '' }, ... }
  const save = await api('/api/admin/settings', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Cookie: cookie },
    body: JSON.stringify(patch),
  });
  if (save.json && save.json.code === 0) {
    console.log(`[rotate-password] ✅ 解析密码已轮换为 ${newPwd}（旧值 ${curSettings.parsePassword || '?'}）`);
  } else {
    console.error('[rotate-password] 写回失败：', save.json && save.json.msg);
    process.exit(1);
  }
}

main().catch((e) => { console.error('[rotate-password] 出错：', e.message); process.exit(1); });

/*
 * ===== macOS launchd 每日凌晨 3 点定时调度 =====
 * 把下面内容存到 ~/Library/LaunchAgents/com.coolink.rotate-password.plist
 * 然后：launchctl load ~/Library/LaunchAgents/com.coolink.rotate-password.plist
 *
 * <?xml version="1.0" encoding="UTF-8"?>
 * <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
 * <plist version="1.0"><dict>
 *   <key>Label</key><string>com.coolink.rotate-password</string>
 *   <key>ProgramArguments</key><array>
 *     <string>/Users/aimx210/.workbuddy/binaries/node/versions/22.22.2/bin/node</string>
 *     <string>/Users/aimx210/WorkBuddy/Claw/coolink/tools/rotate-password.js</string>
 *   </array>
 *   <key>StartCalendarInterval</key><dict>
 *     <key>Hour</key><integer>3</integer>
 *     <key>Minute</key><integer>0</integer>
 *   </dict>
 *   <key>StandardOutPath</key><string>/tmp/coolink-rotate.log</string>
 *   <key>StandardErrorPath</key><string>/tmp/coolink-rotate.err</string>
 * </dict></plist>
 */
