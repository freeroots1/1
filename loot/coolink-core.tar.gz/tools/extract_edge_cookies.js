#!/usr/bin/env node
/**
 * extract_edge_cookies.js —— 从本机 Microsoft Edge 提取已登录网盘的 Cookie
 *
 * 背景：coolink 后端要生成直链（让「下载器」能下），需要各网盘的登录态
 *       （siteSettings.cookies[provider]）。这些 Cookie 存在用户登录的浏览器里，
 *       不在后端。本脚本把浏览器里的登录 Cookie 抽出来，供写入 settings.json。
 *
 * 安全说明：
 *   - 本脚本只读取网盘相关域名的 Cookie，不碰其它站点。
 *   - 解密密钥来自 macOS 钥匙串「Microsoft Edge Safe Storage」，首次运行会在
 *     终端弹出授权框，需在「你的 GUI 会话」里点允许（headless/远程会话点不到）。
 *   - 仅在本机运行，产物可直接粘进 coolink 后台「网盘 Cookie」配置，或交给本脚本
 *     的 --write 模式写进本地 data/settings.json（该文件已被 .gitignore 忽略，不会进 git）。
 *
 * 用法：
 *   node tools/extract_edge_cookies.js            # 仅打印各网盘 Cookie 字符串
 *   node tools/extract_edge_cookies.js --write    # 额外写进本地 data/settings.json（加密）
 *
 * 依赖：系统 sqlite3（已自带）、node 内置 crypto。无需联网安装。
 */
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const EDGE_COOKIES = path.join(os.homedir(), 'Library/Application Support/Microsoft Edge/Default/Cookies');
const SALT = Buffer.from('saltysalt', 'utf8');
const IV = Buffer.alloc(16, 0x20);
const ITER = 1003;

// 网盘域名 → provider 映射
const DOMAIN_MAP = [
  { provider: 'baidu',  hosts: ['pan.baidu.com', 'baidu.com'] },
  { provider: 'quark',  hosts: ['pan.quark.cn', 'quark.cn'] },
  { provider: 'uc',     hosts: ['drive.uc.cn', 'uc.cn'] },
  { provider: 'pan123', hosts: ['123pan.com', '123pan.cn', 'share.123pan.cn', 'login.123pan.com'] },
  { provider: 'xunlei', hosts: ['pan.xunlei.com', 'xunlei.com'] },
  { provider: 'mcloud', hosts: ['yun.139.com', 'caiyun.139.com'] },
];

function getKeychainKey() {
  // 钥匙串弹窗需要 GUI 会话；在远程/headless 里会卡住超时
  return execFileSync('security', ['find-generic-password', '-s', 'Microsoft Edge Safe Storage', '-w'],
    { encoding: 'utf8' }).trim();
}

function dumpCookies() {
  const tmp = path.join('/tmp', 'edge_cookies_' + Date.now() + '.db');
  // 复制一份避免占用锁（WAL 一并复制）
  execFileSync('cp', [EDGE_COOKIES, tmp]);
  try { execFileSync('cp', [EDGE_COOKIES + '-wal', tmp + '-wal']); } catch {}
  try { execFileSync('cp', [EDGE_COOKIES + '-shm', tmp + '-shm']); } catch {}
  const sql = `SELECT host_key, name, encrypted_value, path, is_secure, expires_utc
               FROM cookies
               WHERE ${DOMAIN_MAP.map(d => d.hosts.map(h => `host_key LIKE '%${h.replace(/'/g, "''")}%'`).join(' OR ')).join(' OR ')};`;
  const out = execFileSync('sqlite3', ['-json', tmp, sql], { encoding: 'utf8' });
  return JSON.parse(out || '[]');
}

function decryptValue(enc, key) {
  if (!enc) return '';
  // 新版前缀 v10/v11（AES-256-CBC）或空（明文）
  let buf = Buffer.isBuffer(enc) ? enc : Buffer.from(enc, 'utf8');
  if (buf.slice(0, 3).toString() === 'v10' || buf.slice(0, 3).toString() === 'v11') buf = buf.slice(3);
  if (buf.length === 0) return '';
  try {
    const decipher = crypto.createDecipheriv('aes-256-cbc', key, IV);
    return decipher.update(buf).toString('utf8') + decipher.final().toString('utf8');
  } catch {
    return '';
  }
}

function buildCookieStrings(rows, key) {
  const byProvider = {};
  for (const d of DOMAIN_MAP) byProvider[d.provider] = {};
  for (const r of rows) {
    const val = decryptValue(r.encrypted_value, key);
    if (!val) continue;
    for (const d of DOMAIN_MAP) {
      if (d.hosts.some(h => r.host_key === h || r.host_key.endsWith('.' + h) || r.host_key.includes(h))) {
        byProvider[d.provider][r.name] = val;
      }
    }
  }
  const result = {};
  for (const d of DOMAIN_MAP) {
    const m = byProvider[d.provider];
    const parts = Object.entries(m).map(([k, v]) => `${k}=${v}`);
    result[d.provider] = parts.join('; ');
  }
  return result;
}

function writeSettings(cookieStrings) {
  // 复用 server.js 的加密逻辑写盘
  const settingsPath = path.join(__dirname, '..', 'data', 'settings.json');
  const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'AeLnUxLVwcTVBDU5';
  const salt = Buffer.from('pandel-settings-v1', 'utf8');
  const key = crypto.scryptSync(ADMIN_PASSWORD, salt, 32, { N: 16384, r: 8, p: 1 });
  let obj = {};
  if (fs.existsSync(settingsPath)) {
    try {
      const raw = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
      if (raw.enc === true && raw.data) {
        const b = Buffer.from(raw.data, 'base64');
        const dec = crypto.createDecipheriv('aes-256-gcm', key, b.subarray(0, 12));
        dec.setAuthTag(b.subarray(12, 28));
        obj = JSON.parse(Buffer.concat([dec.update(b.subarray(28)), dec.final()]).toString('utf8'));
      } else obj = raw;
    } catch (e) { console.error('读取旧 settings 失败，将新建:', e.message); }
  }
  obj.cookies = obj.cookies || {};
  for (const p of Object.keys(cookieStrings)) {
    if (cookieStrings[p]) obj.cookies[p] = cookieStrings[p];
  }
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ct = Buffer.concat([cipher.update(Buffer.from(JSON.stringify(obj), 'utf8')), cipher.final()]);
  const tag = cipher.getAuthTag();
  fs.writeFileSync(settingsPath, JSON.stringify({ enc: true, v: 1, data: Buffer.concat([iv, tag, ct]).toString('base64') }, null, 2));
  console.log('已写入', settingsPath);
}

function main() {
  if (!fs.existsSync(EDGE_COOKIES)) { console.error('未找到 Edge Cookies 文件:', EDGE_COOKIES); process.exit(1); }
  console.log('正在从钥匙串读取 Edge 解密密钥（若弹出授权框请在终端允许）…');
  const key = crypto.pbkdf2Sync(getKeychainKey(), SALT, ITER, 32, 'sha1');
  const rows = dumpCookies();
  console.log(`导出网盘相关 Cookie 行数: ${rows.length}`);
  const cookieStrings = buildCookieStrings(rows, key);
  console.log('\n===== 各网盘 Cookie（可直接粘进后台，或配合 --write 写盘）=====');
  for (const p of Object.keys(cookieStrings)) {
    const v = cookieStrings[p];
    console.log(`\n[${p}] ${v ? 'OK (' + v.length + ' 字符)' : '空（该网盘未在 Edge 登录或 Cookie 缺失）'}`);
    if (v) console.log('   ', v.slice(0, 200) + (v.length > 200 ? '…' : ''));
  }
  const hasAny = Object.values(cookieStrings).some(Boolean);
  if (!hasAny) {
    console.log('\n⚠️ 未抽到任何网盘 Cookie：请确认对应网盘已在 Edge 登录，且本脚本在「你的 GUI 会话」终端运行（钥匙串授权框已允许）。');
  }
  if (process.argv.includes('--write') && hasAny) writeSettings(cookieStrings);
}

main();
