#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
xunlei_page.py — 迅雷云盘分享解析（Playwright 页面方案 + token 缓存复用）

核心思路：
- 迅雷 API 强制 x-captcha-token，绑定 device_id + action + 来源 IP，captcha_sign 由
  浏览器 WASM 生成（服务器无法伪造）。只有真实浏览器打开分享页才能自动拿到 token。
- token 有效期 6-24h，且同一来源 IP 可复用 → 只在 token 过期时开一次浏览器
  （~1.8MB 流量），其余解析直接用缓存的 token 走 API（~10KB/次）。

用法:
  python xunlei_page.py <share_id> [passcode] [--parent <id>] [--token <pass_code_token>]
输出: JSON {ok, share_status, title, files:[{id,name,kind,size,parent_id}], error?}
"""
import json, sys, time, urllib.request, urllib.error

TOKEN_CACHE = '/home/ubuntu/pwand-playwright/xunlei_token.json'
JWT_CACHE = '/home/ubuntu/pwand-playwright/xunlei_jwt_cache.json'
TOKEN_TTL = 6 * 3600  # token 缓存 6 小时（实际 6-24h，保守 6h）
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36'

# 2026-08-20 修：JWT 自愈——读取运营者迅雷登录 Cookie（settings 解密）注入浏览器页面，
#   页面登录后 API 请求带 Authorization: Bearer <JWT>（xluser-ssl 签发）→ request 事件捕获 → 写 JWT 缓存。
#   此前 JWT 只能手动捕获（过期后转存/每日密码生成全挂：oidc: token is expired）。
def get_xunlei_cookie():
    try:
        import subprocess
        js = """const fs=require('fs'),crypto=require('crypto');
const j=JSON.parse(fs.readFileSync(process.argv[1],'utf8'));
let _SALT='pandel-settings-v1'; try { _SALT=fs.readFileSync('/home/ubuntu/app/coolink/data/settings.salt','utf8').trim(); } catch(e){} if(!_SALT||_SALT.length<16)_SALT='pandel-settings-v1';
const key=crypto.scryptSync(process.env.ADMIN_PASSWORD||'AeLnUxLVwcTVBDU5',Buffer.from(_SALT,'utf8'),32,{N:65536,r:8,p:1,maxmem:128*1024*1024});
const b=Buffer.from(j.data,'base64');
const d=crypto.createDecipheriv('aes-256-gcm',key,b.subarray(0,12));d.setAuthTag(b.subarray(12,28));
const o=JSON.parse(Buffer.concat([d.update(b.subarray(28)),d.final()]).toString('utf8'));
process.stdout.write(o.cookies.xunlei||'');"""
        r = subprocess.run(['/usr/bin/node', '-e', js, '/home/ubuntu/app/coolink/data/settings.json'],
                           capture_output=True, text=True, timeout=15)
        return r.stdout.strip()
    except Exception:
        return ''

def save_jwt_cache(jwt):
    try:
        with open(JWT_CACHE, 'w', encoding='utf-8') as f:
            json.dump({'jwt': jwt, 'ts': int(time.time())}, f)
    except Exception:
        pass

def load_token_cache():
    try:
        with open(TOKEN_CACHE, 'r', encoding='utf-8') as f:
            d = json.load(f)
        if time.time() - d.get('ts', 0) < TOKEN_TTL and d.get('token'):
            return d
    except Exception:
        pass
    return None

def save_token_cache(token, did, cookie=''):
    # 2026-08-20 13:25 修复：cookie 必须持久化！api_fetch 带 Cookie 头才能过迅雷 400 风控，
    #   只存 token/did → api_fetch cookie='' → 400 → 永远回退浏览器（9.2s）
    try:
        with open(TOKEN_CACHE, 'w', encoding='utf-8') as f:
            json.dump({'token': token, 'did': did, 'ts': int(time.time()), 'cookie': cookie or ''}, f)
    except Exception:
        pass

def api_fetch(share_id, passcode, token, did, cookie='', parent_id='', pass_code_token=''):
    """直接用 API 请求（不开浏览器）。2026-08-20 支持 detail（--parent 纯 API）：
       先 GET /drive/v1/share 拿 pass_code_token，再 GET /drive/v1/share/detail 拿子目录列表"""
    hdrs0 = {
        'User-Agent': UA, 'Content-Type': 'application/json',
        'x-device-id': did, 'x-client-id': 'Xqp0kJBXWhwaTpB6',
        'x-captcha-token': token, 'Referer': 'https://pan.xunlei.com/',
    }
    if cookie:
        hdrs0['Cookie'] = cookie
    if parent_id:
        # detail：需要 pass_code_token（调用方可传 --token；否则先 share?limit=1 拿）
        pct = pass_code_token or ''
        if not pct:
            u1 = ('https://api-pan.xunlei.com/drive/v1/share?share_id=' + urllib.request.quote(share_id) +
                  '&pass_code=' + urllib.request.quote(passcode) + '&limit=1&keyword=&pass_code_token=&page_token=&scene=NORMAL&order_by=')
            try:
                with urllib.request.urlopen(urllib.request.Request(u1, headers=hdrs0), timeout=20) as r1:
                    j1 = json.loads(r1.read().decode('utf-8'))
                pct = j1.get('pass_code_token') or ''
            except Exception:
                pct = ''
        if not pct:
            return 400, json.dumps({'error': 'pass_code_token 获取失败（detail）'})
        url = ('https://api-pan.xunlei.com/drive/v1/share/detail?share_id=' + urllib.request.quote(share_id) +
               '&parent_id=' + urllib.request.quote(parent_id) + '&pass_code_token=' + urllib.request.quote(pct))
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=hdrs0), timeout=20) as r:
                return r.status, r.read().decode('utf-8')
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode('utf-8', 'ignore')
        except Exception as e:
            return 0, json.dumps({'error': str(e)[:100]})
    url = ('https://api-pan.xunlei.com/drive/v1/share?share_id=' + urllib.request.quote(share_id) +
           '&pass_code=' + urllib.request.quote(passcode) + '&limit=100&keyword=&pass_code_token=&page_token=&scene=NORMAL&order_by=')
    hdrs = {
        'User-Agent': UA, 'Content-Type': 'application/json',
        'x-device-id': did, 'x-client-id': 'Xqp0kJBXWhwaTpB6',
        'x-captcha-token': token, 'Referer': 'https://pan.xunlei.com/',
    }
    if cookie:
        hdrs['Cookie'] = cookie
    req = urllib.request.Request(url, headers=hdrs)
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            body = r.read().decode('utf-8')
            return r.status, body
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode('utf-8', 'ignore')
    except Exception as e:
        return 0, json.dumps({'error': str(e)[:100]})

def parse_share_json(j, parent_id):
    src = (j.get('file_list') or j.get('files') or []) if parent_id else (j.get('files') or [])
    files = []
    for f in src or []:
        files.append({
            'id': f.get('id') or f.get('file_id') or '',
            'name': f.get('name') or f.get('file_name') or '',
            'kind': f.get('kind') or ('drive#folder' if (f.get('is_dir') or f.get('isDir')) else 'drive#file'),
            'size': int(f.get('size') or 0),
            'parent_id': f.get('parent_id') or '',
        })
    return {
        'ok': True,
        'share_status': j.get('share_status') or '',
        'title': j.get('title') or '',
        'files': files,
        'next_page_token': j.get('next_page_token') or '',
        'pass_code_token': j.get('pass_code_token') or '',
    }

def browser_resolve(share_id, passcode, parent_id='', pass_code_token=''):
    """开浏览器：拿新 token + 解析（~1.8MB 流量）"""
    from playwright.sync_api import sync_playwright
    # 2026-08-20 修：注入运营者登录 cookie → 页面 API 请求带 Bearer JWT → 捕获刷新（JWT 自愈）
    jwt_captured = {}
    def _on_request(req):
        try:
            auth = (req.headers or {}).get('authorization', '')
            if auth.startswith('Bearer ') and len(auth) > 100:
                jwt_captured['jwt'] = auth[7:]
        except Exception:
            pass
    ck = get_xunlei_cookie()
    cookies = []
    if ck:
        for part in ck.split(';'):
            part = part.strip()
            if '=' in part:
                k, v = part.split('=', 1)
                cookies.append({'name': k.strip(), 'value': v.strip(), 'domain': '.xunlei.com', 'path': '/'})
    with sync_playwright() as p:
        b = p.chromium.launch(headless=True, args=['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage'])
        ctx = b.new_context(viewport={'width': 1400, 'height': 900}, user_agent=UA)
        if cookies:
            try: ctx.add_cookies(cookies)
            except Exception: pass
        page = ctx.new_page()
        page.on('request', _on_request)
        page.goto('https://pan.xunlei.com/s/%s?pwd=%s' % (share_id, passcode),
                  wait_until='domcontentloaded', timeout=30000)
        time.sleep(8)
        js = """async (args) => {
            const { shareId, passcode, parentId, passCodeToken } = args;
            let captcha = '';
            for (let i=0;i<localStorage.length;i++){
                const k = localStorage.key(i), v = localStorage.getItem(k);
                if (k.includes('captcha_')) { try { captcha = JSON.parse(v).token || ''; } catch(e){} }
            }
            let did = '';
            for (let i=0;i<localStorage.length;i++){
                const k = localStorage.key(i);
                if (k === 'deviceid') { did = localStorage.getItem(k) || ''; break; }
            }
            if (!did) did = (document.cookie.match(/deviceid=([^;]+)/)||[])[1] || '';
            // 2026-08-23 修：保留完整 wdi10. 前缀——captcha token 绑定的是完整 deviceid，
            //   截断前缀导致 x-device-id 与 captcha 设备不匹配 → detail 返回空 files
            let url, opts = { headers: {
                'Content-Type': 'application/json', 'x-device-id': did,
                'x-client-id': 'Xqp0kJBXWhwaTpB6', 'x-captcha-token': captcha,
                'Referer': 'https://pan.xunlei.com/',
            }};
            if (parentId) {
                let pct = passCodeToken || '';
                if (!pct) {
                    const sr = await fetch('https://api-pan.xunlei.com/drive/v1/share?share_id=' + encodeURIComponent(shareId) +
                        '&pass_code=' + encodeURIComponent(passcode) + '&limit=1&keyword=&pass_code_token=&page_token=&scene=NORMAL&order_by=', opts);
                    const sj = await sr.json();
                    pct = sj.pass_code_token || '';
                }
                url = 'https://api-pan.xunlei.com/drive/v1/share/detail?share_id=' + encodeURIComponent(shareId) +
                    '&parent_id=' + encodeURIComponent(parentId) + '&pass_code_token=' + encodeURIComponent(pct || '');
            } else {
                url = 'https://api-pan.xunlei.com/drive/v1/share?share_id=' + encodeURIComponent(shareId) +
                    '&pass_code=' + encodeURIComponent(passcode) + '&limit=100&keyword=&pass_code_token=&page_token=&scene=NORMAL&order_by=';
            }
            const r = await fetch(url, opts);
            const j = await r.json();
            return {status: r.status, body: j, did: did, token: captcha, cookie: document.cookie};
        }"""
        result = page.evaluate(js, {'shareId': share_id, 'passcode': passcode, 'parentId': parent_id, 'passCodeToken': pass_code_token})
        b.close()

    # 缓存新 token（同 IP 复用）
    if result.get('token') and result.get('did'):
        save_token_cache(result['token'], result['did'], result.get('cookie') or '')
    # 2026-08-20 修：捕获到新 JWT → 写缓存（JWT 自愈，转存/每日密码不再依赖手动捕获）
    if jwt_captured.get('jwt'):
        save_jwt_cache(jwt_captured['jwt'])
    out = parse_share_json(result.get('body') or {}, parent_id)
    if out.get('ok'):
        out['_usedBrowser'] = True
    return out

def main():
    # 2026-08-20 23:5x 修：--refresh-creds 浏览器刷新 JWT（页面 JS 用 refresh_token 自动续期）
    #   注入 cookie + 旧 credentials 到页面 → 页面加载检测过期自动 refresh → 读回新 access_token → 写缓存
    if '--refresh-creds' in sys.argv:
        from playwright.sync_api import sync_playwright
        try:
            import subprocess
            js = """const fs=require('fs'),crypto=require('crypto');
const j=JSON.parse(fs.readFileSync(process.argv[1],'utf8'));
let _SALT='pandel-settings-v1'; try { _SALT=fs.readFileSync('/home/ubuntu/app/coolink/data/settings.salt','utf8').trim(); } catch(e){} if(!_SALT||_SALT.length<16)_SALT='pandel-settings-v1';
const key=crypto.scryptSync(process.env.ADMIN_PASSWORD||'AeLnUxLVwcTVBDU5',Buffer.from(_SALT,'utf8'),32,{N:65536,r:8,p:1,maxmem:128*1024*1024});
const b=Buffer.from(j.data,'base64');
const d=crypto.createDecipheriv('aes-256-gcm',key,b.subarray(0,12));d.setAuthTag(b.subarray(12,28));
const o=JSON.parse(Buffer.concat([d.update(b.subarray(28)),d.final()]).toString('utf8'));
process.stdout.write(JSON.stringify({ck:o.cookies.xunlei||'', jwt:o.xunleiAccessToken||'', rt:o.xunleiRefreshToken||''}));"""
            creds = json.loads(subprocess.run(['/usr/bin/node', '-e', js, '/home/ubuntu/app/coolink/data/settings.json'],
                                              capture_output=True, text=True, timeout=15).stdout)
            cookies = []
            for part in (creds.get('ck') or '').split(';'):
                part = part.strip()
                if '=' in part:
                    k, v = part.split('=', 1)
                    cookies.append({'name': k.strip(), 'value': v.strip(), 'domain': '.xunlei.com', 'path': '/'})
            init = ("() => { try { const v = {token_type:'Bearer', access_token: " + json.dumps(creds.get('jwt') or '')
                     + ", refresh_token: " + json.dumps(creds.get('rt') or '')
                     + ", expires_in: 43200, expires_at: new Date(Date.now()-3600*1000).toISOString()};"
                     + " localStorage.setItem('credentials_Xqp0kJBXWhwaTpB6', JSON.stringify(v)); } catch(e) {} }")
            with sync_playwright() as p:
                b = p.chromium.launch(headless=True, args=['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage'])
                ctx = b.new_context(viewport={'width': 1400, 'height': 900}, user_agent=UA)
                if cookies:
                    try: ctx.add_cookies(cookies)
                    except Exception: pass
                page = ctx.new_page()
                page.add_init_script(init)
                page.goto('https://pan.xunlei.com/', wait_until='domcontentloaded', timeout=30000)
                time.sleep(12)
                cred = page.evaluate("() => localStorage.getItem('credentials_Xqp0kJBXWhwaTpB6') || ''")
                b.close()
            new_jwt = ''
            new_rt = creds.get('rt') or ''
            if cred:
                try:
                    c = json.loads(cred)
                    new_jwt = c.get('access_token') or ''
                    new_rt = c.get('refresh_token') or new_rt
                except Exception: pass
            if new_jwt:
                save_jwt_cache(new_jwt)
                # 回写 settings.xunleiAccessToken / xunleiRefreshToken
                upjs = """const fs=require('fs'),crypto=require('crypto');
const j=JSON.parse(fs.readFileSync(process.argv[1],'utf8'));
let _SALT='pandel-settings-v1'; try { _SALT=fs.readFileSync('/home/ubuntu/app/coolink/data/settings.salt','utf8').trim(); } catch(e){} if(!_SALT||_SALT.length<16)_SALT='pandel-settings-v1';
const key=crypto.scryptSync(process.env.ADMIN_PASSWORD||'AeLnUxLVwcTVBDU5',Buffer.from(_SALT,'utf8'),32,{N:65536,r:8,p:1,maxmem:128*1024*1024});
const b=Buffer.from(j.data,'base64');
const d=crypto.createDecipheriv('aes-256-gcm',key,b.subarray(0,12));d.setAuthTag(b.subarray(12,28));
const o=JSON.parse(Buffer.concat([d.update(b.subarray(28)),d.final()]).toString('utf8'));
o.xunleiAccessToken=process.argv[2]; o.xunleiRefreshToken=process.argv[3];
const iv=crypto.randomBytes(12); const c=crypto.createCipheriv('aes-256-gcm',key,iv);
const ct=Buffer.concat([c.update(Buffer.from(JSON.stringify(o),'utf8')),c.final()]);
const tag=c.getAuthTag();
fs.writeFileSync(process.argv[1], JSON.stringify({enc:true,v:1,data:Buffer.concat([iv,tag,ct]).toString('base64')},null,2));"""
                subprocess.run(['/usr/bin/node', '-e', upjs, '/home/ubuntu/app/coolink/data/settings.json', new_jwt, new_rt], timeout=15)
                print(json.dumps({'ok': True, 'refreshed': True, 'jwt_len': len(new_jwt)}, ensure_ascii=False))
            else:
                print(json.dumps({'ok': False, 'error': 'refresh-creds 未拿到新 access_token'}, ensure_ascii=False))
        except Exception as e:
            print(json.dumps({'ok': False, 'error': 'refresh-creds 失败: ' + str(e)[:200]}, ensure_ascii=False))
        return 0

    # 2026-08-20 修：--token-only 只刷新 captcha token（不解析分享）
    #   captcha token 会轮换（旧 token 对 share 等接口 400 captcha_invalid）→ 生成器/转存前调用
    if '--token-only' in sys.argv:
        from playwright.sync_api import sync_playwright
        try:
            with sync_playwright() as p:
                b = p.chromium.launch(headless=True, args=['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage'])
                ctx = b.new_context(viewport={'width': 1400, 'height': 900}, user_agent=UA)
                page = ctx.new_page()
                page.goto('https://pan.xunlei.com/', wait_until='domcontentloaded', timeout=30000)
                time.sleep(8)
                r = page.evaluate("""() => {
                    let captcha = '';
                    for (let i=0;i<localStorage.length;i++){
                        const k = localStorage.key(i), v = localStorage.getItem(k);
                        if (k.includes('captcha_')) { try { captcha = JSON.parse(v).token || ''; } catch(e){} }
                    }
                    let did = (document.cookie.match(/deviceid=([^;]+)/)||[])[1] || '';
                    did = did.replace(/^wdi10\\./i, '');
                    return { token: captcha, did: did, cookie: document.cookie };
                }""")
                b.close()
            if r.get('token') and r.get('did'):
                save_token_cache(r['token'], r['did'], r.get('cookie') or '')
                print(json.dumps({'ok': True, 'token_refreshed': True}, ensure_ascii=False))
            else:
                print(json.dumps({'ok': False, 'error': 'token-only 未拿到 captcha'}, ensure_ascii=False))
        except Exception as e:
            print(json.dumps({'ok': False, 'error': 'token-only 失败: ' + str(e)[:200]}, ensure_ascii=False))
        return 0

    share_id = sys.argv[1] if len(sys.argv) > 1 else ''
    passcode = sys.argv[2] if len(sys.argv) > 2 else ''
    parent_id = ''
    pass_code_token = ''
    rest = sys.argv[3:]
    i = 0
    while i < len(rest):
        if rest[i] == '--parent' and i + 1 < len(rest): parent_id = rest[i + 1]; i += 2
        elif rest[i] == '--token' and i + 1 < len(rest): pass_code_token = rest[i + 1]; i += 2
        else: i += 1
    if not share_id:
        print(json.dumps({'ok': False, 'error': '缺少 share_id'}, ensure_ascii=False))
        return 1

    try:
        # 1) 有缓存 token → 直接 API（零浏览器流量；share/detail 都支持）
        cache = load_token_cache()
        if cache:
            status, body = api_fetch(share_id, passcode, cache.get('token'), cache.get('did'), cache.get('cookie', ''), parent_id, pass_code_token)
            if status == 200:
                    try:
                        j = json.loads(body)
                        st = j.get('share_status') or ''
                        if st and st != 'NOT_FOUND':
                            out = parse_share_json(j, '')
                            out['_usedBrowser'] = False
                            print(json.dumps(out, ensure_ascii=False))
                            return 0
                    except Exception:
                        pass
                # token 失效/分享状态异常 → 落浏览器重取
        # 2) 开浏览器（拿新 token / detail）
        out = browser_resolve(share_id, passcode, parent_id, pass_code_token)
        print(json.dumps(out, ensure_ascii=False))
        return 0
    except Exception as e:
        print(json.dumps({'ok': False, 'error': str(e)[:300]}, ensure_ascii=False))
        return 1

if __name__ == '__main__':
    sys.exit(main())
