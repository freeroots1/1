/* coolink 管理后台前端应用（独立 chunk，2026-08-19 从 admin.html 内联拆出）
 * 提供 window.mountAdmin，由 admin.html 内联的 Vue 源码 + 本文件共同构成后台
 * 依赖：window.Vue（admin.html 内联的 Vue UMD 源码）*/
'use strict';

function mountAdmin() {
const createApp = (window.Vue && window.Vue.createApp) || (() => { throw new Error('Vue 未加载'); });
const PROVIDER_NAMES = { quark: '夸克网盘', baidu: '百度网盘', xunlei: '迅雷网盘', pan123: '123盘', mcloud: '移动云盘', uc: 'UC网盘' };
const PROVIDER_KEYS = Object.keys(PROVIDER_NAMES);

createApp({
  data() {
    return {
      authed: false,
      pwd: '',
      err: '',
      tab: 'overview',
      providerNames: PROVIDER_NAMES,
      providerKeys: PROVIDER_KEYS,
      // 2026-08-19：Cookie 循环排除 123盘（改账号密码登录，Cookie 框不再展示）
      cookieProviderKeys: PROVIDER_KEYS.filter((p) => p !== 'pan123'),
      feedbacks: [],
      visitor: { total: 0, mobile: 0, pc: 0, sourceTop: [] },
      overview: { parseOk: 0, parseFail: 0, activeDevices: 0, totalActions: 0, byProvider: {}, accessTotal: 0, accessUsers: 0, visitorSource: [] },
      accessSeries: [],
      parseSeries: [],
      form: {
        cookies: { quark: '', baidu: '', xunlei: '', pan123: '', mcloud: '', uc: '' },
        cookieConfigured: {},
        cookiePreview: {},  // 2026-08-20：脱敏预览（已保存 xx 字符），输入框 placeholder 展示
        cookieDirty: {},  // 记录哪些 Cookie 输入框被管理员动过（避免误清空）
        pan123Account: { username: '', password: '', clear: false },  // 2026-08-19：123盘 账号密码登录
        // 2026-08-19 加固：promo 预填全部 6 网盘（loadAccounts 未完成/失败时卡片元素也一定渲染）
        promo: {
          quark: { passcode: '', link: '', qrUrl: '', auto_daily: false },
          baidu: { passcode: '', link: '', qrUrl: '', auto_daily: false },
          xunlei: { passcode: '', link: '', qrUrl: '', auto_daily: false },
          pan123: { passcode: '', link: '', qrUrl: '', auto_daily: false },
          mcloud: { passcode: '', link: '', qrUrl: '', auto_daily: false },
          uc: { passcode: '', link: '', qrUrl: '', auto_daily: false },
        },
        // 2026-08-19 加固：模板访问的字段全部 data() 预填（防 loadAccounts 前渲染崩溃）
        pan123Account: { username: '', password: '', clear: false, hasPassword: false },
        xunleiCaptchaToken: { hasToken: false },
        xunleiCaptchaTokenInput: '',
        xunleiCaptchaTokenClear: false,
        pan123LoginState: { ok: null, error: '', ts: 0 },
        pan123Token: '',
        pan123TokenState: { ok: null, msg: '' },
        pan123Status: { accountConfigured: false, hasPassword: false, tokenConfigured: false, tokenOk: null, tokenPrefix: '', tokenLen: 0, tokenError: '', checkedAt: 0 },
      },
      saved: false,
      saving: false,       // 账号与推广保存中（disable 按钮）
      saveErr: '',          // 保存失败提示
      saveRunResult: null,  // 保存后触发的今日密码程序执行结果
      dailyPwdBusy: false,  // 「立即重新生成」按钮点击后到返回前
      dailyPwdRunResult: null, // 手动重新生成的执行结果
      taskBusy: null,      // 任务保存中（记录正在保存的 task.id）
      taskErr: null,       // 任务保存失败（记录 task.id）
      logs: { admin: [], actions: [] },
      // 今日密码状态（推广区块小字展示）
      dailyPwd: null,
      // 任务管理
      tasks: [],
      taskCategories: ['小文件', '大文件', '网盘解锁', '其它'],
    };
  },
  mounted() {
    this.checkAuth();
  },
  methods: {
    rewardTypeLabel(t) {
      const map = {
        unlock_small_file: '解锁小文件',
        unlock_large_file: '解除大小限制',
        unlock_downloader: '解锁发送下载器',
        small_file_all_providers: '追加小文件流量',
        small_file_single_provider: '追加指定网盘小文件',
        single_provider: '追加次数',
        default: '追加次数',
      };
      return map[t] || t;
    },
    async api(path, opts) {
      const r = await window.fetch(path, opts);
      return r.json();
    },
    async checkAuth() {
      const r = await this.api('/api/admin/auth-check');
      if (r.code === 0 && r.data && r.data.authed) {
        this.authed = true;
        this.loadOverview();
      }
    },
    async login() {
      this.err = '';
      const r = await this.api('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: this.pwd }),
      });
      if (r.code === 0) {
        this.authed = true;
        this.loadOverview();
      } else {
        this.err = r.msg || '登录失败';
      }
    },
    logout() {
      // admin_token 是 HttpOnly Cookie，document.cookie 删不掉 —— 走后端登出接口
      fetch('/api/admin/logout', { method: 'POST' }).finally(() => {
        this.authed = false;
        this.pwd = '';
      });
    },
    async loadOverview(keepTab) {
      // 2026-08-19：keepTab=true 时不切 tab（保存后刷新数据但停留当前页，避免"看不到已保存"）
      if (!keepTab) this.tab = 'overview';
      // 2026-08-21：移除 /api/admin/trend（24h 折线图板块已删，数据恒空无意义）
      const r1 = await this.api('/api/admin/overview?days=15');
      if (r1.code === 0) {
        this.overview = { ...this.overview, ...r1.data };
        this.accessSeries = r1.data.accessSeries || [];
        this.parseSeries = r1.data.parseSeries || [];
        this.$nextTick(() => {
          this.drawAccessChart();
          this.animateCounter('statTotal', this.overview.accessTotal || 0);
          this.animateCounter('statUsers', this.overview.accessUsers || 0);
        });
      }
    },

    /* 2026-08-19：右侧滚动数字动画（从 0 滚到目标值） */
    animateCounter(elId, target) {
      const el = document.getElementById(elId);
      if (!el || !target) { if (el) el.textContent = String(target || 0); return; }
      const dur = 1200, start = performance.now();
      const step = (now) => {
        const p = Math.min(1, (now - start) / dur);
        const eased = 1 - Math.pow(1 - p, 3);
        el.textContent = Math.round(target * eased).toLocaleString();
        if (p < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    },

    /* 2026-08-19：近 15 天访问柱状图（双柱：访问次数 + 访问用户） */
    drawAccessChart() {
      const canvas = this.$refs.accessChart;
      if (!canvas || !this.accessSeries || !this.accessSeries.length) return;
      const dpr = window.devicePixelRatio || 1;
      const cssW = canvas.clientWidth || canvas.parentElement.clientWidth || 900;
      const cssH = 280;
      canvas.style.height = cssH + 'px';
      canvas.width = cssW * dpr;
      canvas.height = cssH * dpr;
      const ctx = canvas.getContext('2d');
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, cssW, cssH);
      const data = this.accessSeries;
      const padding = { top: 30, right: 24, bottom: 44, left: 48 };
      const w = cssW - padding.left - padding.right;
      const h = cssH - padding.top - padding.bottom;
      const maxV = Math.max(1, ...data.map((d) => Math.max(d.total || 0, d.devices || 0)));
      // 2026-08-19 调优：nice number（maxV=975 → 1000；避免 Math.ceil(975*1.15)=1122 这种丑数）
      const niceV = (v) => { if (v <= 1) return 1; if (v <= 2) return 2; if (v <= 5) return 5; if (v <= 10) return 10; if (v <= 20) return 20; if (v <= 50) return 50; if (v <= 100) return 100; if (v <= 200) return 200; if (v <= 500) return 500; if (v <= 1000) return 1000; if (v <= 2000) return 2000; if (v <= 5000) return 5000; if (v <= 10000) return 10000; return Math.ceil(v / 1000) * 1000; };
      const niceMax = niceV(maxV) * 1.1 || 10;
      ctx.font = '11px Inter, sans-serif';
      ctx.fillStyle = '#939bb1';
      ctx.strokeStyle = '#e5e9f3';
      ctx.lineWidth = 1;
      const gridLines = 4;
      for (let i = 0; i <= gridLines; i++) {
        const y = padding.top + (h * i) / gridLines;
        ctx.beginPath();
        ctx.moveTo(padding.left, y);
        ctx.lineTo(padding.left + w, y);
        ctx.stroke();
        ctx.textAlign = 'right';
        ctx.textBaseline = 'middle';
        ctx.fillText(String(Math.round(niceMax * (1 - i / gridLines))), padding.left - 8, y);
      }
      ctx.save();
      ctx.translate(14, padding.top + h / 2);
      ctx.rotate(-Math.PI / 2);
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = '600 11px Inter, sans-serif';
      ctx.fillStyle = '#6c7589';
      ctx.fillText('访问次数', 0, 0);
      ctx.restore();
      const n = data.length;
      const groupW = w / n;
      const barW = Math.min(14, groupW * 0.32);
      data.forEach((d, i) => {
        const cx = padding.left + groupW * i + groupW / 2;
        const h1 = ((d.total || 0) / niceMax) * h;
        ctx.fillStyle = '#4d6bfe';
        ctx.fillRect(cx - barW - 1.5, padding.top + h - h1, barW, h1);
        const h2 = ((d.devices || 0) / niceMax) * h;
        ctx.fillStyle = '#f97316';
        ctx.fillRect(cx + 1.5, padding.top + h - h2, barW, h2);
        if (n <= 15 || i % 2 === 0 || i === n - 1) {
          ctx.textAlign = 'center';
          ctx.textBaseline = 'top';
          ctx.fillStyle = '#6c7589';
          ctx.font = '10px Inter, sans-serif';
          ctx.fillText(String(d.date || '').slice(5), cx, padding.top + h + 8);
        }
      });
      ctx.strokeStyle = '#cbd2e0';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(padding.left, padding.top);
      ctx.lineTo(padding.left, padding.top + h);
      ctx.lineTo(padding.left + w, padding.top + h);
      ctx.stroke();
      ctx.textAlign = 'center';
      ctx.font = '600 11px Inter, sans-serif';
      ctx.fillStyle = '#6c7589';
      ctx.fillText('日期（月-日）', padding.left + w / 2, cssH - 10);
    },
    async loadAccounts() {
      this.tab = 'accounts';
      const [r1, r2] = await Promise.all([
        this.api('/api/admin/settings'),
        this.api('/api/admin/daily-password'),
      ]);
      if (r1.code === 0) {
        const s = r1.data || {};
        const promo = s.promo || {};
        const cookies = {};
        const cookieConfigured = s.cookieConfigured || {};
        const cookiePreview = s.cookiePreview || {};  // 2026-08-20：脱敏预览
        const cookieDirty = {};
        for (const p of PROVIDER_KEYS) { cookies[p] = ''; cookieDirty[p] = false; }
        this.form = {
          cookies,
          cookieConfigured,
          cookiePreview,
          cookieDirty,
          pan123Account: { username: '', password: '', clear: false, hasPassword: false },
          xunleiCaptchaToken: s.xunleiCaptchaToken || { hasToken: false },
          xunleiCaptchaTokenInput: '',
          xunleiCaptchaTokenClear: false,
          pan123LoginState: s.pan123LoginState || { ok: null, error: '', ts: 0 },
          pan123Token: '',
          pan123TokenState: s.pan123TokenState || { ok: null, msg: '' },
          pan123Status: s.pan123Status || { accountConfigured: false, hasPassword: false, tokenConfigured: false, tokenOk: null, tokenPrefix: '', tokenLen: 0, tokenError: '', checkedAt: 0 },
          promo: {},
        };
        for (const p of PROVIDER_KEYS) {
          this.form.promo[p] = { passcode: '', link: '', qrUrl: '', auto_daily: false, ...(promo[p] || {}) };
        }
      }
      if (r2.code === 0 && r2.data) {
        // 兼容旧格式（单网盘）与新格式（多网盘 codes）
        const d = r2.data;
        if (d.codes) this.dailyPwd = d;
        else this.dailyPwd = { date: d.date, codes: { [d.provider || 'quark']: d.code }, shares: { [d.provider || 'quark']: d.share_url } };
      } else this.dailyPwd = null;
    },
    // ===== 今日密码：补跑失败项 =====
    // 用户 2026-08-16 强调：成功项绝不重新生成（防误触作废已发分享）。
    // 此按钮仅在「今天存在失败项」时显示，只补跑失败/未生成的网盘。
    async retryFailedDailyPwd() {
      if (!confirm('仅补跑今日【生成失败/未生成】的网盘；已成功的密码与分享链接不会改动。继续？')) return;
      this.dailyPwdBusy = true;
      this.dailyPwdRunResult = null;
      try {
        const r = await this.api('/api/admin/daily-password/run', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
        });
        this.dailyPwdRunResult = {
          ok: r.code === 0,
          msg: r.msg || '',
          generated: (r.run && r.run.generated) || [],
          skipped: (r.run && r.run.skipped) || [],
          data: r.data || null,
          failedTotal: r.failed_total || 0,
        };
        // 重新拉一次今日密码状态
        const r2 = await this.api('/api/admin/daily-password');
        if (r2.code === 0 && r2.data) this.dailyPwd = r2.data;
      } catch (e) {
        this.dailyPwdRunResult = { ok: false, msg: '请求失败：' + (e.message || e) };
      } finally {
        this.dailyPwdBusy = false;
      }
    },
    // 该网盘今日密码程序状态（供后台徽章/失败提醒使用）
    dailyPwdState(key) {
      const s = (this.dailyPwd && this.dailyPwd.state && this.dailyPwd.state[key]) || null;
      if (!s) return null;
      return s;
    },
    dailyPwdStatusText(key) {
      const s = this.dailyPwdState(key);
      if (!s) return '';
      if (s.status === 'ok') return `今日密码 ${s.code}（已分享）`;
      if (s.status === 'error') return `生成失败：${s.error || '未知错误'}`;
      return '';
    },
    // 今天是否有失败项（决定是否显示「补跑失败项」按钮 + 顶部红色提醒）
    dailyPwdHasFailed() {
      const st = (this.dailyPwd && this.dailyPwd.state) || {};
      return Object.values(st).some((s) => s && s.status === 'error');
    },
    dailyPwdFailedCount() {
      const st = (this.dailyPwd && this.dailyPwd.state) || {};
      return Object.values(st).filter((s) => s && s.status === 'error').length;
    },
    async saveSettings() {
      this.saving = true;
      this.saved = false;
      this.saveErr = '';
      this.saveRunResult = null;
      const body = {
        cookies: {},
        clearCookies: [],
        promo: {},
        // 2026-08-19：123盘 账号密码已下线（token + refresh 自续期，无需账号密码）
        pan123Account: null,
        // 2026-08-19：迅雷验证码 token（非空才提交）
        xunleiCaptchaToken: (this.form.xunleiCaptchaTokenInput || '').trim(),
        xunleiCaptchaTokenClear: !!(this.form.xunleiCaptchaTokenClear),
        // 2026-08-19：token 直填（登录被验证码风控时的替代，非空才提交）
        pan123Token: (this.form.pan123Token || '').trim(),
      };
      for (const p of PROVIDER_KEYS) {
        // 输入框有内容 → 更新；勾选了「清除」→ 显式清除；否则保持原值
        if (this.form.cookies[p] && this.form.cookies[p].trim()) body.cookies[p] = this.form.cookies[p].trim();
        else if (this.form.cookieDirty[p] && this.form.cookieConfigured[p]) body.clearCookies.push(p);
        body.promo[p] = {
          passcode: this.form.promo[p].passcode || '',
          link: this.form.promo[p].link || '',
          qrUrl: this.form.promo[p].qrUrl || '',
          auto_daily: !!this.form.promo[p].auto_daily,
        };
      }
      const r = await this.api('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      this.saving = false;
      if (r.code === 0) {
        this.saved = true;
        this.saveRunResult = {
          generated: (r.daily_pwd_run && r.daily_pwd_run.generated) || [],
          skipped: (r.daily_pwd_run && r.daily_pwd_run.skipped) || [],
        };
        // 保存后若自动程序有失败 → 醒目红色提醒（用户 2026-08-16 要求）
        const failed = (r.daily_pwd_run && r.daily_pwd_run.generated || []).filter((g) => !g.ok);
        if (failed.length) {
          const names = failed.map((f) => `${PROVIDER_NAMES[f.provider] || f.provider}`).join('、');
          alert(`⚠️ 今日密码自动程序执行失败（${names}）：${failed[0].error || '未知错误'}\n\n请检查该网盘 Cookie 是否有效，修复后点「补跑失败项」。已成功的网盘不受影响。`);
        }
        // 重新拉今日密码状态（保存可能触发了 runDailyPasswordJob）
        const r2 = await this.api('/api/admin/daily-password');
        if (r2.code === 0 && r2.data) this.dailyPwd = r2.data;
        // 2026-08-20：保存后重新拉账号表单（脱敏预览/已配置徽章即时更新，让管理员确认保存成功）
        try { await this.loadAccounts(); } catch (e) {}
        this.loadOverview(true);
        setTimeout(() => { this.saved = false; }, 6000);
      } else {
        this.saveErr = r.msg || '保存失败';
      }
    },
    async loadLogs() {
      this.tab = 'logs';
      const r = await this.api('/api/admin/logs');
      if (r.code === 0) this.logs = r.data;
    },
    // ===== 反馈管理（2026-08-17：后台管理不了用户反馈 → 新增）=====
    async loadFeedback() {
      this.tab = 'feedback';
      const r = await this.api('/api/admin/feedback');
      if (r.code === 0) this.feedbacks = r.data || [];
    },
    async deleteFeedback(id) {
      if (!confirm('删除这条反馈？')) return;
      const r = await this.api('/api/admin/feedback/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      if (r.code === 0) this.feedbacks = this.feedbacks.filter((f) => f.id !== id);
      else alert(r.msg || '删除失败');
    },
    async clearFeedback() {
      if (!confirm('确定清空全部反馈？此操作不可恢复！')) return;
      const r = await this.api('/api/admin/feedback/clear', { method: 'POST' });
      if (r.code === 0) this.feedbacks = [];
      else alert(r.msg || '清空失败');
    },
    // ===== 任务管理（固定任务位：每个任务位选择网盘口令任务）=====
    async loadTasks() {
      this.tab = 'tasks';
      const r = await this.api('/api/admin/daily-tasks');
      if (r.code === 0) {
        this.tasks = ((r.data && r.data.tasks) || []).map((t) => ({ ...t, providers: Array.isArray(t.providers) ? [...t.providers] : [] }));
      }
    },
    // 保存单个任务位：绑定网盘密码任务（task_provider）；不绑定 = 停用
    async saveTaskSlot(t) {
      if (this.taskBusy) return;
      this.taskBusy = t.id;
      this.taskErr = null;
      t._saved = false;
      const task = {
        id: t.id,
        type: 'answer',
        icon: t.icon || '🎯',
        title: t.title,
        description: t.description,
        reward_type: t.reward_type || 'default',
        reward_count: Number(t.reward_count) || 0,
        reward_provider: t.task_provider || '',
        providers: t.task_provider ? [t.task_provider] : [],
        answer: '',
        enabled: !!t.task_provider,
        task_provider: t.task_provider || '',
      };
      const r = await this.api('/api/admin/daily-tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ task }),
      });
      this.taskBusy = null;
      if (r.code === 0) {
        t._saved = true;
        t.enabled = task.enabled;
        setTimeout(() => { t._saved = false; }, 2000);
      } else {
        this.taskErr = t.id;
        setTimeout(() => { this.taskErr = null; }, 3000);
      }
    },
    async deleteTask(id) {
      if (!confirm('确认删除任务 ' + id + '？')) return;
      const r = await this.api(`/api/admin/daily-tasks/${encodeURIComponent(id)}/delete`, { method: 'POST' });
      if (r.code === 0) this.loadTasks();
      else this.err = r.msg || '删除失败';
    },
  },
}).mount('#app');
}
// 2026-08-19 拆出后显式导出（普通 script 的函数声明也会挂 window，这里双重保险）
if (typeof window !== 'undefined') window.mountAdmin = mountAdmin;
