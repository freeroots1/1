# Cool Link — 2026-08-16 大版本修复与精简日志

> 本日志覆盖 2026-08-16 01:00 ~ 02:00 的全部修改。每项记录：**为什么改 → 怎么改 → 结果如何**。
> 项目路径：`/Users/aimx210/WorkBuddy/Claw/coolink/`；线上：https://wici.cc.cd

---

## 一、前台搜索框彻底禁用（用户多次反馈"搜索界面还在"）

### 为什么
- 之前只在后端 `/api/public/meta` 返回 `search.enabled:false`，**但原版主 JS 根本不读这个字段**，搜索框无条件渲染，所以改 meta 永远无效（用户判断正确：要改前端主 JS）。
- 主 JS `public/assets/index-Bm9aiG71.js` 中 `wn()` 组合函数里 `u = w(!0)`（searchEnabled 默认 true），且 `<router-view>` 渲染 UcPage 时不传 prop 覆写 → 搜索框始终显示。

### 怎么改
1. `wn()` 中 `u=w(!0)` → `u=w(!1)`（默认禁用搜索）
2. 同步函数 `x(e)` 中 `u.value=t.search_enabled!==!1` → `u.value=t.search_enabled===!0`（只有服务端**显式 true** 才启用，杜绝意外打开）
3. `public/index.html` 注入 CSS 兜底：`.search-section,.search-input-row{display:none!important}`（双保险）

### 结果
- 服务器文件已确认两处修改（grep 验证 `u=w(!1)` / `===!0`）；CDN 缓存需带 `?nocache=` 绕过才能看到新 JS。
- 站点标题同步改为「盘达 pandel」（index.html title + meta site_title）。

---

## 二、今日密码自动生成「真正生效」（核心大修，用户反馈"功能没生效"）

### 为什么（三层根因，服务器日志铁证）
1. **UTC 日期 bug**：`new Date().toISOString()` 返回 UTC 日期。北京时间 00:00 时 UTC 还是前一天 → 定时器认为"今天已生成"直接跳过 → 每天都不生成。
2. **同名冲突**：夸克不允许同名文件夹重复创建，`quarkRunDaily` 每次都"创建文件夹" → 报 `file is doloading[同名冲突]`（HTTP 400）。
3. **夸克上传协议 2025 改版**：预上传响应**不再返回 region**，只有 `bucket` + `upload_url:http://pds.quark.cn` + `auth_info`。旧代码拼 `{bucket}.{region}.aliyuncs.com` → `ul-sz.undefined.aliyuncs.com` DNS 解析失败（`fetch failed`）。同时分享接口改为**异步任务**（返回 task_id 需轮询拿 share_id）。

### 怎么改（参照 GitHub kong-hen/cloud_driver_sdk 权威实现，重写 `server/quark-auto.js`）
1. 新增 `dateStrCN()`（+8h 后再取日期），quark-auto.js / server.js 全部改用北京时间。
2. 建文件夹前先 `findFolderId()` 查同名复用 fid；上传前 `findFileFid()` 删旧 zip。
3. 重写上传链路为夸克新版协议：
   - `update/hash`（md5/sha1 秒传检查）
   - `upload/auth` 请求体带 `auth_info`；auth_meta canonical **带 bucket 前缀** + `x-oss-date` + `x-oss-user-agent`
   - PUT 到 `https://{bucket}.{upload_url去协议}/{obj_key}`（即 `ul-sz.pds.quark.cn` → CNAME 阿里云深圳 OSS；裸 `pds.quark.cn` NXDOMAIN 解析不了）
   - `upload/finish` 完成 → fid
4. 分享重写：`/1/clouddrive/share` 返回 task_id → 轮询 `/1/clouddrive/task`（status=2 成功）拿 share_id → `/1/clouddrive/share/password` 拿 share_url。

### 结果（服务器真实 Cookie 端到端实测通过）
- **2026-08-16 今日密码 2635，分享链接 https://pan.quark.cn/s/329c63db079e（HTTP 200 可访问）**
- 已持久化到 `data/daily_passwords.json`（codes/shares/state 结构）
- 服务重启后 30 秒补跑：日志确认"今日密码无需生成（全部已存在）"——幂等生效

---

## 三、分享结构与命名修正（用户明确要求的嵌套结构）

### 为什么
用户明确指出：真实结构应为 **文件夹「日期+解析下载密码」→ 内含 zip → zip 内含两个文件夹**，且真实密码只存在于 txt 文件内容中，绝不出现在任何文件名上。旧实现分享的是 zip 文件本身、zip 内结构也不对。

### 怎么改（quark-auto.js）
1. 外层文件夹名：`${dateStr}解析下载密码`（如 `2026-08-16解析下载密码`）
2. **分享对象 = 外层文件夹**（`fid_list:[folderId]`），用户打开分享先见文件夹 → 点进去才是 zip
3. `makeZip()` 重写为双文件夹结构：
   - `(日期)密码/` → `password.txt`（内容：`今日解析密码：xxxx`，**密码只在这**）
   - `问题可反馈，小网站维持不易，多多体谅/` → `说明.txt`（反馈引导）
4. 修复 zip 中文文件名 UTF-8 编码 bug：**Central Directory Header 的 general purpose flag 必须写在 offset 8**（旧代码写在 offset 6，ASCII 名看不出、中文名必乱码）——`zipfile` 验证 `bad: None`，中文路径完整读出。

### 结果
`makeZip('2635','2026-08-16')` 解包验证：
```
2026-08-16密码/
2026-08-16密码/password.txt          → 今日解析密码：2635
问题可反馈，小网站维持不易，多多体谅/
问题可反馈，小网站维持不易，多多体谅/说明.txt
```

---

## 四、任务换绑问题（用户问：中途换绑定网盘，用户端密码/任务会变吗）

### 结论：**是，是** —— 用户端密码跟随新绑定，用户端看到的任务还是那一个。

### 依据（代码实锤）
1. **任务还是那一个**：`/api/daily-tasks/today` 返回的任务 `id` 不变（`tasks.json` 中任务位固定 9 个），只有 `task_provider` / `provider_name` 字段变化。
2. **密码实时跟随**：前端 `oh()`（打开任务弹窗）**每次强制 `await xm()` 重新拉服务器**（不读 localStorage 缓存）；后端 `/api/daily-tasks/today` 每次实时读 `dailyTasks`；`/api/daily-tasks/complete` 校验 `task.task_provider` 对应的今日密码（`loadDailyPasswords()` 实时读盘）→ 换绑后验证密码立即变为新网盘的今日密码。
3. 前端 localStorage 缓存（`pandl_daily_tasks_cache`）仅按天兜底首屏，打开弹窗必然刷新，不会让用户看到旧绑定。

---

## 五、新增：移动云盘 / 迅雷 每日密码自动生成器

### 为什么
用户要求把这两个网盘的自动生成做出来（DAILY_PWD_GENERATORS 原只有夸克）。

### 怎么改（quark-auto.js 新增两个生成器 + server.js 注册）
1. `mcloudRunDaily(token)`：参照 SDK Yun139 协议
   - 凭证 = yun.139.com 的 **Basic Token**（Authorization 头，可带 Basic 前缀；与解析用的网页 Cookie 不同，后台已加提示）
   - 建文件夹（`hcy/file/create` type:folder，同名复用）→ 删旧 zip → 上传（`hcy/file/create` SHA256+partInfos → PUT uploadUrl → `hcy/file/complete`）→ 分享（`getOutLink`，`caIDLst:[folderId]` 分享文件夹）
2. `xunleiRunDaily(cookie)`：参照 Google Drive 风格协议（api-pan.xunlei.com）
   - 凭证 = 网页 Cookie（须含 device_id，后台已加提示）
   - 建文件夹（`drive/v1/files` kind:folder）→ 删旧 zip → 创建上传任务（`upload_type:UPLOAD_TYPE_RESUMABLE` 拿 upload_url）→ PUT 上传 → 分享（`drive/v1/share` + 轮询 share_id → 取 share_url）
3. `server.js`：`DAILY_PWD_GENERATORS = { quark, mcloud, xunlei }`；require 同步导入。

### 结果
- 代码就绪并部署；因服务器**未配置**这两个网盘的凭证，无法端到端实测（后台会显示"未配置 Cookie，跳过"或失败原因，配置后点「补跑失败项」即可）。
- ⚠️ 真实凭证验证待用户提供 Cookie 后执行（逻辑与夸克同构，协议对齐 SDK，风险可控）。

---

## 六、后台防误触 + 失败提醒（用户 2026-08-16 强调）

### 为什么
原设计有"重新生成"按钮会**删除今日记录**——若今日已成功，误触 = 作废已发分享。用户要求：成功项绝不动，失败必须醒目提醒。

### 怎么改
1. `runDailyPasswordJob()` 幂等强化：`state.status==='ok'` 的网盘**绝不重新生成**（记录 skipped「今日已生成成功，幂等沿用」）；只有未生成/失败的补跑。
2. `/api/admin/daily-password/run`：改为只补跑失败项，成功项不动；返回 `failed_total`。
3. 后台 UI（admin.html）：去掉"重新生成"，改为**仅当今天有失败项**才显示的红色横幅「⚠️ 今日密码自动程序有 N 个网盘生成失败」+ 每网盘状态徽章（ok/error/未生成）+ 失败原因 + 「补跑失败项」按钮。
4. `saveSettings` 同步 await 生成任务，把 `daily_pwd_run` 回给前端；有失败直接 alert 红字。
5. 修复：`saveTodayPassword` 需从 quark-auto.js **导出**（曾漏导出 → ReferenceError，服务器日志抓到）。

### 结果
本地 + 生产实测：假 Cookie 触发失败 → state.status=error + 错误原因；模拟成功 → 补跑返回"没有需要补跑的网盘"、`generated:[]`。

---

## 七、精简与漏洞修复（全局自检）

### 为什么
用户要求：删 100% 确认无效的死代码、修明显漏洞、不破坏任何核心功能与交互。

### 怎么改
1. **删除重复路由**（后出现的永远执行不到 = 死代码 + 契约错误）：
   - `/api/search/auth/unlock`（旧版 1770 保留，1931 新版无 `ok` 字段删除）
   - `/api/search/auth/status`（1767 保留，1940 删除）
   - `/api/parse/verify-password`（1753 保留，1959 删除）
2. **补缺失路由**（前端调用但后端 404）：
   - `/api/encode`（扫码跳转中介，前端 cf() 消费）
   - `/api/scan-status`（扫码轮询）
   - `/api/search/parse-admin-exempt`（管理员豁免）
   - `/api/hot-searches`（热搜上报）
   - `/api/search`（聚合搜索 → 已禁用返回空结果，防前端报错）
3. **删死代码**：`LARGE_FILE_THRESHOLD`、`DEFAULT_SIZE_CAP`（无引用常量）、`zlib` require（未使用）。
4. **删陈旧文件**：`public/admin.6c22cfed.js`（旧版后台产物，admin.html 已单文件内联，无任何引用；本地+服务器都删）。
5. **后台 Cookie 提示文案**：区分 mcloud（Basic Token）/ xunlei（含 device_id）/ 其余（网页 Cookie）。

### 结果
- `node --check` 全部通过；本地冒烟测试所有新路由返回正确 JSON；部署后生产环境逐项 curl 验证通过。
- 未删除任何仍被引用的函数（quarkSave/quarkPoll/ucSave/ucPoll/quarkDelete/pendingSaves 等均为转存清理链路的活跃代码，保留）。

---

## 八、部署记录

| 文件 | 服务器路径 | 说明 |
|---|---|---|
| server/server.js | /home/ubuntu/app/coolink/server/ | 路由/生成器注册/精简 |
| server/quark-auto.js | 同上 | zip 结构/上传协议/新增生成器 |
| public/admin.html | /home/ubuntu/app/coolink/public/ | 后台 UI（重建后 166KB 单文件） |
| public/assets/index-Bm9aiG71.js | /home/ubuntu/app/coolink/public/assets/ | 搜索禁用 |
| public/index.html | /home/ubuntu/app/coolink/public/ | CSS 兜底 + 标题 |
| public/admin.6c22cfed.js | 已删除 | 陈旧产物 |

- 部署命令：逐文件 `rsync -avz -e "ssh -i ~/Documents/机密文件/服务器/key.pem -o StrictHostKeyChecking=no"` → `sudo systemctl restart pandl.service`
- 验证：`systemctl is-active` = active；生产 curl 逐接口通过；今日密码 2635 分享链接可访问。

---

## 九、遗留与下一步

1. **移动云盘 / 迅雷**：代码已接入，需用户提供对应网盘凭证后点「补跑失败项」实测（后台会显示失败原因）。
2. 服务器夸克网盘根目录留有历史 `2026-08-15今日密码` 旧文件夹（UTC bug 产物），可手动清理。
3. 百度/UC/123盘 的自动生成器未接入（本次仅按用户要求做了夸克/移动/迅雷）；协议同构，后续可快速扩展。

## 2026-08-16 03:00 —— settings.json 加密 + Cookie 过期检测告警

### 为什么改
- 后台 `data/settings.json` 一直是**明文存盘**（含各网盘会员 Cookie）：服务器文件一旦被读取，运营者全部网盘账号即泄露。用户要求堵住这个服务器侧泄露点。
- Cookie 会过期（夸克 __puus、百度 BDUSS 等均有有效期），用户点击解析时才发现"下不了"体验差。用户要求主动检测 + 告警。

### 怎么改
1. **AES-256-GCM 加密**：密钥由 `ADMIN_PASSWORD` 经 scrypt 派生（固定 salt 保证重启可解密）；文件格式 `{enc, v, data}`；`loadSettings` 解密、`saveSettings` 加密写盘；旧明文文件启动时自动备份为 `settings.json.plain.bak` 后加密落盘；解密失败保留磁盘文件并写 `settings_err` 日志（不覆盖不崩溃）。
2. **新模块 `server/cookie-check.js`**：夸克/UC 用 file/sort（失效码 40001/10000/31001/401/403）、百度用 uinfo（errno -6/-12/6）、迅雷用 drive/v1/files（error_code 3/5/401/403）检测；123盘/移动盘无可靠检测接口 → 返回 skip 不误报。
3. **触发时机**：每日 01:25-01:35 定时检测（防重复）；服务启动 60 秒后首检；解析失败且错误信息含 Cookie/登录/鉴权字样时实时检测对应盘。
4. **告警**：判定失效 → 后台日志 `cookie_warn` + 可选 webhook（环境变量 `ALERT_WEBHOOK`，POST JSON）。

### 结果（生产实测）
- 服务器明文 settings 重启后自动迁移为加密（`enc:true`），`.plain.bak` 明文备份已生成。
- 启动检测日志：`cookie_check — 启动检测：1 个网盘 Cookie 全部有效`（真实夸克 Cookie 解密后检测正常）。
- 本地往返验证：加密写盘 → 重启 → 解密 → 后台保存新 Cookie → 再次解密读取，全链路无丢失。
- 服务 active，今日密码/解析功能不受影响。
