# Cool Link 网盘直链解析站 —— 项目全记录与迁移手册

> 最后更新：2026-08-15
> 项目性质：网盘直链代解析站（合法，用户贴自己的分享链接，站方用自己 Cookie 解析）
> 前端自研 + 后端自研兼容层

---

## 一、项目是什么

| 项 | 说明 |
|---|---|
| 定位 | 网盘直链解析 + 下载器推送（Gopeed/aria2/Motrix） |
| 变现模式 | 网盘联盟 CPA：用户做「口令任务」（去指定网盘 App 保存推广资源包）→ 解锁额度/密码 → 下载 |
| 前端 | **自研打包资源**（index.html + /assets/*.js + app.css），交互一致 |
| 后端 | Node.js 零依赖（原生 http + fetch），`server/server.js` 单文件 |
| 数据存储 | 内存（设备额度/日志）+ `data/tasks.json`（任务配置持久化） |

### 核心目录结构

```
coolink/
├── server/
│   ├── server.js          # 唯一后端（API + 静态托管 + 解析逻辑）
│   └── tools/qrcode.js    # 零依赖二维码生成（SVG）
├── public/
│   ├── index.html         # 首页
│   ├── admin.html         # 自研精简后台（隐蔽路径访问）
│   ├── admin.js           # 后台逻辑（ESM）
│   ├── style.css          # 后台样式
│   ├── vendor/vue.esm-browser.prod.js  # Vue 3.5.13 full 版（含编译器）
│   └── assets/            # 打包资源（8 个 chunk + css）
├── data/tasks.json        # 每日任务配置（后台可管理）
├── tools/rotate-password.js  # 密码轮换工具
├── docs/monetization-plan.md  # 变现方案
├── start.sh               # 本地启动脚本
├── README.md / BLUEPRINT.md
└── 备份：coolink-backup-1832/（早期自研 UI 版，已弃用）
```

---

## 二、当前线上部署（2026-08-15）

### 服务器（即将迁移，勿依赖）

| 项 | 值 |
|---|---|
| 服务器 | 腾讯云轻量 `115.159.226.161`（Ubuntu 24.04，2核2G，40G 盘） |
| SSH 密钥 | 本地 `~/Documents/机密文件/服务器/key.pem`（**迁移时必须带走**） |
| SSH 登录 | `ssh -i "~/Documents/机密文件/服务器/key.pem" ubuntu@115.159.226.161` |
| 应用目录 | `/home/ubuntu/app/coolink` |
| 服务 | systemd `pandl.service`（Node 3000 端口，开机自启 + 崩溃重启） |
| Nginx | 80 → 127.0.0.1:3000 反向代理（`/etc/nginx/sites-available/pandl`） |
| 隧道 | Cloudflare Tunnel `cloudflared` 服务（token 在 `/etc/cloudflared/token`） |

### 域名（即将换）

| 项 | 值 |
|---|---|
| 当前域名 | `wici.cc.cd`（DNSHE 免费注册的 .cd 根域，已 NS 托管到 Cloudflare） |
| Cloudflare | 免费版，NS：`lola.ns.cloudflare.com` / `matias.ns.cloudflare.com` |
| 隧道名 | AIMX（tunnel id `5b309055-1ad4-4395-b1a5-cf90ef8c1886`） |
| 访问 | `https://wici.cc.cd`（前台）/ `https://wici.cc.cd/panel-5436e43b`（后台） |

### 后台凭据（重要！）

| 项 | 值 | 备注 |
|---|---|---|
| 后台地址 | `/panel-5436e43b` | 环境变量 `ADMIN_PATH`，隐藏路径，前端无入口 |
| 后台密码 | 见服务器 systemd 环境变量 `ADMIN_PASSWORD` | 原文已从文档移除（防仓库泄露），存于 `PROJECT-DOC.md.bak` 本地备份 |
| 前台解析密码 | `1234`（demo） | 后台站点设置可改 |

---

## 三、完整迁移手册（换服务器 / 换域名）

### A. 迁移到新服务器（5 步）

```bash
# 1. 装环境（Ubuntu 24.04 推荐）
sudo apt update && sudo apt install -y git nginx
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - && sudo apt install -y nodejs

# 2. 上传代码（本地执行，改 IP 和密钥路径）
rsync -avz -e "ssh -i '密钥路径.pem'" \
  /Users/aimx210/WorkBuddy/Claw/coolink/ \
  ubuntu@新IP:~/app/coolink/

# 3. systemd 服务（含后台凭据环境变量）
sudo tee /etc/systemd/system/pandl.service > /dev/null <<'EOF'
[Unit]
Description=PandL Demo (网盘直链解析)
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/app/coolink/server
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=3
Environment=NODE_ENV=production
Environment=ADMIN_PASSWORD=换成你的新密码
Environment=ADMIN_PATH=/panel-新随机路径

[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload && sudo systemctl enable pandl && sudo systemctl start pandl

# 4. Nginx 反代
sudo tee /etc/nginx/sites-available/pandl > /dev/null <<'EOF'
server {
    listen 80;
    server_name _;
    client_max_body_size 50m;
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_read_timeout 120s;
    }
}
EOF
sudo ln -sf /etc/nginx/sites-available/pandl /etc/nginx/sites-enabled/pandl
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl restart nginx

# 5. 验证
curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:3000/   # 期望 200
```

### B. 换域名（3 种情况）

**情况 1：新域名是根域（如 xxx.com / xxx.xyz）**
1. 注册 Cloudflare 账号 → Add site 新域名 → Free 计划 → 复制 2 个 NS
2. 去注册商把 NS 改成 Cloudflare 的 → 等激活（5-30 分钟）
3. 在 Cloudflare → Networks → Tunnels → AIMX → Public Hostname，把 `wici.cc.cd` 改成新域名（或新增一条）

**情况 2：新域名是二级域下的子域（如 xxx.cc.cd 之类）**
> ⚠️ 注意：Cloudflare 只接受「根域」。`cou.l.cd` 这类被拒是因为 `l.cd` 在 PSL 里。
> 判断方法：在 Cloudflare Add site 输入域名，能通过就是根域，报错就是子域。

**情况 3：不用域名直接 IP 访问**
- 访问 `http://新IP:3000` 即可（需放行安全组端口），无 HTTPS
- 或保留 Cloudflare Tunnel 用 `trycloudflare.com` 临时地址（重启会变，仅测试用）

### C. 换域名后要改的地方

| 位置 | 改什么 |
|---|---|
| Cloudflare DNS | 确保新域名的 CNAME 指向 tunnel（Tunnel 创建时自动建） |
| Cloudflare Tunnel | Public Hostname 里加/改新域名 → `http://localhost:3000` |
| 服务器 Nginx | `server_name _` 已通配，无需改 |
| 后台 | 无硬编码域名，无需改 |

---

## 四、API 全清单（后端 server.js）

### 前台（前端消费，契约须严格对齐）

| 接口 | 方法 | 说明 |
|---|---|---|
| `/api/public/meta` | GET | 站点信息（启动必调，nav_links/site_title） |
| `/api/public/heartbeat` | POST | 心跳轮询 |
| `/api/{网盘}/share` | POST | 解析分享链接 → `{ok, result:{files}, data:{list,detail_info:{list},token_info:{stoken}}}` |
| `/api/{网盘}/detail` | POST | 文件夹详情（同 share 结构） |
| `/api/{网盘}/fetch` | POST | 取直链 → `{ok, data:{download_url, dlink, file_name}}` |
| `/api/uc/list` | POST | UC 网盘第一步（路径特殊：叫 list 不叫 share） |
| `/api/xunlei/restore-files` | POST | 迅雷第三步（路径特殊：叫 restore-files 不叫 fetch） |
| `/api/parse/verify-password` | POST | 验证解析密码 `{provider, password}` |
| `/api/ip-quota` | POST | IP 额度（今日次数/大小/单文件上限） |
| `/api/daily-tasks/today` | GET/POST | 每日任务列表（含 providers + promo_options 多网盘口令） |
| `/api/daily-tasks/complete` | POST | 标记任务完成 |
| `/api/daily-tasks/claim` | POST | 领取奖励（按 reward_type 发奖） |
| `/api/daily-tasks/reveal-answer` | GET/POST | 查看答案任务答案 |
| `/api/my-downloads` | POST | 我的下载记录 |
| `/api/downloader-push-log` | POST | 下载器推送日志（失败可退额度） |
| `/api/search/auth/status` `unlock` | GET/POST | 解锁状态/解锁 |

### 后台（自研精简后台消费）

| 接口 | 方法 | 说明 |
|---|---|---|
| `/api/admin/login` | POST | 登录（限流：5 次错锁 15 分钟；token 绑 IP + 12h） |
| `/api/admin/logout` | POST | 登出 |
| `/api/admin/auth-check` | GET | 鉴权检查 |
| `/api/admin/overview` | GET | 今日数据（解析成功/失败/活跃设备） |
| `/api/admin/settings` | GET/POST | 站点设置（密码/限额/6 网盘 Cookie/推广配置） |
| `/api/admin/logs` | GET | 操作日志 + 埋点 |
| `/api/admin/daily-tasks` | GET/POST | 任务列表 / 新增或更新任务 |
| `/api/admin/daily-tasks/{id}/delete` | POST | 删除任务 |
| `/api/admin/daily-tasks/reorder` | POST | 任务排序 |
| `/api/admin/daily-tasks/logs` | GET | 任务完成日志 |

---

## 五、任务系统（任务=奖励类型，完成方式=多网盘任选）

### 模型（data/tasks.json）

```json
{
  "id": "small_file",
  "type": "small_file",           // password | small_file | large_file | answer
  "icon": "📦",
  "title": "解锁小文件解析流量",
  "description": "选择任一网盘保存资源包，解锁小文件解析 +500MB 流量",
  "reward_type": "small_file_all_providers",   // 见下方枚举
  "reward_count": 500,             // MB 或 次数
  "providers": ["quark", "baidu", "pan123"],   // 完成方式：用户任选其一做口令任务
  "answer": ""                     // answer 任务的答案
}
```

### reward_type 枚举（契约）

| 值 | 含义 |
|---|---|
| `unlock_small_file` | 解锁小文件流量机制（一次性） |
| `unlock_large_file` | 解除单文件大小限制（一次性） |
| `small_file_all_providers` | 全部网盘小文件 +N MB |
| `small_file_single_provider` | 指定网盘小文件 +N MB（配 reward_provider） |
| `single_provider` | 指定网盘 +N 次（配 reward_provider） |
| `default` | 全部网盘 +N 次 |

> **核心机制**：每个任务关联多个网盘（providers），用户做**任意一个**网盘的口令任务 → 拿同样的任务奖励。这是变现核心——每次用户想解锁都要去网盘 App 保存推广资源包。

### 额度体系（四道墙）

| 墙 | 触发 | 解决方式 |
|---|---|---|
| 密码墙 | 未解锁下载 | 做「解锁下载权限」任务拿解析密码 |
| 小文件墙 | 小文件流量不足/未解锁 | 做「解锁小文件」任务（+500MB） |
| 大文件墙 | 大文件次数用完 | 做「每日签到」（+3次） |
| 大小墙 | 超过单文件上限（4GB） | 做「解除大小限制」任务（→20GB） |

---

## 六、已知坑与排障经验（重要！）

### 1. Vue ESM 必须用 full 版
- `vue.global.prod.js` 是 **runtime-only**（无模板编译器）→ 页面显示 `{{ xxx }}` 原文
- 必须用 **`vue.esm-browser.prod.js`**（含 compiler）+ `<script type="module">` 加载
- ESM 的 `.js` MIME 不能带 `charset=utf-8`（Chrome 拒绝），必须 `text/javascript`

### 2. 缓存策略（卡顿元凶）
- 之前全部 `no-cache` → 每次刷新重下 1.7MB → 卡顿
- 正确：HTML `no-cache`，JS/CSS 长缓存（`public, max-age=31536000, immutable`）
- 改代码后给资源加 `?v=版本号` 强制浏览器拉新版

### 3. Cloudflare 缓存错位
- 改文件后必须**清 Cloudflare 缓存**（Caching → Purge Everything）或访问加 `?v=` 参数
- `cf-cache-status: HIT` = 边缘缓存；`MISS` = 回源

### 4. 契约字段（容易踩）
- share 返回必须是**双结构**：`result:{files}`（百度）+ `data:{list, detail_info:{list}, token_info:{stoken}}`（夸克）
- 文件项要同时给：`{dir, fid, pdir_fid, file_name}`（夸克）和 `{fs_id, server_filename}`（百度）
- UC 第一步是 `/api/uc/list`（不是 share）；迅雷第三步是 `/api/xunlei/restore-files`（不是 fetch）
- daily-tasks/claim 用 `{task_id}`；complete 直接传 taskId 字符串

### 5. 后台安全
- 登录 Set-Cookie 的 `Path` 必须为 `/`（设成 ADMIN_PATH 会导致 /api/* 不带 cookie）
- adminSessionToken 是全局单例，登录会顶掉旧会话；token 绑 IP
- 登录限流按 IP（loginFails Map），5 次锁 15 分钟

### 6. rsync 目录陷阱
- rsync 前必须 `cd` 到项目根目录，否则会同步错误目录甚至清空服务器（曾发生）

### 7. 后台「显示严重 bug」排障
- 症状：后台显示 `{{ err }}` 原文、面板泄漏
- 原因：浏览器缓存了旧版 admin.html（普通 script + 旧 admin.js，引用 `Vue` 全局变量而新版不挂全局）
- 修复：ESM 化 + `?v=` 版本号 + 硬刷新

---

## 七、如何日常改代码 + 部署

```bash
# 本地改代码 → 同步到服务器 → 重启
cd /Users/aimx210/WorkBuddy/Claw/coolink
rsync -avz -e "ssh -i '/Users/aimx210/Documents/机密文件/服务器/key.pem'" \
  ./ ubuntu@115.159.226.161:~/app/coolink/
ssh -i "/Users/aimx210/Documents/机密文件/服务器/key.pem" ubuntu@115.159.226.161 \
  'sudo systemctl restart pandl'
```

> ⚠️ 改前端后记得：清 Cloudflare 缓存 + 给资源加 `?v=` 版本号
> ⚠️ 改后台密码：编辑 `/etc/systemd/system/pandl.service` 的 `ADMIN_PASSWORD=` → daemon-reload → restart

---

## 八、当前未完成 / 待办

| 事项 | 状态 |
|---|---|
| 夸克/百度真实 Cookie 配置 | ⏳ 待用户在后台填写（否则解析报「未配置 Cookie」） |
| 各网盘推广口令/链接/二维码 | ⏳ 待配置（变现核心，任务弹窗才有内容） |
| 百度/夸克真实解析验证 | ⏳ 配好 Cookie 后验证 |
| 网盘资源搜索（TG 频道聚合） | ❌ 暂不做（需 TG 频道数据源） |
| 其余网盘真实接入（迅雷/UC/123/移动） | ❌ 未接入（SUPPORTED_PROVIDERS 只有 quark/baidu） |
| 后台完整实现（AdminPage chunk） | ❌ 用自研精简后台替代 |

---

## 九、参考资源

- 参考站（同类网盘解析站）
- 反向工程源码（本地）（index 主逻辑 / scanLinkCmd 解析命令 / admin / app.css）
- 开源参考实现：
  - github.com/muyan556/gopeed-extension-quark（夸克直链）
  - github.com/code-hasaki/gopeed-extension-baiduwp（百度直链）
