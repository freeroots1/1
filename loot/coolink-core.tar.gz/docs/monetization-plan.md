# Cool Link 完整迁移 + 自动化变现方案

> 本文把参考站的架构与运作方式彻底吃透，并给出「一比一迁移 + 全自动化变现」的落地路线。
> 定位澄清：**这不是盗版站**。用户粘的是**自己上传**的网盘分享链接，网站用运营者自己的 Cookie 调网盘官方接口转成直链（代下服务）；变现靠**网盘官方联盟「转存 CPA」**，与盗版无关。

---

## 一、网站本质与合法边界

| 维度 | 说明 |
|---|---|
| 核心服务 | 网盘「直链解析 / 代下」：用户给分享链接，站点用**运营者自己的 Cookie** 调夸克/百度/移动云盘等官方接口，穿透出真实下载直链 |
| 资源来源 | 用户自己上传的分享链接，站点**不存储、不传播**任何资源 |
| 变现模式 | 网盘官方联盟「推广合伙人 CPA」：用户获取解析密码时，需扫码/复制口令去网盘**转存**运营者的推广分享，平台按转存/拉新结算佣金 |
| 合法性 | 全程调用网盘官方接口 + 官方联盟推广，不涉盗版、不涉灰产 |

---

## 二、完整架构（逆向实证）

前端 `Vue3 + Vite/Rolldown + Naive UI`，后端 `Node 原生 http`（零依赖），多 chunk 懒加载。

```
普通用户首屏        index chunk（搜索/解析/密码墙/下载）
运营侧懒加载        admin chunk（后台）/ scanLinkCmd chunk（扫链/每日任务/节点）
后端               Node 原生 http，接口全在 /api/*
```

### 完整 API 全景（逆向提取，已全部列出）

**主程序（用户侧）**
```
/api/search                      多网盘资源搜索（聚合）
/api/search/parse-verify-status  解析前置校验（是否需解锁）
/api/search/parse-admin-exempt   管理员豁免墙
/api/search/auth/status|unlock   查询/提交解析密码解锁
/api/search/reveal-links         穿透防盗链 → 真实直链 + 提取码
/api/search/check-links          校验直链有效性
/api/search/track-action         埋点（关键词/来源/成败）
/api/encode /api/hot-searches   短链 / 热搜
/api/qrcode                      生成二维码（扫码获取密码）
/api/scan-status                 扫链状态
```

**扫链/任务/节点（scanLinkCmd chunk）**
```
# 各网盘解析三件套（share→fetch→detail）
/api/{quark,baidu,mcloud,pan123,uc,xunlei}/{share,fetch,detail}
/api/parse/verify-password       密码校验（独立入口）
/api/daily-tasks/{today,claim,complete,reveal-answer}
/api/admin/daily-tasks/*         任务 CRUD / 日志 / 排序
/api/my-downloads /api/ip-quota /api/downloader-push-log
```

**管理后台（admin chunk）**
```
/api/admin/{login,auth-check,overview,trend,settings,logs,...}
/api/admin/search/{plugins,tg-channels,kdocs-docs}  搜索源 CRUD+导入导出
/api/admin/baidu/*               百度账号维护：check-accounts / login-proxy / mars / outbound-proxy / qr/start|poll|cancel / auto-maintain
/api/admin/pan123/login          123盘登录
/api/parse/scan-guide            扫码引导
/api/public/{heartbeat,meta}
```

---

## 三、变现闭环（吃透核心，源码实锤）

**一句话闭环**：解析免费（诱饵）→ 下载卡密码墙 → 密码藏在网盘推广分享里 → 用户扫码/口令去网盘**转存** → 联盟结算佣金 → 回填密码解锁下载 → 次日重置再转存。

### 3.1 密码墙的真实形态（不是"输密码"，是"扫码/口令转存"）

源码文案证据：
- 「请用夸克网盘 App 扫一扫获取解析密码」/「请用百度网盘 App 扫一扫」/「请用中国移动云盘 App 扫一扫」
- 「请复制网盘口令到夸克网盘获取解析密码」/「复制上面的口令到网盘获取解析密码」
- 二维码组件 `扫码获取解析密码`（200×200），口令由 `/api/qrcode` 或后台配置生成
- 「暂无扫码链接，请先在后台配置」→ 后台可配置各网盘的**口令 + 二维码链接**
- 「服务端未配置该网盘解析密码，请检查后台各网盘限流中的解析密码设置」
- 「转存分享文件失败」→ 用户必须**转存**（这就是 CPA 转化动作）
- 「检测到该网盘解析密码已更新，请重新输入解析密码」→ 密码定期轮换

### 3.2 密码获取 → 转存 → 佣金 的完整链路

```
运营者（网盘联盟合伙人）
  └ 在联盟后台拿到「推广口令 / 推广分享链接」（带追踪 UID）
  └ 把「4 位解析密码」写进 txt/压缩包，上传到自己网盘，生成带追踪的分享
  └ 在网站后台配置：各网盘的「口令 + 二维码链接 + 解析密码」

用户侧
  └ 搜资源（免费看）→ 解析（免费出直链）→ 点下载 → 卡密码墙
  └ 密码墙展示：二维码（扫码打开网盘分享）+ 口令（复制去网盘 App）
  └ 用户扫码/复制口令 → 打开网盘 App → 转存分享文件 → 解压得 4 位密码
  └ 网盘后台判定有效转存/拉新 → 结算佣金
       老用户转存 0.3~0.85 元/次；新用户拉新 5.5~13 元/单；会员分成 30%~60%
  └ 回填密码 → 解锁当日额度 → 下载直链 → 次日重置 → 再转存 → 再赚
```

### 3.3 防刷（联盟合规关键）

- 设备指纹：`X-Device-Id` / `X-Machine-Key` / `X-Legacy-Device-Id`（SHA-256 哈希）
- 请求签名：`X-Req-Ts` + `X-Req-Nonce` + `X-Req-Sign`（HMAC-SHA256）
- 手机环境检测：「未检测到可信手机环境，请用真实手机扫码验证」「当前电脑无法伪装成手机」（`mobile_signals_*`）
- 密码错误限次：「解析密码错误次数过多（已达 N 次），请刷新页面后再试」

### 3.4 每日任务（额度钩子，变现放大器）

任务类型枚举（源码实锤）：
```
small_file_all_providers    解锁全平台小文件流量
small_file_single_provider  解锁指定网盘小文件流量
unlock_small_file / unlock_large_file  解除小/大文件锁
answer                      答题任务
external_link               外部链接任务（去网盘保存）← 变现钩子
parse-password-qrcode       扫码任务（最高频）← 变现钩子
```

闭环：做任务（去网盘保存/扫码）→ claim → 额度 +N → 继续解析 → 次日重置 → 再保存 → 再赚。

---

## 四、自动化运行方案（全自动流水线）

### 4.1 总体架构

```
┌─────────────────────── 定时调度（cron / launchd / node-cron）───────────────┐
│  ① 密码轮换任务        ② 推广码/口令维护      ③ 网盘账号健康检查             │
│    生成新4位密码          拉取联盟推广口令        探测各网盘 Cookie 是否失效   │
│    打包→上传网盘          写入后台配置            失效→告警/自动重新登录       │
│    更新后台解析密码       让口令出现在任务/密码墙                             │
└──────────────────────────────────────────────────────────────────────────┘
```

### 4.2 关键自动化环节

1. **自动上传密码**
   - 定时（每天/每 N 小时）生成新 4 位解析密码
   - 写成文本/压缩包，用网盘官方上传 API 自动传到自己的夸克/移动云盘
   - 生成新的分享链接 + 口令 → 写回后台 `siteSettings` 各网盘「口令/二维码/密码」
   - 前端密码墙自动读最新配置

2. **推广码获取与展示**
   - 运营者在联盟后台生成「推广口令」（带追踪 UID），或联盟 API 拉取
   - 配置到：① 密码墙（扫码/口令）② 每日任务 `external_link` / `parse-password-qrcode`
   - 前端渲染成二维码 + 口令文案，引导用户转存

3. **任务关联推广**
   - 每日任务数据源改为「带推广链接」的配置
   - `external_link` 任务点击 → 跳转推广分享链接 → 用户保存 → 转存计数

4. **账号健康 / 风控**
   - 定时探测各网盘 Cookie（token/sharepage 探测）
   - 失效 → 告警（TG/邮件）+ 触发二维码重新登录流程（参考 `/api/admin/baidu/qr/start|poll`）

---

## 五、迁移实现路线

### 已完成（coolink）
- Vue3 + emerald/slate 主题、夸克/百度真实解析、解析免费/下载弹四道墙、localStorage Cookie、每日任务→额度闭环、aria2 JSON-RPC 推送、埋点、热搜、后台 admin、文件夹树形结构

### 待实现（按优先级）
1. **密码墙升级为「扫码/口令」模式**（本轮核心）
   - 后台配置各网盘「口令 + 二维码链接 + 解析密码」
   - `/api/qrcode` 生成二维码
   - 前端密码墙改弹「二维码 + 口令」，替代纯输密码（保留 demo 输入兜底）
2. **每日任务关联推广链接**
   - 任务数据带 `promoUrl`（推广分享链接）
   - `external_link` / `parse-password-qrcode` 任务点击跳转
3. **自动上传密码脚本**
   - `tools/rotate-password.js`：生成密码 → 上传网盘 → 更新配置
   - `tools/sync-promo.js`：拉取/配置推广口令
   - 用 cron / launchd 定时调度
4. **账号健康探测 + 风控**
   - 各网盘 Cookie 失效探测 + 告警

---

*本文仅做技术架构映射与合法网盘联盟推广学习，不涉及任何资源获取/传播。*
