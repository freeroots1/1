#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 从 Playwright profile（可信设备）抓取迅雷最新 credentials
# RT 失效时由 server.js 调用，获取新 AT/RT 完成自动续期（免验证码）
import json
import sys

from playwright.sync_api import sync_playwright

PROFILE = "/home/ubuntu/xunlei-browser/profile"
KEY = "credentials_Xqp0kJBXWhwaTpB6"


def main():
    with sync_playwright() as p:
        ctx = p.chromium.launch_persistent_context(
            PROFILE,
            headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage"],
        )
        page = ctx.new_page()
        page.goto("https://pan.xunlei.com/", wait_until="domcontentloaded", timeout=45000)
        page.wait_for_timeout(5000)
        creds = page.evaluate("() => localStorage.getItem('%s') || ''" % KEY)
        ctx.close()

    if not creds:
        print(json.dumps({"error": "no_credentials"}))
        return 1
    try:
        d = json.loads(creds)
    except Exception as e:
        print(json.dumps({"error": "parse_failed:%s" % e}))
        return 1
    at = d.get("access_token", "")
    rt = d.get("refresh_token", "")
    if len(at) > 200 and rt:
        print(json.dumps({"access_token": at, "refresh_token": rt}))
        return 0
    print(json.dumps({"error": "invalid_credentials"}))
    return 1


if __name__ == "__main__":
    sys.exit(main())