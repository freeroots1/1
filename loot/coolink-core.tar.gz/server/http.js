// =====================================================================
//  lib/http.js — 网盘 HTTP 请求封装（2026-08-19 从 server.js 渐进拆分 Step 2）
//  仅含请求封装 + API 常量 + 会话内 cookie 续期；逻辑与拆分前完全一致
// =====================================================================
'use strict';

// 2026-08-19 调优：全局外部请求超时（防网盘 API 卡死 hang 住整个请求）
// 默认 15 秒；超时抛错，由调用方 catch 处理（失败提示重试）
const FETCH_TIMEOUT_MS = 15000;
function fetchTimeout(url, init = {}, timeoutMs = FETCH_TIMEOUT_MS) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  const merged = { ...init, signal: ctrl.signal };
  return fetch(url, merged).finally(() => clearTimeout(timer));
}

const QUARK_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) quark-cloud-drive/2.5.20 Chrome/100.0.4896.160 Electron/18.3.5.4-b478491100 Safari/537.36 Channel/pckk_other_ch';
const QUARK_API = 'https://pan.quark.cn';
const QUARK_DRIVE = 'https://drive-pc.quark.cn';

// 夸克：cookie 维护对象（单次解析会话内自动续期 __puus）
function refreshPuus(cookie, puusPart) {
  const parts = (cookie || '').split(';').map((s) => s.trim());
  const idx = parts.findIndex((c) => c.startsWith('__puus='));
  if (idx >= 0) parts[idx] = puusPart;
  else parts.push(puusPart);
  return parts.join('; ');
}


async function quarkRequest(method, url, data, cookieRef) {
  // 2026-08-19 用户需求：解析阶段不调 Cookie（分享页 token/detail 为公开接口）。
  // 仅当调用方传了 cookie 才带 Cookie 头；未配置时列表接口照常工作，
  // 只有下载/转存类接口在真正需要登录态时才要求（由调用方在 fetch 阶段保证 cookie 存在）。
  const headers = {
    'User-Agent': QUARK_UA,
    Referer: `${QUARK_API}/`,
    Origin: QUARK_API,
    'Content-Type': 'application/json;charset=UTF-8',
  };
  if (cookieRef && cookieRef.value) headers.Cookie = cookieRef.value;
  const init = { method, headers };
  if (method === 'POST' && data) init.body = JSON.stringify(data);
  const resp = await fetchTimeout(url, init);
  const setCookies = typeof resp.headers.getSetCookie === 'function' ? resp.headers.getSetCookie() : [];
  for (const sc of setCookies) {
    if (sc && sc.startsWith('__puus')) {
      if (cookieRef) cookieRef.value = refreshPuus(cookieRef.value, sc.split(';')[0]);
      break;
    }
  }
  const body = await resp.json();
  if (body.code === 40001 || body.code === 10000) {
    throw new Error('夸克 Cookie 已失效或登录过期，请重新在浏览器复制完整 Cookie（含 __puus）');
  }
  if (body.code && body.code !== 0) {
    if (body.code === 32003) {
      throw new Error('夸克网盘容量不足（capacity limit）。已默认走「免转存」模式，若仍报此错说明该资源走了转存回退，请清理网盘空间或开通会员');
    }
    throw new Error(`夸克接口错误 ${body.code}: ${body.message || ''}`);
  }
  return body;
}


function parseQuarkUrl(url, passcodeOverride) {
  // 2026-08-19 全局一致性：前端把 ?pwd= 拆出单独放 body.pass_code（同 Baidu/pan123/UC 契约），
  //   此处优先用显式传入的 pass_code，避免带提取码的夸克分享进不去
  let passcodeFromBody = (passcodeOverride || '').toString().trim();
  let clean = (url || '').replace(/\[.*?\]/g, '').trim();
  // 兼容 URL 编码输入（前端可能 encodeURIComponent 后传输，如 https%3A%2F%2F...）
  if (/^https?%3a|%2f/i.test(clean)) {
    try { clean = decodeURIComponent(clean); } catch {}
  }
  // 2026-08-16：适配「夸克 App 分享口令文本」——用户复制的是整段话，不是纯链接。
  // 从任意文本里提取夸克分享链接（容忍前后多余文字/换行/引号），提取不到才整段当 ID 试
  const linkM = clean.match(/https?:\/\/[^\s，。；、""''【】\]]*quark\.cn\/[^\s，。；、""''【】\]]*/i);
  if (linkM) clean = linkM[0];
  let pwdId = '', passcode = passcodeFromBody, pdirFid = '';
  const idM = clean.match(/\/s\/([a-zA-Z0-9]+)/);
  if (idM) pwdId = idM[1];
  else if (clean.length > 10 && /^[a-zA-Z0-9]+$/.test(clean)) pwdId = clean;
  // body.pass_code 优先；否则从 URL ?pwd= 取
  if (!passcode) {
    const pwM = clean.match(/[?&](pwd|password|pw)=([a-zA-Z0-9]{1,8})/i);
    if (pwM) passcode = pwM[2];
  }
  // 口令文本常见格式「提取码：abcd」/「访问码 abcd」（链接里没带 pwd 时兜底）
  if (!passcode) {
    const pwTxt = (url || '').match(/提取码[:：]?\s*([a-zA-Z0-9]{1,8})|访问码[:：]?\s*([a-zA-Z0-9]{1,8})|口令[:：]?\s*([a-zA-Z0-9]{1,8})/i);
    if (pwTxt) passcode = pwTxt[1] || pwTxt[2] || pwTxt[3] || '';
  }
  const dirM = clean.match(/#\/list\/share\/([a-zA-Z0-9]+)/);
  if (dirM) pdirFid = dirM[1];
  if (!pwdId) throw new Error('无法从链接解析出夸克分享 ID（应为 https://pan.quark.cn/s/xxxx）');
  return { pwdId, passcode, pdirFid };
}

// 夸克：递归列出分享内所有文件/文件夹，返回树形结构
// recursive=false（2026-08-19）：只列指定层（share 根层 / detail 进入文件夹时用），
//   保持原有文件结构——文件夹行前端显示「进入文件夹」可点击，文件行才显示下载

const BAIDU_API = 'https://pan.baidu.com';

async function baiduRequest(method, url, formBody, cookie) {
  // 2026-08-19 用户需求：解析阶段不调 Cookie。wxlist/tplconfig 为公开接口，
  // 仅 sharedownload（下载阶段）才真正需要 BDUSS；未配置时公开列表照常可用。
  const headers = {
    'User-Agent': 'netdisk',
    Referer: 'https://pan.baidu.com/disk/home',
    'Content-Type': 'application/x-www-form-urlencoded',
  };
  if (cookie) headers.Cookie = cookie;
  const resp = await fetchTimeout(url, { method, headers, body: formBody });
  const data = await resp.json();
  if (data.errno && data.errno !== 0) {
    throw new Error(`百度接口错误 errno=${data.errno}: ${data.errmsg || data.message || ''}`);
  }
  return data;
}



const UC_API = 'https://pc-api.uc.cn';
const UC_DRIVE = 'https://pc-api.uc.cn';
module.exports = {
  QUARK_API, QUARK_DRIVE, BAIDU_API, UC_API, UC_DRIVE,
  refreshPuus, quarkRequest, baiduRequest, parseQuarkUrl,
  fetchTimeout, FETCH_TIMEOUT_MS,
};
