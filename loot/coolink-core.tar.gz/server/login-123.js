// =====================================================================
//  providers/login-123.js — 123盘 账号密码登录（2026-08-19）
//  参考 AList 开源实现（github.com/alist-org/alist/drivers/123）：
//    SignIn = https://login.123pan.com/api/user/sign_in
//    请求体 { passport: 手机号, password, remember: true }（邮箱则 mail/type:2）
//    响应 data.token → 后续请求带 Authorization: Bearer <token>
//  方案：后台填账号密码 → 程序 sign_in 自动拿 token（token 过期自动重登）
// =====================================================================
'use strict';

const LOGIN_API = 'https://login.123pan.com/api/user/sign_in';
const API = 'https://yun.123pan.com/b/api';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36';

/**
 * 账号密码登录 123盘，返回 access_token
 * @param {string} username 手机号/邮箱/用户名
 * @param {string} password 密码
 * @returns {Promise<string>} token
 */
async function pan123SignIn(username, password) {
  if (!username || !password) throw new Error('123盘未配置账号密码');
  const isEmail = /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(username.trim());
  const body = isEmail
    ? { mail: username.trim(), password, type: 2 }
    : { passport: username.trim(), password, remember: true };
  const resp = await fetch(LOGIN_API, {
    method: 'POST',
    headers: {
      'User-Agent': UA,
      'Content-Type': 'application/json',
      Origin: 'https://yun.123pan.com',
      Referer: 'https://yun.123pan.com/',
      platform: 'web',
      'app-version': '3',
    },
    body: JSON.stringify(body),
  });
  const j = await resp.json().catch(() => ({}));
  if (j.code !== 200 && j.code !== 0) {
    throw new Error(`123盘登录失败: ${j.message || j.msg || ('code=' + j.code)}`);
  }
  const token = j.data && (j.data.token || j.data.access_token || j.data.accessToken);
  if (!token) throw new Error('123盘登录成功但未返回 token: ' + JSON.stringify(j).slice(0, 150));
  return token;
}

/**
 * 2026-08-19：用现有 token 换新 token（POST /b/api/user/refresh_token）
 * 绕开 sign_in 验证码风控——自动续期的核心途径
 * @returns {Promise<string|null>} 新 token
 */
async function pan123RefreshToken(token) {
  if (!token) return null;
  try {
    const resp = await fetch(`${API}/user/refresh_token`, {
      method: 'POST',
      headers: {
        'User-Agent': UA,
        'Content-Type': 'application/json',
        authorization: 'Bearer ' + token,
        platform: 'web',
        'app-version': '3',
        Origin: 'https://yun.123pan.com',
        Referer: 'https://yun.123pan.com/',
      },
      body: '{}',
    });
    const j = await resp.json().catch(() => ({}));
    if (j.code !== 0 && j.code !== 200) return null;
    const nt = j.data && (j.data.token || j.data.access_token || j.data.new_token);
    return nt && nt !== token ? nt : null;
  } catch {
    return null;
  }
}

/**
 * 验证 token 是否有效（调 /b/api/user/info）
 * @returns {Promise<boolean>}
 */
async function pan123CheckToken(token) {
  if (!token) return false;
  try {
    const resp = await fetch(`${API}/user/info`, {
      headers: {
        'User-Agent': UA,
        authorization: 'Bearer ' + token,
        platform: 'web',
        'app-version': '3',
        Origin: 'https://yun.123pan.com',
        Referer: 'https://yun.123pan.com/',
      },
    });
    const j = await resp.json().catch(() => ({}));
    return j.code === 200 || j.code === 0;
  } catch {
    return false;
  }
}

/**
 * 从 Cookie/旧格式 兼容提取 token（兼容历史配置：直接填 Bearer token 或 token=xxx）
 */
function extractToken(input) {
  const s = String(input || '').trim();
  // 直接是 Bearer token
  if (s.startsWith('Bearer ')) return s.slice(7).trim();
  // token=xxx 格式（AList 的 cookie 语义）
  const m = s.match(/token=([^;\s]+)/i);
  if (m) return decodeURIComponent(m[1].trim());
  // 纯 token（长度>20 且无分号）
  if (/^[A-Za-z0-9._-]{20,}$/.test(s)) return s;
  return '';
}

module.exports = { pan123SignIn, pan123CheckToken, pan123RefreshToken, extractToken, PAN123_API: API };
