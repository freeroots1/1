// =====================================================================
//  lib/utils.js — 纯工具函数（2026-08-19 从 server.js 渐进拆分 Step 1）
//  仅含无外部状态依赖的纯函数；逻辑与拆分前完全一致（零改动）
// =====================================================================
'use strict';

function quarkSenderCookie(fullCookie) {
  // 2026-08-20 修复：drive 节点直链（dl-pc-zb.drive.quark.cn）下载必须带 __puus（登录会话），
  //   仅 sender 白名单（__sdid/video-auth/__kuus/__uus）→ 412「Precondition Failed」→ Gopeed 下载失败。
  //   实测：__puus + sender 即可 200。用户需求「下载走我的账号」→ 白名单加入 __puus。
  const keep = ['__puus', '__sdid', 'video-auth', '__kuus', '__uus'];
  const parts = (fullCookie || '').split(';').map((s) => s.trim()).filter(Boolean);
  const picked = parts.filter((p) => keep.some((k) => p.toLowerCase().startsWith(k.toLowerCase() + '=')));
  return picked.join('; ');
}

function ucSenderCookie(fullCookie) {
  // 2026-08-20 修复：UC（drive.uc.cn）登录态 cookie 字段是 HMACCOUNT_BFESS/BDUSS_BFESS（百度系），
  //   旧白名单只认 __sdid/video-auth/__kuus/__uus → 下发为空。补上 UC 实际字段。
  const keep = ['HMACCOUNT_BFESS', 'BDUSS_BFESS', '__sdid', 'video-auth', '__kuus', '__uus'];
  const parts = (fullCookie || '').split(';').map((s) => s.trim()).filter(Boolean);
  const picked = parts.filter((p) => keep.some((k) => p.toLowerCase().startsWith(k.toLowerCase() + '=')));
  return picked.join('; ');
}

function dayStr(d = new Date()) {
  return d.toISOString().slice(0, 10); // YYYY-MM-DD
}

function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

function parseCookies(str) {
  const out = {};
  (str || '').split(';').forEach((c) => {
    const [k, ...v] = c.trim().split('=');
    if (k) out[k] = decodeURIComponent(v.join('='));
  });
  return out;
}

function flattenForShare(tree, files) {
  const out = [];
  // 直链映射：files 数组（fileNodes 已回填 url）按名字索引
  const urlMap = new Map();
  for (const f of files || []) if (f && f.url) urlMap.set(f.name, f.url);
  const walk = (nodes, parentId) => {
    for (const n of nodes || []) {
      const isDir = n.type === 'folder';
      // 2026-08-19 修：优先透传节点真实创建时间（pan123 等从分享 API 拿到 CreateAt），无则用当前时间兜底
      const createdAt = n.created_at || Date.now();
      // 直链：优先节点自带 url，其次从 files 按名字匹配
      const dl = n.url || urlMap.get(n.name) || '';
      // 2026-08-19 修复：透传 fid_token / share_fid_token（前端「凭证模式」下载必需，
      //   此前被 flatten 丢弃导致前端拿不到 token → 点下载后无法转存/获取直链）
      const fidToken = n.fid_token || n.share_fid_token || '';
      out.push({
        // 通用字段
        dir: isDir,
        is_dir: isDir,
        kind: isDir ? 'drive#folder' : 'drive#file',
        id: n.fid || n.fs_id || `f_${out.length}`,
        parent_id: parentId || '',
        // 夸克风格
        fid: n.fid || n.fs_id || `f_${out.length}`,
        pdir_fid: parentId || '',
        file_name: n.name,
        // 夸克凭证模式下载必需（2026-08-19）
        share_fid_token: fidToken,
        fid_token: fidToken,
        // 百度风格
        fs_id: n.fs_id || n.fid || 0,
        server_filename: n.name,
        // 通用
        name: n.name,
        size: n.size || 0,
        url: dl,
        download_url: dl,
        created_at: createdAt,
        created_time: new Date(createdAt).toISOString(),
        updated_at: createdAt,
        md5: '',
      });
      if (isDir && n.children) walk(n.children, n.fid || `f_${out.length - 1}`);
    }
  };
  if (!tree || !tree.length) {
    return (files || []).map((f, i) => {
      const dl = f.url || '';
      return {
        dir: false, is_dir: false, kind: 'drive#file',
        id: f.fid || f.fs_id || `f_${i}`, parent_id: '',
        fid: f.fid || f.fs_id || `f_${i}`, pdir_fid: '',
        file_name: f.name, fs_id: f.fs_id || f.fid || 0, server_filename: f.name,
        name: f.name, size: f.size || 0,
        url: dl, download_url: dl,
        created_at: Date.now(), created_time: new Date().toISOString(), updated_at: Date.now(), md5: '',
      };
    });
  }
  walk(tree, '');
  return out;
}

function collectFileNodes(tree) {
  const out = [];
  (function walk(nodes) {
    for (const n of nodes) {
      if (n.type === 'file') out.push(n);
      else if (n.children) walk(n.children);
    }
  })(tree);
  return out;
}

function buildDisplayTree(tree) {
  const walk = (nodes) => (nodes || []).map((n) => {
    const isDir = n.type === 'folder';
    const out = {
      dir: isDir,
      is_dir: isDir,
      isdir: isDir,
      kind: isDir ? 'drive#folder' : 'drive#file',
      id: n.fid || n.fs_id || `f_${Math.random().toString(36).slice(2, 8)}`,
      parent_id: n.parent_id || '',
      fid: n.fid || n.fs_id || '',
      pdir_fid: n.parent_id || '',
      file_name: n.name,
      server_filename: n.name,
      name: n.name,
      size: n.size || 0,
      fid_token: n.fid_token || n.share_fid_token || '',
      // 2026-08-19：保留直链与下载参数（123盘 解析时已取直链，前端下载直接用）
      url: n.url || '',
      download_url: n.url || '',
      s3keyFlag: n.s3keyFlag || n.S3KeyFlag || '',
      etag: n.etag || n.Etag || '',
      // 2026-08-19 修：透传真实创建/更新时间（之前写死 Date.now() 导致前端显示 -）
      // 前端 Vp() 用 Number(created_at) 转时间戳——必须给数字毫秒值
      created_at: n.created_at ? new Date(n.created_at).getTime() : Date.now(),
      created_time: n.created_at ? new Date(n.created_at).toISOString() : '',
      modified_time: n.updated_at || '',
      content_type: n.content_type || '',
    };
    if (isDir && n.children) out.children = walk(n.children);
    return out;
  });
  return walk(tree);
}

function parseBaiduUrl(url, pwdFallback = '') {
  const u = new URL(url);
  const surl = u.pathname.split('/')[2];
  if (!surl) throw new Error('无法解析百度分享链接（应为 https://pan.baidu.com/s/xxxx）');
  // 2026-08-19 修：前端把 pwd 拆出来单独传 body.pass_code，URL 里通常没有 ?pwd=
  //   → 旧逻辑 pwd 为空 → wxlist -130；现在用调用方传的 pwdFallback 兜底
  const pwd = u.searchParams.get('pwd') || String(pwdFallback || '').trim();
  return { surl, pwd };
}
// 2026-08-20 修：后台 UI 让用户粘「完整登录 Cookie（F12 复制）」，但 baiduResolve/详情分支
//   之前只认「纯 BDUSS 值」。兼容两种格式：
//   - 完整 Cookie 串 → 提取 BDUSS / ndut_fmt / STOKEN 三段（缺哪段留空）
//   - 纯值（无 `=` 包裹或只有 BDUSS=）→ 整段当 BDUSS 值
function buildBaiduCookie(ck) {
  const str = String(ck || '').trim();
  if (!str) return '';
  const get = (k) => (str.match(new RegExp('(?:^|;\\s*)' + k + '=([^;]*)')) || [])[1] || '';
  if (/(?:^|;\s*)BDUSS=/.test(str)) {
    return 'BDUSS=' + get('BDUSS') + '; ndut_fmt=' + get('ndut_fmt') + '; STOKEN=' + get('STOKEN');
  }
  return 'BDUSS=' + str + '; ndut_fmt=';
}
module.exports = {
  quarkSenderCookie, ucSenderCookie,
  dayStr, todayStr, parseCookies,
  flattenForShare, collectFileNodes, buildDisplayTree,
  parseBaiduUrl, buildBaiduCookie,
};
