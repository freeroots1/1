/**
 * 极简纯 JS QR 码生成器（零依赖，byte mode + L 纠错，版本 1-9 自动，输出 SVG）
 * 参考 qrcode-generator (Kazuhiko Arase, MIT) 核心算法精简实现。
 * 用法：const { toSVG } = require('./qrcode'); toSVG('https://...') -> '<svg ...>...</svg>'
 */
'use strict';

// ---------- GF(256) 与 Reed-Solomon ----------
const EXP = (() => {
  const e = new Array(512);
  let t = 1;
  for (let i = 0; i < 255; i++) { e[i] = t; t <<= 1; if (t & 0x100) t ^= 0x11d; }
  for (let i = 255; i < 512; i++) e[i] = e[i - 255];
  return e;
})();
const LOG = (() => { const l = new Array(256); for (let i = 0; i < 255; i++) l[EXP[i]] = i; return l; })();
function gMul(a, b) { return (a === 0 || b === 0) ? 0 : EXP[LOG[a] + LOG[b]]; }

function rsGenerator(degree) {
  let g = [1];
  for (let i = 0; i < degree; i++) {
    const next = new Array(g.length + 1).fill(0);
    for (let j = 0; j < g.length; j++) { next[j] ^= gMul(g[j], EXP[i]); next[j + 1] ^= g[j]; }
    g = next;
  }
  return g;
}
function rsCompute(data, degree) {
  const gen = rsGenerator(degree);
  const res = new Array(degree).fill(0);
  for (const d of data) {
    const factor = d ^ res[0];
    res.shift(); res.push(0);
    for (let i = 0; i < degree; i++) res[i] ^= gMul(gen[i], factor);
  }
  return res;
}

// ---------- 版本/容量（版本 1-9，L 纠错）----------
// [总码字数, 每块EC码字数, 块数]
const RS_BLOCK_TABLE = [
  [26, 7, 1], [44, 10, 1], [70, 15, 1], [100, 20, 1], [134, 26, 1],
  [172, 18, 2], [196, 20, 2], [242, 24, 2], [292, 30, 2],
];
const ALIGN_POS = [
  [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34],
  [6, 22, 38], [6, 24, 42], [6, 26, 46],
];
// 格式信息（L 纠错，15 位，含 BCH + 0x5412 掩码）
const FORMAT_INFO = [0x77C4, 0x72F3, 0x7DAA, 0x789D, 0x662F, 0x6318, 0x6C41, 0x6976];

// ---------- 位缓冲 ----------
class BitBuffer {
  constructor() { this.buf = []; this.len = 0; }
  put(num, length) { for (let i = 0; i < length; i++) this.putBit(((num >>> (length - i - 1)) & 1) === 1); }
  putBit(bit) { const b = this.len >> 3; if (b >= this.buf.length) this.buf.push(0); if (bit) this.buf[b] |= 0x80 >>> (this.len & 7); this.len++; }
}

function chooseVersion(byteLen) {
  for (let v = 0; v < 9; v++) {
    const total = RS_BLOCK_TABLE[v][0];
    const ec = RS_BLOCK_TABLE[v][1] * RS_BLOCK_TABLE[v][2];
    const dataCodewords = total - ec;
    const bits = dataCodewords * 8;
    const headerBits = 4 + (v < 9 ? 8 : 16);
    const capacity = Math.floor((bits - headerBits) / 8);
    if (byteLen <= capacity) return v;
  }
  throw new Error('内容过长，超出二维码容量');
}

function encodeData(text, version) {
  const buf = new BitBuffer();
  const data = Buffer.from(text, 'utf8');
  buf.put(4, 4); // byte mode
  buf.put(data.length, version < 9 ? 8 : 16);
  for (const b of data) buf.put(b, 8);
  const total = RS_BLOCK_TABLE[version][0];
  const ec = RS_BLOCK_TABLE[version][1] * RS_BLOCK_TABLE[version][2];
  const dataCodewords = total - ec;
  buf.put(0, Math.min(4, dataCodewords * 8 - buf.len)); // terminator
  if (buf.len % 8) buf.put(0, 8 - (buf.len % 8));
  const pad = [0xec, 0x11]; let pi = 0;
  while (buf.len < dataCodewords * 8) { buf.put(pad[pi], 8); pi ^= 1; }
  const codewords = [];
  for (let i = 0; i < dataCodewords; i++) codewords.push(buf.buf[i] || 0);
  return codewords;
}

function interleave(codewords, version) {
  const total = RS_BLOCK_TABLE[version][0];
  const ecPerBlock = RS_BLOCK_TABLE[version][1];
  const blocks = RS_BLOCK_TABLE[version][2];
  const dataPerBlock = (total - ecPerBlock * blocks) / blocks;
  const dataBlocks = [], ecBlocks = [];
  for (let b = 0; b < blocks; b++) {
    const data = codewords.slice(b * dataPerBlock, (b + 1) * dataPerBlock);
    dataBlocks.push(data);
    ecBlocks.push(rsCompute(data, ecPerBlock));
  }
  const out = [];
  for (let i = 0; i < dataPerBlock; i++) for (let b = 0; b < blocks; b++) out.push(dataBlocks[b][i]);
  for (let i = 0; i < ecPerBlock; i++) for (let b = 0; b < blocks; b++) out.push(ecBlocks[b][i]);
  return out; // 共 total 个码字
}

// ---------- 矩阵 ----------
function makeMatrix(version, finalCodewords) {
  const size = version * 4 + 17;
  const matrix = Array.from({ length: size }, () => new Array(size).fill(false));
  const reserved = Array.from({ length: size }, () => new Array(size).fill(false)); // 功能图案/格式区

  const mark = (r, c, dark) => { if (r >= 0 && r < size && c >= 0 && c < size) { matrix[r][c] = dark; reserved[r][c] = true; } };

  // 定位图案 + 分隔符
  const drawFinder = (r, c) => {
    for (let dr = -1; dr <= 7; dr++) for (let dc = -1; dc <= 7; dc++) {
      const rr = r + dr, cc = c + dc;
      if (rr < 0 || rr >= size || cc < 0 || cc >= size) continue;
      if (dr < 0 || dr > 6 || dc < 0 || dc > 6) { mark(rr, cc, false); continue; } // 分隔符（浅色）
      const dark = (dr === 0 || dr === 6 || dc === 0 || dc === 6 || (dr >= 2 && dr <= 4 && dc >= 2 && dc <= 4));
      mark(rr, cc, dark);
    }
  };
  drawFinder(0, 0); drawFinder(0, size - 7); drawFinder(size - 7, 0);

  // 对齐图案
  const alignPos = ALIGN_POS[version];
  for (const r of alignPos) for (const c of alignPos) {
    if ((r === 0 && c === 0) || (r === 0 && c === size - 7) || (r === size - 7 && c === 0)) continue;
    for (let dr = -2; dr <= 2; dr++) for (let dc = -2; dc <= 2; dc++) {
      mark(r + dr, c + dc, Math.max(Math.abs(dr), Math.abs(dc)) !== 1);
    }
  }

  // 时序图案
  for (let i = 8; i < size - 8; i++) { mark(6, i, i % 2 === 0); mark(i, 6, i % 2 === 0); }

  // 预留格式信息位置
  for (let i = 0; i < 9; i++) { reserved[8][i] = true; reserved[i][8] = true; }
  for (let i = 0; i < 8; i++) { reserved[8][size - 1 - i] = true; reserved[size - 1 - i][8] = true; }
  reserved[size - 8][8] = true; // 暗模块位

  // 放置数据位（跳过 reserved）
  let idx = 0;
  const totalBits = finalCodewords.length * 8;
  let col = size - 1;
  while (col > 0) {
    if (col === 6) col -= 1;
    for (let upward = 0; upward < 2; upward++) {
      for (let r = 0; r < size; r++) {
        const row = upward === 0 ? size - 1 - r : r;
        for (let c = col; c > col - 2; c--) {
          if (!reserved[row][c]) {
            let dark = false;
            if (idx < totalBits) { dark = ((finalCodewords[idx >> 3] >>> (7 - (idx & 7))) & 1) === 1; idx++; }
            matrix[row][c] = dark;
          }
        }
      }
    }
    col -= 2;
  }
  return { matrix, reserved, size };
}

// ---------- 掩码 ----------
const MASK_FN = [
  (r, c) => (r + c) % 2 === 0,
  (r) => r % 2 === 0,
  (r, c) => c % 3 === 0,
  (r, c) => (r + c) % 3 === 0,
  (r, c) => (Math.floor(r / 2) + Math.floor(c / 3)) % 2 === 0,
  (r, c) => ((r * c) % 2) + ((r * c) % 3) === 0,
  (r, c) => (((r * c) % 2) + ((r * c) % 3)) % 2 === 0,
  (r, c) => (((r + c) % 2) + ((r * c) % 3)) % 2 === 0,
];

function applyMask(matrix, reserved, size, maskId) {
  const m = matrix.map((row) => row.slice());
  for (let r = 0; r < size; r++) for (let c = 0; c < size; c++) {
    if (!reserved[r][c] && MASK_FN[maskId](r, c)) m[r][c] = !m[r][c];
  }
  return m;
}

function penalty(matrix, size) {
  let score = 0;
  for (let r = 0; r < size; r++) {
    let run = 1, prev = matrix[r][0];
    for (let c = 1; c < size; c++) { if (matrix[r][c] === prev) run++; else { if (run >= 5) score += 3 + (run - 5); run = 1; prev = matrix[r][c]; } }
    if (run >= 5) score += 3 + (run - 5);
  }
  for (let c = 0; c < size; c++) {
    let run = 1, prev = matrix[0][c];
    for (let r = 1; r < size; r++) { if (matrix[r][c] === prev) run++; else { if (run >= 5) score += 3 + (run - 5); run = 1; prev = matrix[r][c]; } }
    if (run >= 5) score += 3 + (run - 5);
  }
  for (let r = 0; r < size - 1; r++) for (let c = 0; c < size - 1; c++) {
    const b = matrix[r][c];
    if (b === matrix[r][c + 1] && b === matrix[r + 1][c] && b === matrix[r + 1][c + 1]) score += 3;
  }
  for (let r = 0; r < size; r++) for (let c = 0; c < size - 6; c++) {
    if (matrix[r][c] && !matrix[r][c + 1] && matrix[r][c + 2] && matrix[r][c + 3] && matrix[r][c + 4] && !matrix[r][c + 5] && matrix[r][c + 6] &&
      (c + 10 >= size || (!matrix[r][c + 7] && !matrix[r][c + 8] && !matrix[r][c + 9] && !matrix[r][c + 10]))) score += 40;
  }
  for (let r = 0; r < size - 6; r++) for (let c = 0; c < size; c++) {
    if (matrix[r][c] && !matrix[r + 1][c] && matrix[r + 2][c] && matrix[r + 3][c] && matrix[r + 4][c] && !matrix[r + 5][c] && matrix[r + 6][c] &&
      (r + 10 >= size || (!matrix[r + 7][c] && !matrix[r + 8][c] && !matrix[r + 9][c] && !matrix[r + 10][c]))) score += 40;
  }
  let dark = 0;
  for (const row of matrix) for (const v of row) if (v) dark++;
  score += Math.floor(Math.abs(dark / (size * size) * 100 - 50) / 5) * 10;
  return score;
}

function placeFormat(matrix, size, bits) {
  for (let i = 0; i < 15; i++) {
    const mod = ((bits >> i) & 1) === 1;
    if (i < 6) matrix[i][8] = mod;
    else if (i < 8) matrix[i + 1][8] = mod;
    else matrix[size - 15 + i][8] = mod;
  }
  for (let i = 0; i < 15; i++) {
    const mod = ((bits >> i) & 1) === 1;
    if (i < 8) matrix[8][size - i - 1] = mod;
    else if (i < 9) matrix[8][15 - i - 1 + 1] = mod;
    else matrix[8][15 - i - 1] = mod;
  }
  matrix[size - 8][8] = true; // 暗模块
}

function generateQR(text) {
  const byteLen = Buffer.from(text, 'utf8').length;
  const version = chooseVersion(byteLen);
  const codewords = encodeData(text, version);
  const final = interleave(codewords, version);
  const { matrix, reserved, size } = makeMatrix(version, final);

  let bestMask = 0, bestScore = Infinity, bestMatrix = null;
  for (let m = 0; m < 8; m++) {
    const masked = applyMask(matrix, reserved, size, m);
    const s = penalty(masked, size);
    if (s < bestScore) { bestScore = s; bestMask = m; bestMatrix = masked; }
  }
  placeFormat(bestMatrix, size, FORMAT_INFO[bestMask]);
  return { matrix: bestMatrix, size };
}

function toSVG(text, scale = 4, quiet = 4) {
  // 2026-08-21 修（重大 bug）：QR 标准要求四周至少 4 模块白色静区（quiet zone），
  //   扫描器（尤其手机）依赖静区定位——此前 px=size*scale 无静区 → 所有设备无法识别
  const { matrix, size } = generateQR(text);
  const total = size + quiet * 2;
  const px = total * scale;
  let rects = '';
  for (let r = 0; r < size; r++) for (let c = 0; c < size; c++) {
    if (matrix[r][c]) rects += `<rect x="${(c + quiet) * scale}" y="${(r + quiet) * scale}" width="${scale}" height="${scale}"/>`;
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${px} ${px}" width="${px}" height="${px}"><rect width="${px}" height="${px}" fill="#fff"/><g fill="#000">${rects}</g></svg>`;
}

module.exports = { generateQR, toSVG };
