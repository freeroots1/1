// =====================================================================
//  providers/list-trees.js — 各网盘「列目录」实现（2026-08-19 Step 3）
//  仅依赖 lib/http.js 的请求封装（quarkRequest/baiduRequest + API 常量）；
//  ucListTree 的 ucRequest 由调用方传入。逻辑与拆分前完全一致。
// =====================================================================
'use strict';

const { QUARK_API, BAIDU_API, quarkRequest, baiduRequest } = require('../lib/http.js');

async function quarkListTree(cookieRef, pwdId, stoken, rootFid, recursive = true) {
  const root = [];
  const stack = [{ fid: rootFid || '', target: root, recursive }];
  while (stack.length) {
    const { fid, target, recursive: rec } = stack.pop();
    let page = 1;
    while (true) {
      const d = await quarkRequest('GET',
        `${QUARK_API}/1/clouddrive/share/sharepage/detail?pr=ucpro&fr=pc&pwd_id=${pwdId}` +
        `&stoken=${encodeURIComponent(stoken)}&pdir_fid=${fid}&_page=${page}&_size=100` +
        `&_sort=file_type:asc,updated_at:desc&__dt=${Date.now()}`, null, cookieRef);
      const list = (d.data && d.data.list) || [];
      for (const f of list) {
        if (f.dir) {                       // 文件夹：建节点；recursive 时才继续递归进子层
          const folder = { name: f.file_name, type: 'folder', fid: f.fid, children: [] };
          target.push(folder);
          if (rec) stack.push({ fid: f.fid, target: folder.children, recursive: true });
        } else {                            // 文件：收集 fid/token 供后续取直链
          target.push({
            name: f.file_name, type: 'file', size: f.size,
            fid: f.fid, fid_token: f.share_fid_token || f.fid_token,
          });
        }
      }
      if (list.length < 100) break;
      page++;
    }
  }
  return root;
}

// 百度递归列目录；recursive=false 只列当前层（detail 进入文件夹用，dir 为分享者网盘真实 path）
// 2026-08-22 关键修复：wxlist 子目录查询的 dir 必须是【分享者网盘里的完整 path】
//   （root=1 响应 list[].path，如 /游戏分享/0000魔兽争霸/xxx），而非 server_filename 显示名拼接。
//   显示名拼接 → 百度返回 -130/mis_2（找不到目录）→ 被迫走 Playwright 兜底卡 30 秒。
//   同时子目录查询必须带 BDUSS（否则 errtype=mispwd-9）。参照 baiduwp-php getListApi 实现。
async function baiduListTree(surl, pwd, cookie, dir, acc = [], recursive = true) {
  const r = await baiduRequest('POST',
    `${BAIDU_API}/share/wxlist?channel=weixin&version=2.2.2&clienttype=25&web=1`,
    `shorturl=${surl}&dir=${encodeURIComponent(dir || '/')}&root=${dir === '' ? 1 : 0}&pwd=${encodeURIComponent(pwd)}&page=1&num=1000&order=time`,
    cookie);
  const list = (r.data && r.data.list) || [];
  for (const f of list) {
    // isdir 可能是 0/1 数字或 "0"/"1" 字符串，必须严格判断（"0" 是 truthy 曾误判文件夹）
    const isDir = f.isdir === 1 || f.isdir === '1' || f.isdir === true;
    if (isDir) {
      // f.path = 分享者网盘真实完整路径，子目录查询必须用它
      const folder = { name: f.server_filename, type: 'folder', fs_id: f.fs_id, path: f.path, children: [] };
      if (recursive && f.path) {
        folder.children = await baiduListTree(surl, pwd, cookie, f.path, [], true);
      }
      acc.push(folder);
    } else {
      acc.push({ name: f.server_filename, type: 'file', size: f.size, fs_id: f.fs_id, url: '' });
    }
  }
  return acc;
}

// UC 递归列目录（与夸克同构）
// UC 递归列目录（与夸克同构）；recursive=false 只列当前层（detail 进入文件夹用）
async function ucListTree(ucRequest, shareId, stoken, rootFid, recursive = true) {
  const root = [];
  const stack = [{ fid: rootFid || '', target: root, recursive }];
  while (stack.length) {
    const { fid, target, recursive: rec } = stack.pop();
    let page = 1;
    while (true) {
      const d = await ucRequest('GET',
        `/1/clouddrive/share/sharepage/detail?entry=ft&fr=pc&pr=UCBrowser&pwd_id=${shareId}` +
        `&stoken=${encodeURIComponent(stoken)}&pdir_fid=${fid}&_page=${page}&_size=100` +
        `&_sort=file_type:asc,updated_at:desc&__dt=${Date.now()}`);
      const list = (d.data && d.data.list) || [];
      for (const f of list) {
        if (f.dir) {
          const folder = { name: f.file_name, type: 'folder', fid: f.fid, children: [] };
          target.push(folder);
          if (rec) stack.push({ fid: f.fid, target: folder.children, recursive: true });
        } else {
          target.push({
            name: f.file_name, type: 'file', size: f.size,
            fid: f.fid, fid_token: f.share_fid_token || f.fid_token,
          });
        }
      }
      if (list.length < 100) break;
      page++;
    }
  }
  return root;
}
module.exports = { quarkListTree, baiduListTree, ucListTree };
