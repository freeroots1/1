// =====================================================================
//  providers/resolve-other.js — 百度/123/迅雷/移动 网盘解析（2026-08-19 Step 4）
//  仅依赖 lib/http.js(fetchTimeout/baiduRequest/BAIDU_API) +
//  lib/utils.js(collectFileNodes/parseBaiduUrl) + providers/list-trees.js(baiduListTree)
// =====================================================================
'use strict';

const {
  BAIDU_API, baiduRequest, fetchTimeout,
} = require('../lib/http.js');
const {
  collectFileNodes, parseBaiduUrl, buildBaiduCookie,
} = require('../lib/utils.js');
const { baiduListTree } = require('./list-trees.js');

// ============ 123盘 账号接口签名（模块级，供 pan123Resolve 转存 + server.js 后删除共用）============
// 2026-08-20 15:53：从 pan123Resolve 内部提升为模块级导出（cleanupSave 删除转存副本也要用签名）
const zlib = require('zlib');
const SIGN_TABLE = ['a','d','e','f','g','h','l','m','y','i','j','n','o','p','k','q','r','s','t','u','b','c','v','w','s','z'];
const pad2 = (n) => String(n).padStart(2, '0');
// AList: 数字0→table[0]；netdisk: 数字1→table[0]
function pan123Sign(path, mode) {
  const random = String(Math.round(1e7 * Math.random()));
  const cst = new Date(Date.now() + 8 * 3600 * 1000);
  const timestamp = String(Math.floor(cst.getTime() / 1000));
  const fmt = String(cst.getUTCFullYear()) + pad2(cst.getUTCMonth() + 1) + pad2(cst.getUTCDate())
    + pad2(cst.getUTCHours()) + pad2(cst.getUTCMinutes());
  let nowStr;
  if (mode === 'netdisk') {
    nowStr = fmt.split('').map((c) => {
      const d = Number(c);
      return d === 0 ? SIGN_TABLE[0] : SIGN_TABLE[d - 1];
    }).join('');
  } else {
    nowStr = fmt.split('').map((c) => SIGN_TABLE[Number(c)]).join('');
  }
  const timeSign = String(zlib.crc32(Buffer.from(nowStr)));
  const data = [timestamp, random, path, 'web', '3', timeSign].join('|');
  const dataSign = String(zlib.crc32(Buffer.from(data)));
  return { [timeSign]: [timestamp, random, dataSign].join('-') };
}
const SIGN_MODES = [null, 'alist', 'netdisk'];
// 2026-08-21 修（全局审计 P2）：签名模式不缓存 → 每次调用最多试 3 种（3 倍请求）。
//   首次试出生效模式后模块级缓存；401/403/sign 类失败时清缓存重试其他模式。
let _signModeCache = { save: undefined, download: undefined };
function pickSignModes(kind) {
  const cached = _signModeCache[kind];
  if (cached !== undefined) return [cached, ...SIGN_MODES.filter((m) => m !== cached)];
  return SIGN_MODES;
}
function learnSignMode(kind, mode) {
  if (mode !== undefined) _signModeCache[kind] = mode;
}
function forgetSignMode(kind) {
  _signModeCache[kind] = undefined;
}

async function baiduResolve(url, bduss, opts = {}) {
  // 2026-08-20 修：兼容「完整 Cookie 串」与「纯 BDUSS 值」两种后台填法（见 lib/utils.js）
  const cookie = buildBaiduCookie(bduss);
  // 2026-08-19 修：前端把 pwd 拆出单独传 body.pass_code，URL 里通常没有 ?pwd=
  //   → 传 opts.pass_code 作兜底，避免 wxlist -130
  const { surl, pwd } = parseBaiduUrl(url, opts.pass_code || opts.passcode);
  module.exports._lastBaiduSurl = surl; // 供 server.js 建 path 映射（2026-08-22）

  // 1) 分享信息（含 uk/shareid/seckey + 首层列表）—— wxlist 为公开接口，解析阶段可免 Cookie
  const info = await baiduRequest('POST',
    `${BAIDU_API}/share/wxlist?channel=weixin&version=2.2.2&clienttype=25&web=1`,
    `pwd=${encodeURIComponent(pwd)}&shorturl=${surl}&root=1`, cookie);
  const { uk, shareid, seckey: seckeyInit } = info.data;

  // 2) 列文件
  // 2026-08-22 性能优化（参照 AList baidu_share 驱动）：解析阶段只列当前层，
  //   不再全量递归 —— 全量递归连续多次 wxlist 必触发百度 -130 风控 → 被迫走 Playwright 页面方案（50s+）。
  //   第 1 步 wxlist root=1 响应本身已带首层列表（零额外请求）；进文件夹由前端调 detail 单层查询。
  //   与夸克/UC/迅雷的「本地切层」模式对齐。
  let tree, seckey = seckeyInit || '';
  const mapWxlistNode = (f) => {
    // isdir 可能是 0/1 数字或 "0"/"1" 字符串，严格判断（"0" 是 truthy 曾误判文件夹）
    // path = 分享者网盘真实路径，detail 子目录查询必须用它（2026-08-22）
    const isDir = f.isdir === 1 || f.isdir === '1' || f.isdir === true;
    return isDir
      ? { name: f.server_filename, type: 'folder', fs_id: f.fs_id, path: f.path, children: [] }
      : { name: f.server_filename, type: 'file', size: f.size, fs_id: f.fs_id, url: '', path: f.path };
  };
  if (opts.listOnly) {
    // 解析（share）：直接复用第 1 步 root=1 返回的首层列表，零额外请求
    tree = ((info.data && info.data.list) || []).map(mapWxlistNode);
  } else {
    try {
      // 下载/detail 等深路径场景仍递归（此时请求频率低，风控风险小）
      tree = await baiduListTree(surl, pwd, cookie, '', [], true);
    } catch (e) {
      console.warn('[baidu] wxlist 失败，走页面方案:', String(e.message || '').slice(0, 80));
      tree = await buildBaiduFullTree(surl, pwd, '');
    }
  }

  const fileNodes = collectFileNodes(tree);
  if (fileNodes.length === 0 && tree.length === 0) throw new Error('该分享没有可解析的文件（可能是空文件夹）');

  // 2.5) 解析阶段（listOnly）：只列文件、不取直链、不动 Cookie（用户 2026-08-19 需求）
  if (opts.listOnly) {
    return {
      tree,
      files: fileNodes.map((f) => ({ name: f.name, size: f.size, url: '', expiresAt: 0, needSave: true })),
    };
  }

  // 3) sign + dlink（下载阶段才需要 BDUSS）
  const signResp = await baiduRequest('GET',
    `${BAIDU_API}/share/tplconfig?fields=sign,timestamp&channel=chunlei&web=1&app_id=250528&clienttype=0&surl=${surl}`,
    null, cookie);
  const { sign, timestamp } = signResp.data;

  const fids = fileNodes.map((f) => f.fs_id);
  const durl = await baiduRequest('POST',
    `${BAIDU_API}/api/sharedownload?app_id=250528&channel=chunlei&clienttype=12&web=1&sign=${sign}&timestamp=${timestamp}`,
    `encrypt=0&extra=${encodeURIComponent(JSON.stringify({ sekey: seckey }))}` +
    `&fid_list=[${fids}]&primaryid=${shareid}&product=share&type=nolimit&uk=${uk}`, cookie);

  // 4) 把直链写回树叶节点
  // 注意：百度 sharedownload 返回顺序与 fid_list 请求顺序一致；文件名可能重复，
  //      因此不能用 server_filename 做 key（同名会互相覆盖），改为按顺序匹配。
  if (Array.isArray(durl.list)) {
    // 若返回带 fs_id 则优先按 fs_id 精确匹配，否则按请求顺序一一对应
    const urlMap = {};
    const byFsId = durl.list.every((d) => d.fs_id != null);
    if (byFsId) {
      for (const d of durl.list) urlMap['fs:' + d.fs_id] = d.dlink;
      for (const n of fileNodes) { const k = 'fs:' + n.fs_id; if (urlMap[k]) n.url = urlMap[k]; }
    } else {
      fileNodes.forEach((n, i) => { const d = durl.list[i]; if (d) n.url = d.dlink; });
    }
    return {
      tree,
      files: fileNodes.map((f) => ({ name: f.name, size: f.size, url: f.url })),
    };
  }
  throw new Error('获取百度直链失败');
}

// 2026-08-20：从 123 download/info 响应里选「浏览器可下」的分享直链（过滤 app-pay 403 死链）
//   62.jpg 实锤：部分分享 dispatchList[0] = user-app-pay-download-cdn（app 付费通道），Gopeed 一律 403。
//   遍历全部通道 + HEAD 探测，优先 user-share-*（浏览器通道）；全不可用 → ''（前端发送时 prepare 秒传转存）
async function pan123PickUrl(data) {
  const path = (data && data.downloadPath) || '';
  const direct = (data && (data.DownloadUrl || data.downloadUrl || data.url)) || '';
  const candidates = [];
  if (direct) candidates.push({ url: direct, app: /user-app/i.test(direct) });
  if (path && Array.isArray(data && data.dispatchList)) {
    for (const d0 of data.dispatchList) {
      const prefix = (d0 && d0.prefix) || '';
      if (!prefix) continue;
      candidates.push({ url: prefix + path, app: /user-app/i.test(prefix) });
    }
  }
  candidates.sort((a, b) => Number(a.app) - Number(b.app)); // 非 app 通道优先
  for (const c of candidates) {
    if (await pan123HeadOk(c.url)) return c.url;
  }
  return '';
}
async function pan123HeadOk(url) {
  if (!url) return false;
  try {
    const resp = await fetchTimeout(url, {
      method: 'GET',
      headers: {
        'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Version/17.0 Mobile/15E148 Safari/604.1',
        'Referer': 'https://www.123pan.com/',
        'Range': 'bytes=0-0',
      },
      redirect: 'follow',
    }, 3000);
    return resp.status === 200 || resp.status === 206;
  } catch (e) { return false; }
}

async function pan123Resolve(url, cookie, opts = {}) {
  const rawUrl = String(url || '');
  let key = (rawUrl.match(/\/s\/([A-Za-z0-9_-]+)/) || [])[1] || '';
  if (!key) {
    const m = rawUrl.match(/(?:123pan|123pan\.cn)\/[A-Za-z0-9]+\/([A-Za-z0-9_-]+)/);
    key = m ? m[1] : '';
  }
  if (!key) throw new Error('无法识别123网盘分享链接');
  // 2026-08-19：提取码 = URL ?pwd= 优先，其次 opts.pass_code（前端把 pwd 拆出单独传）
  const pwd = (rawUrl.match(/[?&#]pwd=([a-zA-Z0-9]+)/i) || [])[1] || opts.pass_code || opts.passcode || '';

  // 从原始 URL 提取分享站 host（子域或主站），作为 Origin/Referer
  // 2026-08-19：123盘 固定用官网域名做 Origin/Referer（前端可能把链接重写成 www.123pan.cn 错域名，
  // 从 URL 提取 origin 会导致 Referer/Origin 头错误 → API 拒绝 → 解析失败）
  const shareHost = 'https://www.123pan.com';
  const headers = {
    'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
    'Referer': shareHost + '/',
    'Origin': shareHost,
    'Accept': 'application/json, text/plain, */*',
  };
  if (cookie) headers.Cookie = cookie;
  // 2026-08-19：123盘 账号密码登录后 token 存 cookies.pan123（格式 token=xxx）→ 带 Bearer 鉴权
  // 分享公开接口免登录；大文件直链/上传需登录态（code 5112）→ Bearer token 才能全速
  try {
    const { extractToken } = require('./login-123.js');
    const tk = extractToken(cookie);
    if (tk) headers.authorization = 'Bearer ' + tk;
  } catch {}

  // ============ 路径 A：官方 API（H5 主路径，稳）============
  // 列表：GET /api/share/get（shareKey + ParentFileId 递归）
  // 直链：POST /api/v2/share/download/info（shareKey + fileId + sharePwd + S3KeyFlag + Size + Etag）
  // 规则：小文件 DownloadUrl 内嵌直链免登录；大文件需登录态（code 5112），配 Cookie 即可全速
  const apiBase = 'https://api.123pan.cn';
  const tree = [];
  let needLoginNote = '';

  // 2026-08-21 修（全局审计 P1）：递归加深度上限（对齐 mcloud 限深 8），
  //   子层异常不再静默吞掉 → console.warn 留痕（树残缺可排查）
  const P123_MAX_DEPTH = 8;
  async function apiList(parentId, target, recursive = true, depth = 0) {
    const qs = `shareKey=${encodeURIComponent(key)}&sharePwd=${encodeURIComponent(pwd)}` +
      `&ParentFileId=${parentId || 0}&Page=1&limit=100&orderBy=fileId&orderDirection=asc&next=0`;
    const r = await fetchTimeout(`${apiBase}/api/share/get?${qs}`, { headers });
    const j = await r.json().catch(() => ({}));
    if (j.code !== 0) throw new Error(j.message || '获取123网盘分享信息失败');
    const items = (j.data && j.data.InfoList) || [];
    for (const f of items) {
      const name = f.FileName || f.fileName || '';
      const isDir = f.Type === 1 || f.IsFolder === true;
      if (isDir) {
        const folder = { name, type: 'folder', fid: String(f.FileId || f.fileId || ''), size: f.Size || f.size || 0, created_at: f.CreateAt || f.createAt || f.UpdateAt || '', children: [] };
        target.push(folder);
        if (recursive && depth < P123_MAX_DEPTH) {
          try { await apiList(f.FileId, folder.children, true, depth + 1); }
          catch (e) { console.warn(`[pan123] apiList 子层失败(${name}, depth=${depth}):`, String(e.message || e).slice(0, 100)); }
        } else if (recursive) {
          console.warn(`[pan123] apiList 达到最大深度 ${P123_MAX_DEPTH}，截断: ${name}`);
        }
      } else {
        // 2026-08-20 22:0x 修（62.jpg 根因实锤）：user-app-pay-download-cdn（app 付费通道）**绑定签发 IP**——
        //   服务器签发后用户电脑下载必 403（实测：服务器同 IP 下载 206 / 用户浏览器 HEAD 403）。
        //   且 HEAD 探测环境=签发环境（同 IP）会误判 200 → 不能靠探测，app 通道**一律置空**，
        //   前端发送时 prepare → 秒传转存到自己账号（user-other 通道）拿直链。
        let dlUrl = f.DownloadUrl || f.downloadUrl || '';
        if (dlUrl && /user-app/i.test(dlUrl)) dlUrl = '';
        target.push({
          name, type: 'file', size: f.Size || f.fileSize || 0,
          fid: f.FileId || f.fileId || '',
          url: dlUrl,
          s3keyFlag: f.S3KeyFlag || f.S3keyFlag || f.s3keyFlag || '',
          etag: f.Etag || f.etag || '',
          created_at: f.CreateAt || f.createAt || f.UpdateAt || '',
          updated_at: f.UpdateAt || f.updateAt || '',
          content_type: f.ContentType || '',
        });
      }
    }
  }

  try {
    await apiList(0, tree, true);
  } catch (e) {
    // API 失败回退：页面 shareInfo（旧版页面结构）
    try {
      const pageUrl = /share\.123pan\.cn/i.test(rawUrl) ? rawUrl : `https://www.123pan.com/s/${key}`;
      const pageResp = await fetchTimeout(pageUrl, { headers });
      const html = await pageResp.text();
      const jsonMatch = html.match(/window\.shareInfo\s*=\s*(\{[\s\S]*?\})\s*;?\s*<\/script>/);
      if (!jsonMatch) throw new Error('无法解析123网盘分享页面（分享可能已失效）');
      const shareInfo = JSON.parse(jsonMatch[1]);
      if (shareInfo.hasPwd && !pwd && !shareInfo.passCode) throw new Error('该分享需要提取码，请在链接末尾加 ?pwd=密码');
      const raw = (shareInfo.fileList && shareInfo.fileList.length) ? shareInfo.fileList : (shareInfo.fileInfo || []);
      const walk = (items, target, recursive = true) => {
        for (const f of items || []) {
          const isDir = !!f.isFolder || !!f.dir || f.type === 'folder';
          if (isDir) {
            const folder = { name: f.fileName || f.name, type: 'folder', fid: String(f.fileId || f.id || ''), children: [] };
            target.push(folder);
            if (recursive && f.children) walk(f.children, folder.children, true);
          } else {
            target.push({
              name: f.fileName || f.name, type: 'file', size: f.fileSize || f.size || 0,
              fid: f.fileId || f.id || '',
              url: f.downloadUrl || f.downURL || f.downUrl || '',
              s3keyFlag: f.S3keyFlag || f.s3keyFlag || f.S3KeyFlag || '',
              etag: f.Etag || f.etag || '',
            });
          }
        }
      };
      walk(raw, tree, true);
    } catch (e2) {
      throw new Error('获取123网盘分享信息失败（' + (e2.message || '') + '）');
    }
  }

  // 大文件（无内嵌直链）→ 官方 download/info 补直链
  // 解析阶段（listOnly）：只列文件不补直链（小文件内嵌直链已含在列表，大文件留空，
  // 点击下载时 fetch 阶段再动用 Cookie 补直链）—— 用户 2026-08-19 需求
  const fileNodes = collectFileNodes(tree);
  if (!opts.listOnly) {
    const apiHeaders = {
      'User-Agent': headers['User-Agent'],
      'Origin': shareHost,
      'Referer': shareHost + '/',
      'Content-Type': 'application/json',
      'Platform': 'ios',
      'App-Version': '3',
    };
    if (cookie) {
      apiHeaders.Cookie = cookie;
      // 123盘 download/info 需要 Authorization: Bearer {token}（LinkSwift 契约）。
      // 从 Cookie 里自动提取常用 token 字段（platformLoginToken / token / auth），粘贴完整 Cookie 即可生效
      const tok = String(cookie).match(/(?:platformLoginToken|platform_token|token|auth)=([a-zA-Z0-9._\-]+)/i);
      if (tok) apiHeaders.Authorization = 'Bearer ' + tok[1];
    }
    // 2026-08-20 用户需求「借助我的账号加速下载」：
    // 123盘流量包机制 = 分享方勾选「游客/免费用户提取」后，提取方下载流量消耗**分享方的流量包**，
    //   分享方流量包耗尽 → 大文件报 5113「分享方提取流量包不足」。
    //   而**登录用户/转存到自己账号的文件不消耗分享方流量包**。
    // 因此：大文件先「秒传转存到运营者自己的 123 账号」→ 从自己账号 download_info 取直链
    //   （参考 AList drivers/123：upload_request body {driveId,duplicate,etag,fileName,parentFileId,size,type}
    //    响应 data.Reuse=true → 秒传成功拿 FileId；download_info body {fileId,etag,fileName,s3keyFlag,size,type}
    //    响应 data.DownloadUrl 可能带 params=base64(真实url) → 302 跟随 / data.redirect_url）
    // 秒传失败（如分享方禁止转存/无登录态）→ 回退分享通道 download/info（5113 时提示流量包）
    // 提取 Bearer token（供秒传加速用；从 apiHeaders 的 Authorization 解析）
    let bearerToken = apiHeaders.Authorization ? apiHeaders.Authorization.slice(7) : '';
    // 123盘 账号类接口（upload_request/download_info/delete）签名参数（模块级 pan123Sign/SIGN_MODES）
    // 2026-08-20 15:53 用户反馈：123 网盘「被塞满」但「无法正常下载」——根因：share 列表阶段就秒传转存
    //   （pan123Resolve 不看 listOnly/allowSave）→ 每次解析都往运营者 123 账号塞文件；且秒传失败时
    //   静默跳过拿不到直链。修复：**只有 fetch/prepare（allowSave=true，即点发送到下载器）才秒传**；
    //   share/detail 列表阶段一律不转存。
    const allowSave = opts.allowSave === true;
    // 秒传/账号下载走 b/api（AList MainApi=BApi）；签名参数附加在 query
    const yunApi = 'https://yun.123pan.com/b/api';
    const secHeaders = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
      'Origin': 'https://yun.123pan.com',
      'Referer': 'https://yun.123pan.com/',
      'platform': 'web',
      'app-version': '3',
      'Content-Type': 'application/json',
    };
    if (bearerToken) secHeaders.Authorization = 'Bearer ' + bearerToken;
    else if (cookie) secHeaders.Cookie = cookie;
    // 秒传转存（上传到运营者账号根目录，重名覆盖）→ 返回新 FileId；失败返回 ''
    // 2026-08-20：签名参数不确定（AList signPath 与 netdisk-fast encode123 字符映射不同），
    //   按 SIGN_MODES 序列尝试：无签名 → AList签名 → netdisk签名
    async function pan123Save(f) {
      if (!f.etag || !f.size) return '';
      const body = { driveId: 0, duplicate: 2, etag: f.etag, fileName: f.name, parentFileId: 0, size: Number(f.size), type: 0 };
      for (const mode of pickSignModes('save')) {
        try {
          const sign = mode ? pan123Sign('/b/api/file/upload_request', mode) : null;
          const url = `${yunApi}/file/upload_request` + (sign ? '?' + new URLSearchParams(sign) : '');
          const r = await fetchTimeout(url, {
            method: 'POST', headers: secHeaders, body: JSON.stringify(body),
          });
          const j = await r.json().catch(() => ({}));
          if (j.code === 0 && j.data && (j.data.Reuse === true || j.data.reuse === true)) {
            // 2026-08-20 修（秒传"假失败"实锤）：upload_request 响应 data.FileId 恒为 0，
            //   真实新文件 ID 在 data.Info.FileId（AList 123 driver 同款）→ 之前永远取空 → 秒传转存从未真正生效
            learnSignMode('save', mode);
            const fid = j.data.FileId || j.data.fileId || j.data.fileID
              || (j.data.Info && (j.data.Info.FileId || j.data.Info.fileId || j.data.Info.fileID)) || '';
            if (fid) return String(fid);
          }
          if (j.code === 401 || j.code === 403 || /sign|auth/i.test(String(j.message || ''))) {
            forgetSignMode('save');
            continue; // 签名/鉴权问题 → 下一种签名重试
          }
          return '';
        } catch (e) {
          continue;
        }
      }
      return '';
    }
    // 从自己账号拿直链（AList Link() 同款；DownloadUrl 可能带 params=base64(真实url)）
    async function pan123DownloadUrl(f, newFileId) {
      const body = { driveId: 0, etag: f.etag || '', fileId: newFileId || f.fid, fileName: f.name, size: Number(f.size || 0), type: 0 };
      if (f.s3keyFlag) body.s3keyFlag = f.s3keyFlag;
      for (const mode of pickSignModes('download')) {
        try {
          const sign = mode ? pan123Sign('/b/api/file/download_info', mode) : null;
          const url = `${yunApi}/file/download_info` + (sign ? '?' + new URLSearchParams(sign) : '');
          const r = await fetchTimeout(url, {
            method: 'POST', headers: secHeaders, body: JSON.stringify(body),
          });
          const j = await r.json().catch(() => ({}));
          if (j.code !== 0 || !j.data) {
            if (j.code === 401 || j.code === 403 || /sign|auth/i.test(String(j.message || ''))) { forgetSignMode('download'); continue; }
            return '';
          }
          learnSignMode('download', mode);
          let url_ = j.data.DownloadUrl || j.data.downloadUrl || j.data.url || '';
          if (!url_) return '';
          // DownloadUrl 可能带 params=base64(真实直链)，需解码替换
          try {
            const u = new URL(url_);
            const nu = u.searchParams.get('params');
            if (nu) {
              const decoded = Buffer.from(nu, 'base64').toString('utf8');
              if (/^https?:\/\//.test(decoded)) url_ = decoded;
            }
          } catch {}
          // 跟随 302（AList 用 NoRedirectClient 拿 location）
          try {
            const head = await fetchTimeout(url_, { method: 'GET', headers: { Referer: 'https://yun.123pan.com/', 'User-Agent': secHeaders['User-Agent'] }, redirect: 'manual' });
            if (head.status === 302 || head.status === 301) {
              const loc = head.headers.get('location');
              if (loc) url_ = new URL(loc, url_).toString();
            } else if (head.status < 300) {
              const bodyTxt = await head.text().catch(() => '');
              try {
                const jj = JSON.parse(bodyTxt);
                if (jj.data && jj.data.redirect_url) url_ = jj.data.redirect_url;
              } catch {}
            }
          } catch {}
          return url_;
        } catch (e) {
          continue;
        }
      }
      return '';
    }
    // 2026-08-20 22:10 修（123 点发送卡 30s）：prepare 只处理**目标文件**（opts.target_file），
    //   之前对分享里所有无直链文件逐个秒传+探测（100 个文件 → 30s+）。其他文件保持空直链，
    //   前端点它们时再 fetch 单独准备。
    const targetSet = opts.target_file ? new Set([String(opts.target_file)]) : null;
    for (const f of fileNodes.filter((x) => !x.url && (!targetSet || targetSet.has(String(x.name))))) {
      // ===== 主路径：秒传转存到自己账号 → 自己账号直链（绕开分享方流量包 5113）=====
      // 2026-08-20：token 失效时经 ensureToken 自动续期后重试一次（复用账号密码/refresh_token 机制）
      // 2026-08-20 15:53 修复：**仅 fetch/prepare（allowSave=true）才秒传**（share 列表阶段不转存，避免占空间）
      if (allowSave && bearerToken && f.etag && f.size) {
        for (let attempt = 0; attempt < 2; attempt++) {
          try {
            const newFileId = await pan123Save(f);
            if (newFileId) {
              const accUrl = await pan123DownloadUrl(f, newFileId);
              if (accUrl) {
                f.url = accUrl;
                f.expiresAt = 0;
                f._transferred = true;
                f.transferFileId = newFileId; // 2026-08-20 15:53：登记删除用（后删除机制）
                break;
              }
            }
            // 秒传成功但没拿到直链（或秒传失败）→ 若还有重试机会且能续期 token 则重试
            if (attempt === 0 && opts.ensureToken && !opts._p123SecRetried) {
              opts._p123SecRetried = true;
              const nt = await opts.ensureToken();
              if (nt && nt !== bearerToken) {
                bearerToken = nt;
                secHeaders.Authorization = 'Bearer ' + nt;
                continue;
              }
            }
          } catch (e) {
            if (attempt === 0 && opts.ensureToken && !opts._p123SecRetried) {
              opts._p123SecRetried = true;
              try {
                const nt = await opts.ensureToken();
                if (nt && nt !== bearerToken) {
                  bearerToken = nt;
                  secHeaders.Authorization = 'Bearer ' + nt;
                  continue;
                }
              } catch {}
            } else {
              console.warn('[pan123] 秒传加速失败,回退分享通道:', String(e.message || e).slice(0, 100));
            }
          }
          break;
        }
        if (f.url) continue;
      }
      // ===== 回退：分享通道 download/info（受分享方流量包限制，5113 会失败）=====
      try {
        // 参数名必须用大写（LinkSwift 实测契约）：ShareKey/FileID/S3keyFlag/Size/Etag + Platform: ios
        const body = { ShareKey: key, FileId: f.fid, SharePwd: pwd };
        if (f.s3keyFlag) body.S3keyFlag = f.s3keyFlag;
        if (f.size) body.Size = f.size;
        if (f.etag) body.Etag = f.etag;
        const dlResp = await fetchTimeout(`${apiBase}/api/v2/share/download/info`, {
          method: 'POST', headers: apiHeaders, body: JSON.stringify(body),
        });
        const dl = await dlResp.json().catch(() => ({}));
        if (dl.code === 0 && dl.data) {
          // 2026-08-20 修（62.jpg 实锤）：分享直链不能只取 dispatchList[0]（可能 app-pay 403 死链）
          f.url = await pan123PickUrl(dl.data);
          f.expiresAt = dl.data.DownloadUrlExpireAt || 0;
        } else if (dl.code === 5112 || dl.code === 401 || dl.code === 403) {
          // 大文件需登录。2026-08-19：配置了 ensureToken（账号密码自动重登）→ 换新 token 重试一次
          if (opts.ensureToken && !opts._p123Retried) {
            opts._p123Retried = true;
            const newToken = await opts.ensureToken();
            if (newToken) {
              headers.authorization = 'Bearer ' + newToken;
              const dlResp2 = await fetchTimeout(`${apiBase}/api/v2/share/download/info`, {
                method: 'POST', headers, body: JSON.stringify(body),
              });
              const dl2 = await dlResp2.json().catch(() => ({}));
              if (dl2.code === 0 && dl2.data) {
                f.url = await pan123PickUrl(dl2.data);
                f.expiresAt = dl2.data.DownloadUrlExpireAt || 0;
                continue; // 重登成功，继续处理后续文件
              }
            }
          }
          // 无账号密码或重登仍失败：记录提示，不再逐个请求
          needLoginNote = '大文件需登录123网盘账号（后台配置 123盘 账号密码后自动续期全速下载）';
          break;
        } else if (dl.code === 5113) {
          // 2026-08-20：分享方流量包不足（用户截图机制：勾选游客/免费用户提取后消耗分享方流量包）。
          //   秒传加速已先尝试过；走到这里说明无 token 或秒传被禁（分享方未开启转存等）
          needLoginNote = needLoginNote || '分享方流量包不足(5113)，且无法转存加速（需后台配置123账号，或分享方关闭流量包选项）';
        }
      } catch {}
    }
  }

  if (!fileNodes.length) throw new Error('该分享没有可解析的文件（可能是空文件夹）');
  const hasUnresolved = fileNodes.some((f) => !f.url);
  if (hasUnresolved && needLoginNote) {
    // 小文件已有直链，大文件缺 → 提示但不中断（前端可展示列表，下载时报错提示）
    console.log(`[pan123] ${needLoginNote}`);
  }
  return { tree, files: fileNodes.map((f) => ({ name: f.name, size: f.size, url: f.url, expiresAt: f.expiresAt || 0, transferred: !!f._transferred, transferFileId: f.transferFileId || '' })) };
}

// =====================================================================
//  迅雷云盘解析 —— API 直连方案（2026-08-24 优化）
//  2026-08-24 改为纯 API：captcha/init 获取 token → share/detail 直接列文件，零浏览器。
//  消除 Playwright 启动耗时（~9s/次），与 xunlei_download.py 同款方案。
//  兜底：API 失败时回退到旧版 Playwright 浏览器方案。
// =====================================================================
const { execFile } = require('child_process');
const XUNLEI_PY = process.env.XUNLEI_PYTHON || '/home/ubuntu/pwand-playwright/venv/bin/python';
const XUNLEI_SCRIPT = process.env.XUNLEI_SCRIPT || '/home/ubuntu/pwand-playwright/xunlei_page.py';
const XUNLEI_TOKEN_CACHE = '/home/ubuntu/pwand-playwright/xunlei_api_token.json';
const XUNLEI_DID = '925b7631473a13716b791d7f28289cad';
const XUNLEI_CLIENT_ID = 'Xqp0kJBXWhwaTpB6';
const XUNLEI_CAPTCHA_TTL = 6 * 3600 * 1000;
const XUNLEI_API_UA = 'Dalvik/2.1.0 (Linux; U; Android 12; M2004J7AC Build/SP1A.210812.016)';

function loadXunleiApiToken() {
  try {
    const d = JSON.parse(require('fs').readFileSync(XUNLEI_TOKEN_CACHE, 'utf8'));
    if (Date.now() - d.ts < XUNLEI_CAPTCHA_TTL && d.token) return d;
  } catch {}
  return null;
}
function saveXunleiApiToken(token) {
  try {
    require('fs').writeFileSync(XUNLEI_TOKEN_CACHE, JSON.stringify({ token, ts: Date.now() }));
  } catch {}
}

async function getXunleiCaptchaToken() {
  const cached = loadXunleiApiToken();
  if (cached) return cached.token;
  const body = JSON.stringify({
    action: 'GET:/drive/v1/share',
    captcha_sign: '1.' + String(Date.now()),
    client_id: XUNLEI_CLIENT_ID, device_id: XUNLEI_DID,
    meta: {}, redirect_uri: 'https://pan.xunlei.com/',
  });
  const resp = await fetchTimeout('https://api-pan.xunlei.com/drive/v1/captcha/init', {
    method: 'POST',
    headers: { 'User-Agent': XUNLEI_API_UA, 'Content-Type': 'application/json',
      'x-device-id': XUNLEI_DID, 'x-client-id': XUNLEI_CLIENT_ID },
    body,
  }, 15000);
  const j = await resp.json();
  const token = (j && j.captcha_token) || '';
  if (token) saveXunleiApiToken(token);
  return token;
}

async function runXunleiApi(shareId, pwd, parentId, passCodeToken) {
  const token = await getXunleiCaptchaToken();
  if (!token) throw new Error('迅雷 captcha token 获取失败');
  const h = {
    'User-Agent': XUNLEI_API_UA, 'Content-Type': 'application/json',
    'x-device-id': XUNLEI_DID, 'x-client-id': XUNLEI_CLIENT_ID,
    'x-captcha-token': token, 'Referer': 'https://pan.xunlei.com/',
  };
  if (parentId) {
    let pct = passCodeToken || '';
    if (!pct) {
      const u = 'https://api-pan.xunlei.com/drive/v1/share?share_id=' + encodeURIComponent(shareId)
        + '&pass_code=' + encodeURIComponent(pwd || '') + '&limit=1&pass_code_token=&page_token=&scene=NORMAL&order_by=';
      const r1 = await fetchTimeout(u, { headers: h }, 20000);
      const j1 = await r1.json();
      pct = j1.pass_code_token || '';
    }
    if (!pct) throw new Error('pass_code_token 获取失败');
    const u = 'https://api-pan.xunlei.com/drive/v1/share/detail?share_id=' + encodeURIComponent(shareId)
      + '&parent_id=' + encodeURIComponent(parentId) + '&pass_code_token=' + encodeURIComponent(pct);
    const r = await fetchTimeout(u, { headers: h }, 20000);
    const j = await r.json();
    return { ok: true, share_status: 'OK', files: j.files || [], pass_code_token: pct };
  }
  const u = 'https://api-pan.xunlei.com/drive/v1/share?share_id=' + encodeURIComponent(shareId)
    + '&pass_code=' + encodeURIComponent(pwd || '') + '&limit=100&pass_code_token=&page_token=&scene=NORMAL&order_by=';
  const r = await fetchTimeout(u, { headers: h }, 20000);
  const j = await r.json();
  if (j.share_status && j.share_status !== 'OK' && j.share_status !== 'PASS_CODE_EMPTY') {
    throw new Error('迅雷分享不可用: ' + j.share_status);
  }
  return { ok: true, share_status: j.share_status || 'OK', files: j.files || [], pass_code_token: j.pass_code_token || '' };
}

// 兜底：API 失败时回退到 Playwright 浏览器方案
function runXunleiPage(shareId, pwd, parentId, passCodeToken) {
  return new Promise((resolve, reject) => {
    const args = [XUNLEI_SCRIPT, shareId, pwd || ''];
    if (parentId) { args.push('--parent', parentId); }
    if (passCodeToken) { args.push('--token', passCodeToken); }
    execFile(XUNLEI_PY, args, { timeout: 60000, maxBuffer: 4 * 1024 * 1024 },
      (err, stdout, stderr) => {
        if (err) return reject(new Error('迅雷解析进程失败: ' + String(stderr || err.message).slice(0, 250)));
        try { resolve(JSON.parse(stdout.trim())); }
        catch (e) { reject(new Error('迅雷解析输出异常: ' + String(stdout || '').slice(0, 250))); }
      });
  });
}

async function xunleiResolve(url, cookie, opts = {}) {
  const shareId = (String(url).match(/\/s\/([A-Za-z0-9_-]+)/) || [])[1] || '';
  if (!shareId) throw new Error('无法识别迅雷云盘分享链接');
  // 2026-08-19 修：前端把 pass_code 单独传（body.pass_code），不拼进 share_url！
  //   旧代码只从 url 提取 pwd → 前端模式 PASS_CODE_EMPTY → 迅雷"响应异常"
  const pwd = String(opts.pass_code || opts.passcode || '').trim()
    || (String(url).match(/[?&#]pwd=([a-zA-Z0-9]+)/i) || [])[1] || '';
  // 2026-08-20：递归建树 → 前端本地切层（点文件夹零请求）。
  //   每层 = 1 次 runXunleiPage（spawn python + 浏览器）；MAX_DEPTH 控制总耗时：
  //   MAX_DEPTH=2 → 根 + 2 层 = 最坏 1 + N1 + N1*N2 次 spawn（N1=根文件夹数，N2=子文件夹数）
  //   实践中根层 1 个文件夹的占多数 → 通常 2 次 spawn ≈ 30-60s，可接受
  const MAX_DEPTH = Number(opts.maxDepth != null ? opts.maxDepth : 2);
  const passCodeToken = String(opts.stoken || opts.pass_code_token || '').trim();

  // 缓存本分享的提取码（detail 兜底用）
  if (pwd) xunleiPwdCache.set(shareId, pwd);

  // 递归取子节点（优先 API 直连，失败回退 Playwright 浏览器）
  const fetchLevel = async (parentId) => {
    // 2026-08-24 优化：优先用 API 直连（零浏览器 ~1s），失败回退 Playwright（~9s）
    try {
      return await runXunleiApi(shareId, pwd, parentId || undefined, passCodeToken || undefined);
    } catch (e) {
      console.warn('[xunlei] API 直连失败，回退 Playwright:', String(e).slice(0, 100));
    }
    const r = await runXunleiPage(shareId, pwd, parentId || undefined, passCodeToken || undefined);
    if (!r.ok || (r.share_status && r.share_status !== 'OK')) return { files: [], token: r.pass_code_token || '' };
    return { files: r.files || [], token: r.pass_code_token || passCodeToken };
  };
  const buildChildren = async (parentId, depth) => {
    if (depth > MAX_DEPTH) return [];
    let level;
    try { level = await fetchLevel(parentId); }
    catch (e) { console.warn('[xunlei] buildChildren level failed', parentId, String(e).slice(0,120)); return []; }
    const out = [];
    for (const f of level.files) {
      if (f.kind === 'drive#folder') {
        const sub = depth < MAX_DEPTH ? await buildChildren(f.id, depth + 1) : [];
        out.push({ name: f.name, type: 'folder', fid: f.id, children: sub });
      } else {
        out.push({ name: f.name, type: 'file', size: f.size || 0, fid: f.id, url: '' });
      }
    }
    return out;
  };

  // 根层
  let root;
  try { root = await fetchLevel(null); }
  catch (e) { throw new Error('迅雷解析失败: ' + String(e.message || e).slice(0, 200)); }
  const st0 = (root.files.length === 0) ? 'EMPTY' : 'OK';
  if (st0 !== 'OK') throw new Error('该分享没有可解析的文件（可能是空分享）');

  const tree = [];
  for (const f of root.files) {
    if (f.kind === 'drive#folder') {
      const sub = await buildChildren(f.id, 1);
      tree.push({ name: f.name, type: 'folder', fid: f.id, children: sub });
    } else {
      tree.push({ name: f.name, type: 'file', size: f.size || 0, fid: f.id, url: '' });
    }
  }
  const fileNodes = collectFileNodes(tree);
  if (!fileNodes.length && !tree.length) throw new Error('该分享没有可解析的文件（可能是空文件夹）');
  // 2026-08-20：下载阶段（!listOnly / allowSave）→ 转存到运营者迅雷云盘，拿转存后文件 ID。
  //   迅雷分享无公开直链（网页下载=转存到自己的云盘再下），故 fetch 返回转存结果，
  //   前端展示「已转存到迅雷云盘 + 我的云盘文件链接」。
  let transfer = null;
  if (!opts.listOnly) {
    try {
      // 2026-08-20 13:36：下载阶段按目标文件转存（opts.target_file = 用户点的文件名）
      transfer = await xunleiTransfer(shareId, pwd, opts.target_file || '');
    } catch (e) {
      console.warn('[xunlei] 转存失败(下载阶段):', String(e && e.message || e).slice(0, 120));
      // 2026-08-21 改：失败不再返回 null，带 {ok:false,error} 回去——
      //   server.js 据此识别 unauthenticated 自动刷新 JWT 重试（自愈）
      transfer = { ok: false, transferred: false, error: String(e && e.message || e).slice(0, 200) };
    }
  }
  return {
    tree,
    files: fileNodes.map((f) => ({ name: f.name, size: f.size, url: '', fid_token: f.fid })),
    stoken: root.token || '',
    full_tree: tree,  // 兼容其他 provider 的 full_tree 字段
    transfer,  // {ok, transferred, new_file_ids, title} 或 null
  };
}

// 迅雷转存（纯 API：captcha init 硬编码 + share + restore + tasks 轮询）
// 2026-08-20 对齐 wgx0307/netdisk：captcha_sign 硬编码 → 无需浏览器 WASM，服务器直接调
const XUNLEI_DL_PY = process.env.XUNLEI_DL_PY || '/home/ubuntu/pwand-playwright/xunlei_download.py';
async function xunleiTransfer(shareId, pwd, fileName) {
  const py = process.env.XUNLEI_PYTHON || '/home/ubuntu/pwand-playwright/venv/bin/python';
  const fs = require('fs');
  fs.appendFileSync('/tmp/xunlei_transfer.log', `[${new Date().toISOString()}] start ${shareId} pwd=${pwd} file=${fileName || ''} py=${py}\n`);
  return new Promise((resolve, reject) => {
    const args = [XUNLEI_DL_PY, String(shareId || ''), String(pwd || '')];
    // 2026-08-20 13:36：支持按目标文件转存（用户点哪个文件就转存哪个，快且准）
    if (fileName) args.push('--file', String(fileName));
    execFile(py, args,
      { timeout: 90000, maxBuffer: 4 * 1024 * 1024 }, (err, stdout, stderr) => {
        fs.appendFileSync('/tmp/xunlei_transfer.log', `[${new Date().toISOString()}] done err=${err ? err.message : 'null'} out=${String(stdout).slice(0, 120)} err2=${String(stderr).slice(0, 120)}\n`);
        if (err) {
          const detail = String(stderr || '').slice(0, 200) || String(err.message || err).slice(0, 200);
          console.warn('[xunlei-transfer-dbg] err.code=' + (err.code || '') + ' stderr=' + detail);
          return reject(new Error('迅雷转存失败: ' + detail));
        }
        try {
          const j = JSON.parse(stdout.trim());
          if (j.ok && j.transferred) resolve(j);
          else reject(new Error(j.error || '迅雷转存未完成'));
        } catch (e) {
          reject(new Error('迅雷转存响应解析失败'));
        }
      });
  });
}

// 迅雷提取码缓存（share 时写入，detail/fetch 兜底读取；内存级，重启即清，够用）
const xunleiPwdCache = new Map();
function getXunleiPwd(shareId) {
  return xunleiPwdCache.get(String(shareId || '')) || '';
}

async function mcloudResolve(url, cookie, opts = {}) {
  // 2026-08-19 修：支持三种链接形态
  //   1) https://yun.139.com/shareweb/#/w/i/{code}
  //   2) ?shareCode={code}
  //   3) /m/i?{code}
  const m1 = String(url).match(/shareCode=([a-zA-Z0-9]+)/i);
  const m2 = String(url).match(/\/w\/i\/([a-zA-Z0-9]+)/i);
  const m3 = String(url).match(/\/m\/i\?([^&]+)/i);
  const code = (m1 ? m1[1] : (m2 ? m2[1] : (m3 ? (m3[1].includes('=') ? m3[1].split('=')[1] : m3[1]) : '')));
  if (!code) throw new Error('无法识别移动云盘分享链接');
  // 2026-08-19 修：改用 AList 新接口 share-kd-njs.yun.139.com（caiyun.139.com 服务器连不上）
  //   POST /yun-share/richlifeApp/devapp/IOutLink/getOutLinkInfoV6，明文 JSON 可调（无需加密）
  //   该接口「一层一查」：pCaID='root' 返根层（caLst=文件夹 / coLst=文件）；
  //   要取某文件夹内容需再以该文件夹 caID 作为 pCaID 再查一次。旧实现只查 root 且漏掉 coLst，
  //   → 永远只看到分享根文件夹、拿不到真实文件。现改为递归下钻。
  const API = 'https://share-kd-njs.yun.139.com/yun-share/richlifeApp/devapp/IOutLink/getOutLinkInfoV6';
  const headers = { 'User-Agent': 'Mozilla/5.0', 'Content-Type': 'application/json' };
  // 2026-08-20 修复：有提取码的分享不传 passwd → 139 返回 9188「提取码非法」→ 解析为空文件夹。
  //   从 URL ?pwd= / opts.pass_code / opts.passcode 提取（参考 share139-proxy 的 requestOutLinkInfo 传 passwd）
  const mPwd = String(url).match(/[?&#]pwd=([a-zA-Z0-9]+)/i);
  const sharePwd = (mPwd && mPwd[1]) || String(opts.pass_code || opts.passcode || '').trim() || '';
  const fetchLevel = async (pCaID) => {
    const reqBody = { getOutLinkInfoReq: { account: '', linkID: code, pCaID } };
    if (sharePwd) reqBody.getOutLinkInfoReq.passwd = sharePwd;
    const resp = await fetchTimeout(API, {
      method: 'POST', headers,
      body: JSON.stringify(reqBody),
    });
    const info = await resp.json().catch(() => ({}));
    // 2026-08-19 修：resultCode 实际返回 "0"（字符串），旧条件只认 '000000'/'00000000' 误判失败
    if (info.code !== 0 && info.resultCode !== '0' && info.resultCode !== '000000' && info.resultCode !== '00000000' && !info.success) {
      throw new Error(info.desc || info.message || '获取移动云盘分享信息失败');
    }
    const data = info.data || {};
    // caLst=文件夹（caID/caName），coLst=文件（coID/coName/coSize）
    const folders = (data.caLst || []).map((c) => ({ name: c.caName || c.CaName, caID: c.caID || c.CaID }));
    const files = (data.coLst || []).map((c) => ({ name: c.coName || c.CoName, size: c.coSize || c.CoSize || 0, coID: c.coID || c.CoID }));
    return { folders, files };
  };
  // 递归下钻：取某 caID 层级的文件夹 + 文件，并对子文件夹继续下钻（限深 8，防失控）
  // 2026-08-20：节点带 path（coID 路径：根层=coID，子层=父path/coID）——
  //   dlFromOutLinkV3 的 coIDLst.item 需要完整路径（参考 share139-proxy）
  const buildTree = async (pCaID, depth, parentPath) => {
    const { folders, files } = await fetchLevel(pCaID);
    const nodes = [];
    for (const f of folders) {
      const folder = { name: f.name, type: 'folder', fid: f.caID, children: [] };
      const folderPath = folder.fid ? (parentPath ? `${parentPath}/${folder.fid}` : folder.fid) : '';
      if (depth < 8) folder.children = await buildTree(f.caID, depth + 1, folderPath);
      nodes.push(folder);
    }
    for (const fl of files) {
      const coPath = fl.coID ? (parentPath ? `${parentPath}/${fl.coID}` : fl.coID) : '';
      nodes.push({ name: fl.name, type: 'file', size: fl.size, fid: fl.coID, path: coPath, url: '' });
    }
    return nodes;
  };
  // 根层：若根只有「一个文件夹、无文件」→ 分享本身是一个文件夹，以其为根递归取内容
  const root = await fetchLevel('root');
  let tree;
  if (root.folders.length === 1 && root.files.length === 0) {
    const sf = root.folders[0];
    tree = [{ name: sf.name, type: 'folder', fid: sf.caID, children: await buildTree(sf.caID, 0, sf.caID) }];
  } else {
    tree = await buildTree('root', 0, '');
  }

  const fileNodes = collectFileNodes(tree);
  if (!fileNodes.length && !tree.length) throw new Error('该分享没有可解析的文件（可能是空文件夹）');

  // 下载直链（非 listOnly 时才请求，避免解析阶段动用 Cookie）
  // 2026-08-20 改：getDownloadUrl 04000005 认证失败（端到端加密），改用 AList drivers/139 方案：
  //   加密 body（AES-128-CBC Key=PVGDwmcvfs1uV3d1）→ getContentInfoFromOutLink →
  //   Authorization: Basic base64("pc:<手机号>:<auth_token>") → 解密响应拿 cdnDownLoadUrl/presentURL
  // 2026-08-20 改2（用户追问「exe 不返直链」）：getContentInfoFromOutLink 只对视频返回 presentURL(HLS)，
  //   普通文件（exe/zip/pdf）用 share139-proxy 的 dlFromOutLinkV3 接口拿 redrUrl/downloadURL（真实下载直链）。
  //   → 下载直链主通道 = dlFromOutLinkV3；getContentInfoFromOutLink 保留作视频 HLS 兜底。
  if (!opts.listOnly) {
    const cryptoLib = require('crypto');
    const MC_KEY = Buffer.from('PVGDwmcvfs1uV3d1', 'utf8');
    const yunEncrypt = (obj) => {
      const json = JSON.stringify(obj);
      const iv = cryptoLib.randomBytes(16);
      const cipher = cryptoLib.createCipheriv('aes-128-cbc', MC_KEY, iv);
      const ct = Buffer.concat([cipher.update(Buffer.from(json, 'utf8')), cipher.final()]);
      return Buffer.concat([iv, ct]).toString('base64');
    };
    const yunDecrypt = (b64) => {
      try {
        const raw = Buffer.from(String(b64).replace(/\s+/g, ''), 'base64');
        const iv = raw.subarray(0, 16), ct = raw.subarray(16);
        const dc = cryptoLib.createDecipheriv('aes-128-cbc', MC_KEY, iv);
        let out = Buffer.concat([dc.update(ct), dc.final()]);
        if (out.length > 2 && out[0] === 0x1f && out[1] === 0x8b) {
          try { out = require('zlib').gunzipSync(out); } catch (e) {}
        }
        const pad = out[out.length - 1];
        if (pad > 0 && pad <= 16) out = out.subarray(0, out.length - pad);
        return out.toString('utf8');
      } catch (e) { return ''; }
    };
    // 从运营者 cookie 提取账号 + authToken（AList 139 鉴权）
    // 2026-08-20 增强（share139-proxy 参考）：兼容三种配置——
    //   1) Cookie 含 Authorization=Basic xxx（share139 导入 token 模式，直接可用）
    //   2) Cookie 含 ORCHES-I-ACCOUNT-ENCRYPT(base64=手机号) + auth_token → 拼 Basic
    //   3) 后台 cookies.mcloud 直接填「Basic base64(pc:手机号:token)」整串
    const getCk = (k) => (String(cookie || '').match(new RegExp('(?:^|;\\s*)' + k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '=([^;]*)')) || [])[1] || '';
    let account = '', auth = '';
    try {
      // 优先：Cookie 里直接带 authorization / Authorization
      const rawAuth = getCk('authorization') || getCk('Authorization');
      if (rawAuth) {
        auth = rawAuth.startsWith('Basic ') || rawAuth.startsWith('basic ')
          ? rawAuth : 'Basic ' + rawAuth;
        // 从 Authorization 解出账号（pc:手机号:token → 中段）
        try {
          const decoded = Buffer.from(auth.replace(/^Basic\s+/i, ''), 'base64').toString('utf8');
          const parts = decoded.split(':');
          if (parts.length >= 2) account = parts[1];
        } catch {}
      }
      // 兜底：ORCHES-I-ACCOUNT-ENCRYPT + auth_token 拼装
      if (!auth) {
        const enc = getCk('ORCHES-I-ACCOUNT-ENCRYPT');
        if (enc) account = Buffer.from(enc, 'base64').toString('utf8');
        const authToken = getCk('auth_token');
        if (account && authToken) auth = 'Basic ' + Buffer.from('pc:' + account + ':' + authToken, 'utf8').toString('base64');
      }
      // 再兜底：整串直接就是 Basic base64（无前缀则尝试补 pc: 前缀）
      if (!auth && /^[A-Za-z0-9+/=]{30,}$/.test(String(cookie || '').trim())) {
        auth = 'Basic ' + String(cookie).trim();
        try {
          const decoded = Buffer.from(auth.replace(/^Basic\s+/i, ''), 'base64').toString('utf8');
          const parts = decoded.split(':');
          if (parts.length >= 2) account = parts[1];
        } catch {}
      }
    } catch (e) {}
    const shareHost = 'https://share-kd-njs.yun.139.com/yun-share/richlifeApp/devapp/IOutLink';
    const mcloudUA = 'Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0';
    // share139-proxy 同款请求头（dlFromOutLinkV3 必须带，否则 resultCode != 0）
    const dlHeaders = {
      'User-Agent': mcloudUA, 'Accept': 'application/json, text/plain, */*',
      'Content-Type': 'application/json;charset=UTF-8',
      'X-Deviceinfo': '||9|12.27.0|firefox|140.0|12b780037221ab547c682223327dc9cd||linux unknow|1920X526|zh-CN|||',
      'hcy-cool-flag': '1', 'CMS-DEVICE': 'default', 'x-m4c-caller': 'PC',
      'X-Yun-Api-Version': 'v1', 'Origin': 'https://yun.139.com', 'Referer': 'https://yun.139.com/',
      'Inner-Hcy-Router-Https': '1', 'mcloud-channel': '1000101', 'mcloud-client': '10702',
      'mcloud-route': '001', 'mcloud-version': '7.13.3',
    };
    if (auth) dlHeaders.Authorization = auth;
    const allFiles = collectFileNodes(tree);
    // 2026-08-21 修（全局审计 P1）：fetch/prepare 阶段只对**目标文件**取直链
    //   （opts.target_file = 用户点的文件，对齐 pan123 targetSet 先例）。
    //   之前全量 Promise.all → 大分享几十个加密请求齐发 → 慢 + 139 风控风险。
    //   其他文件保持空直链，前端点它们时再 fetch 单独准备。
    const mcTarget = opts.target_file ? new Set([String(opts.target_file)]) : null;
    const dlFiles = mcTarget ? allFiles.filter((n) => mcTarget.has(String(n.name))) : allFiles;
    await Promise.all(dlFiles.map(async (n) => {
      try {
        if (!auth) { n.url = ''; n._noAuth = true; return; }
        // ===== 主通道：dlFromOutLinkV3（普通文件直链 redrUrl/downloadURL）=====
        // 2026-08-20（share139-proxy 同款 body）：
        //   { dlFromOutLinkReqV3: { linkID, account, coIDLst: { item: [filePath] } },
        //     commonAccountInfo: { account, accountType: 1 } }
        //   item 传文件 coID 路径（根层=coID，子层=父path/coID）
        const dlPath = n.path || n.fid;
        if (dlPath) {
          const dlReq = {
            dlFromOutLinkReqV3: {
              linkID: code, account,
              coIDLst: { item: [dlPath] },
            },
            commonAccountInfo: { account, accountType: 1 },
          };
          const encBody = yunEncrypt(dlReq);
          const dlResp = await fetchTimeout(shareHost + '/dlFromOutLinkV3', {
            method: 'POST', headers: dlHeaders, body: encBody,
          });
          const raw = await dlResp.text().catch(() => '');
          const dec = yunDecrypt(raw) || raw;
          let dl;
          try { dl = JSON.parse(dec); } catch (e) { dl = {}; }
          // share139-proxy 同款响应：json.data.redrUrl || json.data.downloadURL
          const dlData = dl.data || {};
          const dlUrl = dlData.redrUrl || dlData.downloadURL || dlData.downloadUrl || dlData.url || '';
          if (dlUrl) { n.url = dlUrl; return; }
        }
        // ===== 兜底：getContentInfoFromOutLink（视频 presentURL/HLS）=====
        // 2026-08-20 参考 CloudHub-139：带 commonAccountInfo（account+accountType），提高成功率
        const infoReq = {
          getContentInfoFromOutLinkReq: { contentId: n.fid, linkID: code, account },
          commonAccountInfo: { account, accountType: 1 },
        };
        const encBody2 = yunEncrypt(infoReq);
        const dlResp2 = await fetchTimeout(shareHost + '/getContentInfoFromOutLink', {
          method: 'POST',
          headers: dlHeaders,
          body: encBody2,
        });
        const raw2 = await dlResp2.text().catch(() => '');
        const dec2 = yunDecrypt(raw2) || raw2;
        let dl2;
        try { dl2 = JSON.parse(dec2); } catch (e) { dl2 = {}; }
        const ci = (dl2.data && dl2.data.contentInfo) || dl2.contentInfo || {};
        n.url = ci.cdnDownLoadUrl || ci.presentURL || ci.downloadURL || ci.url || '';
      } catch (e) { /* 单文件失败不阻断整体 */ }
    }));
    // 2026-08-20：缺鉴权时给出明确提示（否则前端拿空直链无从排查）
    const noAuthCnt = dlFiles.filter((f) => f._noAuth).length;
    if (noAuthCnt === dlFiles.length && dlFiles.length > 0) {
      throw new Error('移动云盘未配置有效账号鉴权（需 Cookie 含 ORCHES-I-ACCOUNT-ENCRYPT 与 auth_token，或后台填账号密码）');
    }
  }
  return { tree, files: fileNodes.map((f) => ({ name: f.name, size: f.size, url: f.url, fid_token: f.fid })) };
}
module.exports = { baiduResolve, pan123Resolve, xunleiResolve, mcloudResolve, runXunleiPage, runXunleiApi, getXunleiPwd, xunleiTransfer, baiduListPage, baiduPageDownload, baiduTransfer, pan123Sign, buildBaiduFullTree };

// 百度下载直链页面方案（baidu_page.py --download：点击文件 → 捕获 sharedownload 响应）
// 2026-08-20：sharedownload 返回的 list 是加密串，需页面上下文解密（d.pcs.baidu.com locatedownload 二次转换）
//   直接返回浏览器捕获到的直链文本（页面已解析出真实 dlink）
async function baiduPageDownload(surl, pwd, subdir, fileName) {
  const py = process.env.XUNLEI_PYTHON || '/home/ubuntu/pwand-playwright/venv/bin/python';
  const clean = String(surl || '').replace(/^1/, '');
  return new Promise((resolve, reject) => {
    const args = [BAIDU_PAGE_PY, clean, String(pwd || '')];
    if (subdir) args.push('--dir', String(subdir));
    if (fileName) args.push('--download', String(fileName));
    execFile(py, args, { timeout: 90000, maxBuffer: 4 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) return reject(new Error('百度下载失败: ' + String(err.message || err).slice(0, 120)));
      try {
        const j = JSON.parse(stdout.trim());
        if (j.ok && j.url) resolve(j.url);
        else reject(new Error(j.error || '百度下载失败'));
      } catch (e) {
        reject(new Error('百度下载响应解析失败'));
      }
    });
  });
}

// 2026-08-20 14:05：百度「转存下载删除」方案（用户拍板，对齐迅雷/123 同构）
//   百度分享直链 2026 已失效（sharedownload 返回加密 list / locatedownload 分享侧 404）
//   → Playwright 拿 sekey → share/transfer 转存到管理员网盘（同步完成）
//   → locatedownload 自己网盘文件（path 定位，无需 md5/sekey）→ allall 直链 → 可选删除
const BAIDU_TRANSFER_PY = process.env.BAIDU_TRANSFER_PY || '/home/ubuntu/pwand-playwright/baidu_transfer.py';
async function baiduTransfer(surl, pwd, fsId) {
  const py = process.env.XUNLEI_PYTHON || '/home/ubuntu/pwand-playwright/venv/bin/python';
  const clean = String(surl || '').replace(/^1/, '');
  return new Promise((resolve, reject) => {
    // 2026-08-20 15:25：去掉 --delete —— 转存后立即删除会让 allall 直链 403（文件不存在）！
    //   改为：转存文件保留（占管理员网盘），直链有效期内可用；清理交给定期任务（cleanup）
    execFile(py, [BAIDU_TRANSFER_PY, clean, String(pwd || ''), String(fsId || '')],
      { timeout: 90000, maxBuffer: 4 * 1024 * 1024 }, (err, stdout, stderr) => {
        if (err) return reject(new Error('百度转存下载失败: ' + String(err.message || err).slice(0, 150)));
        try {
          const j = JSON.parse(stdout.trim());
          if (j.ok && j.url) resolve(j);
          else reject(new Error(j.error || '百度转存下载未完成'));
        } catch (e) {
          reject(new Error('百度转存下载响应解析失败'));
        }
      });
  });
}

// 百度子目录页面方案（Playwright 真实点击 + 捕获响应；解决 wxlist -130 / share/list 直调 -9）
// 2026-08-20：百度已弃用 wxlist 子目录（-130），/share/list 直调需完整浏览器会话（-9），
//   唯一直连路径 = 真实浏览器打开分享页点击文件夹，捕获页面真实 share/list 响应。
const BAIDU_PAGE_PY = process.env.BAIDU_PAGE_PY || '/home/ubuntu/pwand-playwright/baidu_page.py';
// 2026-08-20：百度页面方案递归建完整树（用户端固定树，进文件夹本地切层零请求）。
// 每层文件夹并行递归（Playwright 独立进程），深度/数量受限防爆炸。
async function buildBaiduFullTree(surl, pwd, fsPath = '', depth = 0) {
  const MAX_DEPTH = 6;
  const MAX_DIRS_PER_LEVEL = 20;
  if (depth > MAX_DEPTH) return [];
  const files = await baiduListPage(surl, pwd, fsPath);
  const dirs = (files || []).filter((f) => f.is_dir).slice(0, MAX_DIRS_PER_LEVEL);
  const fileNodes = (files || []).filter((f) => !f.is_dir)
    .map((f) => ({ name: f.name, type: 'file', size: f.size, fs_id: f.fs_id, url: '' }));
  const folderNodes = [];
  let idx = 0;
  async function worker() {
    while (idx < dirs.length) {
      const dir = dirs[idx++];
      const childPath = fsPath ? `${fsPath}/${dir.fs_id}` : String(dir.fs_id);
      try {
        const children = await buildBaiduFullTree(surl, pwd, childPath, depth + 1);
        folderNodes.push({ name: dir.name, type: 'folder', fs_id: dir.fs_id, children });
      } catch (err) {
        folderNodes.push({ name: dir.name, type: 'folder', fs_id: dir.fs_id, children: [] });
      }
    }
  }
  await Promise.all([worker(), worker(), worker()]);
  return [...folderNodes, ...fileNodes];
}

async function baiduListPage(surl, pwd, subdir) {
  const py = process.env.XUNLEI_PYTHON || '/home/ubuntu/pwand-playwright/venv/bin/python';
  // surl 可能带 `1` 前缀（parseBaiduUrl 从 /s/1xxx 提取）；脚本内部自己处理 full_surl，
  // 传给脚本的必须是「纯短链」（fetch shorturl 参数用），否则 shorturl=1xxx 报错
  const clean = String(surl || '').replace(/^1/, '');
  return new Promise((resolve, reject) => {
    const args = [BAIDU_PAGE_PY, clean, String(pwd || '')];
    if (subdir) args.push('--dir', String(subdir));
    execFile(py, args, { timeout: 60000, maxBuffer: 4 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) return reject(new Error('百度子目录解析失败: ' + String(err.message || err).slice(0, 150)));
      try {
        const j = JSON.parse(stdout.trim());
        if (j.ok) resolve(j.files || []);
        else reject(new Error(j.error || '百度子目录解析失败'));
      } catch (e) {
        reject(new Error('百度子目录响应解析失败'));
      }
    });
  });
}
