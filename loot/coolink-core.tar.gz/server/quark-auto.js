// Cool Link 每日密码自动生成程序：每天为各网盘生成「今日密码」并上传分享
// 统一结构（用户 2026-08-16 明确）：
//   外层文件夹「(日期)解析下载密码」 → 内含 zip「今日密码.zip」
//   zip 内含两个文件夹：
//     ① 「(日期)密码」 → password.txt（真实密码只存在于 txt 内容，绝不出现在任何文件名上）
//     ② 「问题可反馈，小网站维持不易，多多体谅」 → 说明.txt（反馈引导）
//   分享对象 = 外层文件夹（用户打开先见文件夹 → 点进去才是 zip）
// 已接入生成器：quark（夸克，2026-08-16 实测成功）/ mcloud（移动云盘，SDK 协议）/ xunlei（迅雷，Google Drive 风格协议）
// 供 server.js 每日零点调用；密码与任务的 answer 匹配（用户做任务时输入今日密码）
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');
// 2026-08-19 调优：外部请求超时（防网盘 API 卡死 hang 住进程）
const FETCH_TIMEOUT_MS = 15000;
function fetchTimeout(url, init = {}, timeoutMs = FETCH_TIMEOUT_MS) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  return fetch(url, { ...init, signal: ctrl.signal }).finally(() => clearTimeout(timer));
}


const QUARK_API = 'https://pan.quark.cn';
const QUARK_DRIVE = 'https://drive-pc.quark.cn';
const QUARK_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) quark-cloud-drive/2.5.20 Chrome/100.0.4896.160 Electron/18.3.5.4-b478491100 Safari/537.36 Channel/pckk_other_ch';

// 今日密码持久化：data/daily_passwords.json
// 结构（用户 2026-08-15 澄清：网盘密码与任务分开，6 网盘每天各生成不同密码）：
//   { date, codes: { quark:'1234', baidu:'5678', ... }, shares: { quark:'url', ... },
//     state: { quark:{status:'ok', code, share_url, updated_at} | {status:'error', error, updated_at}
//              | {status:'disabled'} | {status:'no_cookie'} }, created_at }
// ⚠️ 日期一律用「北京时间」：new Date().toISOString() 是 UTC（北京 00:00 时 UTC 还是前一天），
//    之前用 UTC 导致零点定时器认为「今天已生成」而跳过 → 密码自动生成不生效（用户 2026-08-16 定位）
function dateStrCN(d = new Date()) {
  return new Date(d.getTime() + 8 * 3600 * 1000).toISOString().slice(0, 10);
}
function passwordFile() {
  return path.join(__dirname, '..', 'data', 'daily_passwords.json');
}
function loadDailyPasswords() {
  try {
    if (fs.existsSync(passwordFile())) {
      const d = JSON.parse(fs.readFileSync(passwordFile(), 'utf8'));
      const today = dateStrCN();
      if (d && d.date === today) return d;
    }
  } catch {}
  return null;
}
// 兼容旧名（server.js 引用处逐步迁移）
function loadTodayPassword() {
  const d = loadDailyPasswords();
  if (!d) return null;
  // 旧接口语义：返回首个有密码的网盘（兼容单网盘时期代码）
  const codes = d.codes || {};
  const firstKey = Object.keys(codes)[0];
  return { date: d.date, code: firstKey ? codes[firstKey] : '', share_url: d.shares && d.shares[firstKey] || '' };
}
function saveTodayPassword(data) {
  fs.mkdirSync(path.dirname(passwordFile()), { recursive: true });
  // 支持多网盘合并写入：{date, code, share_url, provider, status, error} 追加到 codes/shares/state
  const existing = loadDailyPasswords() || { date: dateStrCN(), codes: {}, shares: {}, state: {} };
  existing.state = existing.state || {};
  if (data.provider) {
    const p = data.provider;
    existing.codes = existing.codes || {};
    existing.shares = existing.shares || {};
    if (data.code) {
      existing.codes[p] = data.code;
      if (data.share_url) existing.shares[p] = data.share_url;
      existing.state[p] = { status: 'ok', code: data.code, share_url: data.share_url || '', updated_at: Date.now() };
    } else {
      // 失败/未启用等状态记录
      const st = { status: data.status || 'error', updated_at: Date.now() };
      if (data.error) st.error = data.error;
      existing.state[p] = st;
      // 状态非 ok 时，不写入 codes（保证只有有效密码会被任务校验采用）
      if (st.status === 'ok' && data.code) { existing.codes[p] = data.code; }
      if (st.status === 'ok' && data.share_url) existing.shares[p] = data.share_url;
    }
    existing.created_at = Date.now();
    fs.writeFileSync(passwordFile(), JSON.stringify(existing, null, 2));
    return existing;
  }
  fs.writeFileSync(passwordFile(), JSON.stringify(data, null, 2));
  return data;
}

// 生成 4 位随机数字密码（1000-9999）
function genCode() {
  // 2026-08-22 安全加固：4 位 → 6 位（暴力破解空间 9000 → 900000）
  return String(100000 + Math.floor(Math.random() * 900000));
}

// 构造 zip（通用：entries = [{name: Buffer, data: Buffer}]，文件名 UTF-8 flag 置位，兼容中文）
function buildZip(entries) {
  const UTF8_FLAG = 0x0800;
  const entryMeta = entries.map((e) => ({ ...e, crc: crc32buf(e.data) }));
  let offset = 0;
  const lfhs = [];
  const cds = [];
  for (const e of entryMeta) {
    const lfh = Buffer.alloc(30);
    lfh.writeUInt32LE(0x04034b50, 0);
    lfh.writeUInt16LE(20, 4);
    lfh.writeUInt16LE(UTF8_FLAG, 6);
    lfh.writeUInt16LE(0, 8);
    lfh.writeUInt16LE(0, 10);
    lfh.writeUInt16LE(0x21, 12);
    lfh.writeUInt32LE(e.crc, 14);
    lfh.writeUInt32LE(e.data.length, 18);
    lfh.writeUInt32LE(e.data.length, 22);
    lfh.writeUInt16LE(e.name.length, 26);
    lfh.writeUInt16LE(0, 28);
    lfhs.push({ lfh, name: e.name, data: e.data, offset });
    const cdh = Buffer.alloc(46);
    cdh.writeUInt32LE(0x02014b50, 0);
    cdh.writeUInt16LE(20, 4);
    cdh.writeUInt16LE(20, 6);
    cdh.writeUInt16LE(UTF8_FLAG, 8);
    cdh.writeUInt16LE(0, 10);
    cdh.writeUInt16LE(0, 12);
    cdh.writeUInt16LE(0, 14);
    cdh.writeUInt32LE(e.crc, 16);
    cdh.writeUInt32LE(e.data.length, 20);
    cdh.writeUInt32LE(e.data.length, 24);
    cdh.writeUInt16LE(e.name.length, 28);
    cdh.writeUInt16LE(0, 30);
    cdh.writeUInt16LE(0, 32);
    cdh.writeUInt16LE(0, 34);
    cdh.writeUInt16LE(0, 36);
    cdh.writeUInt32LE(0, 38);
    cdh.writeUInt32LE(offset, 42);
    cds.push({ cdh, name: e.name });
    offset += 30 + e.name.length + e.data.length;
  }
  const cdSize = cds.reduce((s, c) => s + 46 + c.name.length, 0);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(entryMeta.length, 8);
  eocd.writeUInt16LE(entryMeta.length, 10);
  eocd.writeUInt32LE(cdSize, 12);
  eocd.writeUInt32LE(offset, 16);
  eocd.writeUInt16LE(0, 20);
  const parts = [];
  for (const l of lfhs) parts.push(l.lfh, l.name, l.data);
  for (const c of cds) parts.push(c.cdh, c.name);
  parts.push(eocd);
  return Buffer.concat(parts);
}

// 每日密码 zip（2026-08-21 参考「解析密码_YYYYMMDD_HHMM.zip」结构）：
//   zip 内含两个文件夹：
//     ① 「先看说明再点我」→ {资源名}【{网盘}{M}月{D}号解析密码】.zip（内层 zip，含同名 txt：M月D号解析密码：code）
//     ② 「获取前必须先看我【防止后悔】」→ 领取前必看操作.txt（操作引导文案）
//   返回 { zip, name: '解析密码_YYYYMMDD_HHMM.zip' }（真实密码只存在于内层 txt 内容，不在文件名）
function makeZip(code, dateStr, providerName, resourceName, opts) {
  const M = parseInt(dateStr.slice(4, 6), 10);
  const D = parseInt(dateStr.slice(6, 8), 10);
  // 2026-08-21 修（全局审计 P2）：HH/MM 原用服务器本地时区（服务器=UTC 时差 8 小时），
  //   统一为北京时间（与 dateStrCN 同一套偏移逻辑）
  const nowCN = new Date(Date.now() + 8 * 3600 * 1000);
  // 2026-08-29 修（P0 容量超限根因）：HHMM 取「当前分钟」→ 每日密码调度在 00:00-00:10
  //   窗口内每分钟重试一次，每次 HHMM 不同 → 每天新建 10 个文件夹（0000~0009），
  //   8/21~8/29 累计 59 项，最终撑爆夸克容量（code 32003 capacity limit）。
  //   opts.stable=true 时 HHMM 固定为 '0000'：同一天无论重试多少次都复用同一文件夹（幂等）。
  const stable = !!(opts && opts.stable);
  const HH = stable ? '00' : String(nowCN.getUTCHours()).padStart(2, '0');
  const MM = stable ? '00' : String(nowCN.getUTCMinutes()).padStart(2, '0');
  const innerName = resourceName + '【' + providerName + M + '月' + D + '号解析密码】';
  const innerContent = Buffer.from(M + '月' + D + '号解析密码：' + code + '\n', 'utf8');
  const innerZip = buildZip([
    { name: Buffer.from(innerName + '.txt', 'utf8'), data: innerContent },
  ]);
  const guide = Buffer.from(
    '欢迎使用本工具。请勿给其他人使用本任务答案，如果发现永久拉黑IP和设备\n\n' +
    '首次使用建议花10秒阅读下面内容，可以避免90%以上的问题。\n\n' +
    '① 复制任务答案\n② 打开解析网站\n③ 粘贴任务答案\n④ 点击提交即可获取20次解析机会\n⑤ 如果失败，请联系站长\n\n', 'utf8');
  const outerName = '解析密码_' + dateStr + '_' + HH + MM;
  const outerZip = buildZip([
    { name: Buffer.from('先看说明再点我/', 'utf8'), data: Buffer.alloc(0) },
    { name: Buffer.from('先看说明再点我/' + innerName + '.zip', 'utf8'), data: innerZip },
    { name: Buffer.from('获取前必须先看我【防止后悔】/', 'utf8'), data: Buffer.alloc(0) },
    { name: Buffer.from('获取前必须先看我【防止后悔】/领取前必看操作.txt', 'utf8'), data: guide },
  ]);
  return { zip: outerZip, name: outerName + '.zip' };
}

function crc32buf(buf) {
  let table = crc32buf._t;
  if (!table) {
    table = crc32buf._t = new Int32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      table[n] = c;
    }
  }
  let crc = -1;
  for (let i = 0; i < buf.length; i++) crc = (crc >>> 8) ^ table[(crc ^ buf[i]) & 0xff];
  return (crc ^ -1) >>> 0;
}

// 通用夸克请求（带 __puus 自动续期，与 server.js quarkRequest 同构）
function makeRequester(cookie) {
  let cookieRef = { value: cookie };
  async function req(method, url, data, rawHeaders = {}) {
    const headers = {
      Cookie: cookieRef.value,
      'User-Agent': QUARK_UA,
      Referer: QUARK_API + '/',
      Origin: QUARK_API,
      'Content-Type': 'application/json;charset=UTF-8',
      ...rawHeaders,
    };
    const init = { method, headers };
    if (method === 'POST' && data !== undefined) init.body = typeof data === 'string' ? data : JSON.stringify(data);
    const resp = await fetchTimeout(url, init);
    const setCookies = typeof resp.headers.getSetCookie === 'function' ? resp.headers.getSetCookie() : [];
    for (const sc of setCookies) {
      if (sc && sc.startsWith('__puus')) {
        const v = sc.split(';')[0];
        const m = v.match(/__puus=([^;]+)/);
        if (m) cookieRef.value = cookieRef.value.replace(/__puus=[^;\s]+/, '__puus=' + m[1]);
        break;
      }
    }
    if (resp.status >= 400) {
      const txt = await resp.text().catch(() => '');
      throw new Error('夸克 HTTP ' + resp.status + ': ' + txt.slice(0, 200));
    }
    const body = await resp.json().catch(() => ({}));
    if (body.code && body.code !== 0) throw new Error('夸克 code=' + body.code + ': ' + (body.message || ''));
    return body;
  }
  return { req, getCookie: () => cookieRef.value };
}

// 查找根目录下同名文件夹（夸克同名文件夹不可重复创建，存在则复用）
async function findFolderId(req, name) {
  try {
    const r = await req('GET', `${QUARK_DRIVE}/1/clouddrive/file/sort?pr=ucpro&fr=pc&uc_param_str=&pdir_fid=0&_page=1&_size=100&_fetch_total=1&_sort=file_type:asc,updated_at:desc`);
    const list = (r.data && r.data.list) || [];
    for (const it of list) {
      if (it.file_type === 0 && it.file_name === name) return it.fid;
    }
  } catch (e) {
    console.log('[daily-pwd] 查找文件夹失败(忽略):', e.message);
  }
  return null;
}
// 查找文件夹内同名文件
async function findFileFid(req, pdirFid, name) {
  try {
    const r = await req('GET', `${QUARK_DRIVE}/1/clouddrive/file/sort?pr=ucpro&fr=pc&uc_param_str=&pdir_fid=${pdirFid}&_page=1&_size=100&_fetch_total=1&_sort=file_type:asc,updated_at:desc`);
    const list = (r.data && r.data.list) || [];
    for (const it of list) {
      if (it.file_name === name) return it.fid;
    }
  } catch (e) {
    console.log('[daily-pwd] 查找文件失败(忽略):', e.message);
  }
  return null;
}

// ============ 旧密码文件夹自动清理（2026-08-29 增，P0 根因防御）============
//   背景：命名稳定后每天仍会新增 1 个文件夹，一年 365 个；历史还堆过 59 个。
//   策略：生成成功后顺带清理超过 DAILY_PWD_KEEP_DAYS 天的旧密码文件夹（旧密码早已过期，
//   其分享链接无人再用）。清理失败不影响主流程（仅打日志）。
const DAILY_PWD_KEEP_DAYS = 7;
async function cleanupOldPwdFolders(req, base, pr, today) {
  try {
    const dayMs = 24 * 3600 * 1000;
    const keepAfter = new Date(today + 'T00:00:00+08:00').getTime() - DAILY_PWD_KEEP_DAYS * dayMs;
    const r = await req('GET', `${base}/1/clouddrive/file/sort?pr=${pr}&fr=pc&uc_param_str=&pdir_fid=0&_page=1&_size=200&_fetch_total=1&_sort=file_type:asc,updated_at:desc`);
    const list = (r.data && r.data.list) || [];
    const stale = [];
    for (const f of list) {
      const m = /^解析密码_(\d{4}-\d{2}-\d{2})_/.exec(f.file_name || '');
      if (!m) continue;
      const ts = new Date(m[1] + 'T00:00:00+08:00').getTime();
      if (ts && ts < keepAfter) stale.push(f.fid);
    }
    if (!stale.length) return 0;
    await req('POST', `${base}/1/clouddrive/file/delete?pr=${pr}&fr=pc&uc_param_str=`, {
      action_type: 1, filelist: stale, exclude_fids: [],
    });
    console.log(`[daily-pwd] 已清理 ${stale.length} 个超过 ${DAILY_PWD_KEEP_DAYS} 天的旧密码文件夹`);
    return stale.length;
  } catch (e) {
    console.log('[daily-pwd] 清理旧密码文件夹失败(忽略):', e.message);
    return 0;
  }
}

// ============ 夸克上传 + 分享全链路 ============
// 2026-08-29 修（P0，与 makeZip stable 命名配套）：失败回滚。
//   本次新建文件夹后，若后续步骤（删旧 zip / 预上传 / 上传 / 分享）失败，
//   删除该残留空文件夹 —— 否则每次重试都留一个空壳，日积月累撑爆容量。
async function quarkRunDaily(cookie) {
  const rb = {};
  try {
    return await quarkRunDailyInner(cookie, rb);
  } catch (e) {
    if (rb.newFolderId && rb.req) {
      try {
        await rb.req('POST', `${QUARK_DRIVE}/1/clouddrive/file/delete?pr=ucpro&fr=pc&uc_param_str=`, {
          action_type: 2, filelist: [rb.newFolderId], exclude_fids: [],
        });
        console.log('[daily-pwd] 回滚：已删除本次新建的残留文件夹', rb.newFolderId);
      } catch (e2) {
        console.log('[daily-pwd] 回滚删除失败(忽略):', e2.message);
      }
    }
    throw e;
  }
}
async function quarkRunDailyInner(cookie, _rb) {
  if (!cookie) throw new Error('未配置夸克 Cookie');
  const code = genCode();
  const today = dateStrCN();
  // 2026-08-21 参考「解析密码_YYYYMMDD_HHMM.zip」结构：外层文件夹/zip 带日期时间，内层双层引导
  const mk = makeZip(code, today, '夸克', '2026热门资源合集', { stable: true });
  const folderName = mk.name.replace(/\.zip$/, '');   // 外层文件夹：解析密码_YYYYMMDD_HHMM
  const zip = mk.zip;
  const zipFileName = mk.name;                          // 上传的 zip：解析密码_YYYYMMDD_HHMM.zip
  const { req } = makeRequester(cookie);

  // 1) 创建/复用文件夹「(日期)解析下载密码」
  //    ⚠️ 同名文件夹已存在时直接复用其 fid（夸克不允许同名文件夹重复创建，会报
  //    「file is doloading[同名冲突]」→ 这是自动程序"不生效"的元凶之一）
  const ts = Date.now();
  let folderId = await findFolderId(req, folderName);
  if (!folderId) {
    const folder = await req('POST', `${QUARK_DRIVE}/1/clouddrive/file?pr=ucpro&fr=pc&uc_param_str=&__dt=${Date.now() % 10000}&__t=${ts}`, {
      pdir_fid: '0',
      file_name: folderName,
      dir_path: '',
      dir_init_lock: false,
    });
    folderId = folder.data && folder.data.fid;
    if (!folderId) throw new Error('创建夸克文件夹失败: ' + JSON.stringify(folder).slice(0, 200));
    if (_rb) { _rb.newFolderId = folderId; _rb.req = req; } // 供外层回滚
  }
  // 2) 删除文件夹内旧的 zip（同名残留会导致上传冲突；密码每天变，旧 zip 必须清掉）
  // zipFileName 已由 mk.name 提供
  const oldZipFid = await findFileFid(req, folderId, zipFileName);
  if (oldZipFid) {
    try {
      await req('POST', `${QUARK_DRIVE}/1/clouddrive/file/delete?pr=ucpro&fr=pc&uc_param_str=`, {
        action_type: 2,
        filelist: [oldZipFid],
        exclude_fids: [],
      });
    } catch (e) {
      console.log('[daily-pwd] 删除旧 zip 失败(忽略):', e.message);
    }
  }

  // 3) 预上传（拿 task_id / upload_id / obj_key / bucket / upload_url / auth_info）
  const pre = await req('POST', `${QUARK_DRIVE}/1/clouddrive/file/upload/pre?pr=ucpro&fr=pc&uc_param_str=`, {
    ccp_hash_update: true,
    parallel_upload: true,
    pdir_fid: folderId,
    dir_name: '',
    file_name: zipFileName,
    format_type: 'application/zip',
    l_created_at: ts,
    l_updated_at: ts,
    size: zip.length,
  });
  const preData = pre.data || {};
  const { task_id: taskId, upload_id: uploadId, obj_key: objKey, bucket, upload_url: uploadUrl, auth_info: authInfo, callback: callbackObj } = preData;
  if (!taskId || !objKey) throw new Error('夸克预上传失败: ' + JSON.stringify(pre).slice(0, 200));
  // 上传域 = https://{bucket}.{upload_url 去掉 http://}（如 ul-sz.pds.quark.cn → 阿里云深圳 OSS）
  const ossHost = uploadUrl ? `https://${bucket}.${String(uploadUrl).replace(/^https?:\/\//, '')}` : `https://${bucket}.pds.quark.cn`;
  const partSize = (pre.metadata && pre.metadata.part_size) || 4 * 1024 * 1024;

  // 3.1) 哈希秒传校验（update/hash：云端已有同内容文件则 finish=true 直接完成）
  const md5Hex = crypto.createHash('md5').update(zip).digest('hex');
  const sha1Hex = crypto.createHash('sha1').update(zip).digest('hex');
  const hashResp = await req('POST', `${QUARK_DRIVE}/1/clouddrive/file/update/hash?pr=ucpro&fr=pc&uc_param_str=`, {
    md5: md5Hex,
    sha1: sha1Hex,
    task_id: taskId,
  });
  const hashFinish = hashResp.data && hashResp.data.finish === true;
  let fileId = hashFinish ? (hashResp.data.fid || preData.fid) : '';

  // 3.2) 分片上传（小 zip 单分片）—— auth 拿 OSS 签名 → PUT 到 ossHost
  if (!hashFinish) {
    const gmtDate = new Date().toUTCString();
    // canonical resource 必须带 bucket 前缀 + 头部签名（对齐夸克官方 SDK）
    const canonicalResource = `/${bucket}/${objKey}?partNumber=1&uploadId=${uploadId}`;
    const authMeta = `PUT\n\napplication/zip\n${gmtDate}\nx-oss-date:${gmtDate}\nx-oss-user-agent:aliyun-sdk-js/6.18.0 Chrome/134.0.0.0 on Windows 10 64-bit\n${canonicalResource}`;
    const auth = await req('POST', `${QUARK_DRIVE}/1/clouddrive/file/upload/auth?pr=ucpro&fr=pc&uc_param_str=`, {
      auth_info: authInfo,
      auth_meta: authMeta,
      task_id: taskId,
    });
    const authKey = auth.data && (auth.data.auth_key || auth.data.authorization || auth.data.Authorization || '');
    if (!authKey) throw new Error('夸克 upload/auth 未返回签名: ' + JSON.stringify(auth).slice(0, 200));
    const ossResp = await fetchTimeout(`${ossHost}/${objKey}?partNumber=1&uploadId=${uploadId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/zip',
        'Content-Length': String(zip.length),
        Authorization: authKey,
        Referer: 'https://pan.quark.cn/',
        'x-oss-date': gmtDate,
        'x-oss-user-agent': 'aliyun-sdk-js/6.18.0 Chrome/134.0.0.0 on Windows 10 64-bit',
      },
      body: zip,
    });
    if (!ossResp.ok) {
      const txt = await ossResp.text().catch(() => '');
      throw new Error('夸克 OSS 上传失败 ' + ossResp.status + ': ' + txt.slice(0, 200));
    }
    const etag = (ossResp.headers.get('etag') || '').replace(/"/g, '');

    // 3.3) 提交分片（CompleteMultipartUpload，带 x-oss-callback）
    const gmt2 = new Date().toUTCString();
    const xmlBody = `<?xml version="1.0" encoding="UTF-8"?>\n<CompleteMultipartUpload><Part><PartNumber>1</PartNumber><ETag>${etag}</ETag></Part></CompleteMultipartUpload>`;
    const xmlMd5 = Buffer.from(crypto.createHash('md5').update(xmlBody).digest()).toString('base64');
    const callbackB64 = callbackObj ? Buffer.from(JSON.stringify(callbackObj)).toString('base64') : '';
    const commitCanonical = `/${bucket}/${objKey}?uploadId=${uploadId}`;
    const commitMeta = `POST\n${xmlMd5}\napplication/xml\n${gmt2}\n${callbackB64 ? 'x-oss-callback:' + callbackB64 + '\n' : ''}x-oss-date:${gmt2}\nx-oss-user-agent:aliyun-sdk-js/6.18.0 Chrome/134.0.0.0 on Windows 10 64-bit\n${commitCanonical}`;
    const commitAuth = await req('POST', `${QUARK_DRIVE}/1/clouddrive/file/upload/auth?pr=ucpro&fr=pc&uc_param_str=`, {
      auth_info: authInfo,
      auth_meta: commitMeta,
      task_id: taskId,
    });
    const commitKey = commitAuth.data && (commitAuth.data.auth_key || commitAuth.data.authorization || commitAuth.data.Authorization || '');
    if (!commitKey) throw new Error('夸克 upload/auth(commit) 未返回签名: ' + JSON.stringify(commitAuth).slice(0, 200));
    const commitResp = await fetchTimeout(`${ossHost}/${objKey}?uploadId=${uploadId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/xml',
        'Content-Length': String(Buffer.byteLength(xmlBody)),
        'Content-MD5': xmlMd5,
        Authorization: commitKey,
        Referer: 'https://pan.quark.cn/',
        ...(callbackB64 ? { 'x-oss-callback': callbackB64 } : {}),
        'x-oss-date': gmt2,
        'x-oss-user-agent': 'aliyun-sdk-js/6.18.0 Chrome/134.0.0.0 on Windows 10 64-bit',
      },
      body: xmlBody,
    });
    if (!commitResp.ok) {
      const txt = await commitResp.text().catch(() => '');
      throw new Error('夸克 OSS 提交分片失败 ' + commitResp.status + ': ' + txt.slice(0, 200));
    }
  }

  // 4) 完成上传
  const finish = await req('POST', `${QUARK_DRIVE}/1/clouddrive/file/upload/finish?pr=ucpro&fr=pc&uc_param_str=`, {
    task_id: taskId,
    obj_key: objKey,
  });
  if (!(finish.code === 0 && finish.data && finish.data.finish === true)) {
    throw new Error('夸克完成上传失败: ' + JSON.stringify(finish).slice(0, 200));
  }
  fileId = finish.data.fid || fileId || preData.fid;

  // 5) 创建公开分享（不设提取码）—— 分享【文件夹】而非 zip 本身，
  //    用户点开分享链接先看到「日期，盘达pandel今日分享密码」文件夹 → 点进去才是 zip（嵌套一层文件夹）
  //    返回 task_id，需轮询任务拿 share_id
  const share = await req('POST', `${QUARK_DRIVE}/1/clouddrive/share?pr=ucpro&fr=pc&uc_param_str=`, {
    fid_list: [folderId],
    title: folderName,
    url_type: 1,
    expired_type: 1,
    expire_time: 0,
  });
  const shareTaskId = share.data && (share.data.task_id || share.data.share_id || share.data.shareId);
  if (!shareTaskId) throw new Error('夸克创建分享失败: ' + JSON.stringify(share).slice(0, 200));
  // 轮询任务状态（status=2 成功；最多 10 次，每次 1.5s）
  let shareId = null;
  for (let i = 0; i < 10; i++) {
    const st = await req('GET', `${QUARK_DRIVE}/1/clouddrive/task?pr=ucpro&fr=pc&uc_param_str=&task_id=${shareTaskId}&retry_index=${i}`);
    const stData = st.data || {};
    if (stData.status === 2) {
      shareId = stData.share_id || shareTaskId;
      break;
    }
    if (stData.status === 3) throw new Error('夸克分享任务失败: ' + JSON.stringify(stData).slice(0, 200));
    await new Promise((r) => setTimeout(r, 1500));
  }
  if (!shareId) throw new Error('夸克分享任务超时（10 次轮询未完成）');

  // 6) 拿分享链接
  const link = await req('POST', `${QUARK_DRIVE}/1/clouddrive/share/password?pr=ucpro&fr=pc&uc_param_str=`, {
    share_id: shareId,
  });
  const shareUrl = link.data && (link.data.share_url || link.data.url || '');
  if (!shareUrl) throw new Error('夸克获取分享链接失败: ' + JSON.stringify(link).slice(0, 200));

  const result = { date: today, code, provider: 'quark', folder_id: folderId, file_id: fileId, share_id: shareId, share_url: shareUrl, created_at: Date.now() };
  saveTodayPassword(result);
  // 2026-08-29 增：顺带清理 7 天前的旧密码文件夹（防止再次堆积）
  await cleanupOldPwdFolders(req, QUARK_DRIVE, 'ucpro', today);
  return result;
}



// ============ UC 网盘每日密码生成器 ============
// 2026-08-21：与夸克同构（alist QuarkOrUC 实测）：pc-api.uc.cn + pr=UCBrowser + uc-cloud-drive UA + drive.uc.cn referer
// 分享创建/取消已实测（share/delete 取消；之前 drive.uc.cn 网页域 403 是错误方向，正确域是 pc-api.uc.cn）
const UC_DRIVE_BASE = 'https://pc-api.uc.cn';
const UC_REFERER = 'https://drive.uc.cn';
const UC_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) uc-cloud-drive/2.5.20 Chrome/100.0.4896.160 Electron/18.3.5.4-b478491100 Safari/537.36 Channel/pckk_other_ch';

function makeUcRequester(cookie) {
  let cookieRef = { value: cookie };
  async function req(method, url, data, rawHeaders = {}) {
    const headers = {
      Cookie: cookieRef.value,
      'User-Agent': UC_UA,
      Referer: UC_REFERER + '/',
      Origin: UC_REFERER,
      'Content-Type': 'application/json;charset=UTF-8',
      ...rawHeaders,
    };
    const init = { method, headers };
    if (method === 'POST' && data !== undefined) init.body = typeof data === 'string' ? data : JSON.stringify(data);
    const resp = await fetchTimeout(url, init);
    const setCookies = typeof resp.headers.getSetCookie === 'function' ? resp.headers.getSetCookie() : [];
    for (const sc of setCookies) {
      if (sc && sc.startsWith('__puus')) {
        const v = sc.split(';')[0];
        const m = v.match(/__puus=([^;]+)/);
        if (m) cookieRef.value = cookieRef.value.replace(/__puus=[^;\s]+/, '__puus=' + m[1]);
        break;
      }
    }
    if (resp.status >= 400) {
      const txt = await resp.text().catch(() => '');
      throw new Error('UC HTTP ' + resp.status + ': ' + txt.slice(0, 200));
    }
    const body = await resp.json().catch(() => ({}));
    if (body.code && body.code !== 0) throw new Error('UC code=' + body.code + ': ' + (body.message || ''));
    return body;
  }
  return { req, getCookie: () => cookieRef.value };
}
async function findFolderIdUc(req, name) {
  try {
    const r = await req('GET', `${UC_DRIVE_BASE}/1/clouddrive/file/sort?pr=UCBrowser&fr=pc&uc_param_str=&pdir_fid=0&_page=1&_size=100&_fetch_total=1&_sort=file_type:asc,updated_at:desc`);
    const list = (r.data && r.data.list) || [];
    for (const it of list) {
      if (it.file_type === 0 && it.file_name === name) return it.fid;
    }
  } catch (e) {
    console.log('[daily-pwd] 查找文件夹失败(忽略):', e.message);
  }
  return null;
}
async function findFileFidUc(req, pdirFid, name) {
  try {
    const r = await req('GET', `${UC_DRIVE_BASE}/1/clouddrive/file/sort?pr=UCBrowser&fr=pc&uc_param_str=&pdir_fid=${pdirFid}&_page=1&_size=100&_fetch_total=1&_sort=file_type:asc,updated_at:desc`);
    const list = (r.data && r.data.list) || [];
    for (const it of list) {
      if (it.file_name === name) return it.fid;
    }
  } catch (e) {
    console.log('[daily-pwd] 查找文件失败(忽略):', e.message);
  }
  return null;
}
// 2026-08-29 修（P0）：同 quarkRunDaily，失败回滚本次新建的文件夹
async function ucRunDaily(cookie) {
  const rb = {};
  try {
    return await ucRunDailyInner(cookie, rb);
  } catch (e) {
    if (rb.newFolderId && rb.req) {
      try {
        await rb.req('POST', `${UC_DRIVE_BASE}/1/clouddrive/file/delete?pr=UCBrowser&fr=pc&uc_param_str=`, {
          action_type: 2, filelist: [rb.newFolderId], exclude_fids: [],
        });
        console.log('[daily-pwd] 回滚(UC)：已删除本次新建的残留文件夹', rb.newFolderId);
      } catch (e2) {
        console.log('[daily-pwd] 回滚(UC) 删除失败(忽略):', e2.message);
      }
    }
    throw e;
  }
}
async function ucRunDailyInner(cookie, _rb) {
  if (!cookie) throw new Error('未配置 UC Cookie');
  const code = genCode();
  const today = dateStrCN();
  // 2026-08-21 参考「解析密码_YYYYMMDD_HHMM.zip」结构：外层文件夹/zip 带日期时间，内层双层引导
  const mk = makeZip(code, today, 'UC', '2026热门资源合集', { stable: true });
  const folderName = mk.name.replace(/\.zip$/, '');   // 外层文件夹：解析密码_YYYYMMDD_HHMM
  const zip = mk.zip;
  const zipFileName = mk.name;                          // 上传的 zip：解析密码_YYYYMMDD_HHMM.zip
  const { req } = makeUcRequester(cookie);

  // 1) 创建/复用文件夹「(日期)解析下载密码」
  //    ⚠️ 同名文件夹已存在时直接复用其 fid（UC不允许同名文件夹重复创建，会报
  //    「file is doloading[同名冲突]」→ 这是自动程序"不生效"的元凶之一）
  const ts = Date.now();
  let folderId = await findFolderIdUc(req, folderName);
  if (!folderId) {
    const folder = await req('POST', `${UC_DRIVE_BASE}/1/clouddrive/file?pr=UCBrowser&fr=pc&uc_param_str=&__dt=${Date.now() % 10000}&__t=${ts}`, {
      pdir_fid: '0',
      file_name: folderName,
      dir_path: '',
      dir_init_lock: false,
    });
    folderId = folder.data && folder.data.fid;
    if (!folderId) throw new Error('创建UC文件夹失败: ' + JSON.stringify(folder).slice(0, 200));
    if (_rb) { _rb.newFolderId = folderId; _rb.req = req; } // 供外层回滚
  }
  // 2) 删除文件夹内旧的 zip（同名残留会导致上传冲突；密码每天变，旧 zip 必须清掉）
  // zipFileName 已由 mk.name 提供
  const oldZipFid = await findFileFidUc(req, folderId, zipFileName);
  if (oldZipFid) {
    try {
      await req('POST', `${UC_DRIVE_BASE}/1/clouddrive/file/delete?pr=UCBrowser&fr=pc&uc_param_str=`, {
        action_type: 2,
        filelist: [oldZipFid],
        exclude_fids: [],
      });
    } catch (e) {
      console.log('[daily-pwd] 删除旧 zip 失败(忽略):', e.message);
    }
  }

  // 3) 预上传（拿 task_id / upload_id / obj_key / bucket / upload_url / auth_info）
  const pre = await req('POST', `${UC_DRIVE_BASE}/1/clouddrive/file/upload/pre?pr=UCBrowser&fr=pc&uc_param_str=`, {
    ccp_hash_update: true,
    parallel_upload: true,
    pdir_fid: folderId,
    dir_name: '',
    file_name: zipFileName,
    format_type: 'application/zip',
    l_created_at: ts,
    l_updated_at: ts,
    size: zip.length,
  });
  const preData = pre.data || {};
  const { task_id: taskId, upload_id: uploadId, obj_key: objKey, bucket, upload_url: uploadUrl, auth_info: authInfo, callback: callbackObj } = preData;
  if (!taskId || !objKey) throw new Error('UC预上传失败: ' + JSON.stringify(pre).slice(0, 200));
  // 上传域 = https://{bucket}.{upload_url 去掉 http://}（如 ul-sz.pds.quark.cn → 阿里云深圳 OSS）
  const ossHost = uploadUrl ? `https://${bucket}.${String(uploadUrl).replace(/^https?:\/\//, '')}` : `https://${bucket}.pds.quark.cn`;
  const partSize = (pre.metadata && pre.metadata.part_size) || 4 * 1024 * 1024;

  // 3.1) 哈希秒传校验（update/hash：云端已有同内容文件则 finish=true 直接完成）
  const md5Hex = crypto.createHash('md5').update(zip).digest('hex');
  const sha1Hex = crypto.createHash('sha1').update(zip).digest('hex');
  const hashResp = await req('POST', `${UC_DRIVE_BASE}/1/clouddrive/file/update/hash?pr=UCBrowser&fr=pc&uc_param_str=`, {
    md5: md5Hex,
    sha1: sha1Hex,
    task_id: taskId,
  });
  const hashFinish = hashResp.data && hashResp.data.finish === true;
  let fileId = hashFinish ? (hashResp.data.fid || preData.fid) : '';

  // 3.2) 分片上传（小 zip 单分片）—— auth 拿 OSS 签名 → PUT 到 ossHost
  if (!hashFinish) {
    const gmtDate = new Date().toUTCString();
    // canonical resource 必须带 bucket 前缀 + 头部签名（对齐UC官方 SDK）
    const canonicalResource = `/${bucket}/${objKey}?partNumber=1&uploadId=${uploadId}`;
    const authMeta = `PUT\n\napplication/zip\n${gmtDate}\nx-oss-date:${gmtDate}\nx-oss-user-agent:aliyun-sdk-js/6.18.0 Chrome/134.0.0.0 on Windows 10 64-bit\n${canonicalResource}`;
    const auth = await req('POST', `${UC_DRIVE_BASE}/1/clouddrive/file/upload/auth?pr=UCBrowser&fr=pc&uc_param_str=`, {
      auth_info: authInfo,
      auth_meta: authMeta,
      task_id: taskId,
    });
    const authKey = auth.data && (auth.data.auth_key || auth.data.authorization || auth.data.Authorization || '');
    if (!authKey) throw new Error('UC upload/auth 未返回签名: ' + JSON.stringify(auth).slice(0, 200));
    const ossResp = await fetchTimeout(`${ossHost}/${objKey}?partNumber=1&uploadId=${uploadId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/zip',
        'Content-Length': String(zip.length),
        Authorization: authKey,
        Referer: 'https://drive.uc.cn/',
        'x-oss-date': gmtDate,
        'x-oss-user-agent': 'aliyun-sdk-js/6.18.0 Chrome/134.0.0.0 on Windows 10 64-bit',
      },
      body: zip,
    });
    if (!ossResp.ok) {
      const txt = await ossResp.text().catch(() => '');
      throw new Error('UC OSS 上传失败 ' + ossResp.status + ': ' + txt.slice(0, 200));
    }
    const etag = (ossResp.headers.get('etag') || '').replace(/"/g, '');

    // 3.3) 提交分片（CompleteMultipartUpload，带 x-oss-callback）
    const gmt2 = new Date().toUTCString();
    const xmlBody = `<?xml version="1.0" encoding="UTF-8"?>\n<CompleteMultipartUpload><Part><PartNumber>1</PartNumber><ETag>${etag}</ETag></Part></CompleteMultipartUpload>`;
    const xmlMd5 = Buffer.from(crypto.createHash('md5').update(xmlBody).digest()).toString('base64');
    const callbackB64 = callbackObj ? Buffer.from(JSON.stringify(callbackObj)).toString('base64') : '';
    const commitCanonical = `/${bucket}/${objKey}?uploadId=${uploadId}`;
    const commitMeta = `POST\n${xmlMd5}\napplication/xml\n${gmt2}\n${callbackB64 ? 'x-oss-callback:' + callbackB64 + '\n' : ''}x-oss-date:${gmt2}\nx-oss-user-agent:aliyun-sdk-js/6.18.0 Chrome/134.0.0.0 on Windows 10 64-bit\n${commitCanonical}`;
    const commitAuth = await req('POST', `${UC_DRIVE_BASE}/1/clouddrive/file/upload/auth?pr=UCBrowser&fr=pc&uc_param_str=`, {
      auth_info: authInfo,
      auth_meta: commitMeta,
      task_id: taskId,
    });
    const commitKey = commitAuth.data && (commitAuth.data.auth_key || commitAuth.data.authorization || commitAuth.data.Authorization || '');
    if (!commitKey) throw new Error('UC upload/auth(commit) 未返回签名: ' + JSON.stringify(commitAuth).slice(0, 200));
    const commitResp = await fetchTimeout(`${ossHost}/${objKey}?uploadId=${uploadId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/xml',
        'Content-Length': String(Buffer.byteLength(xmlBody)),
        'Content-MD5': xmlMd5,
        Authorization: commitKey,
        Referer: 'https://drive.uc.cn/',
        ...(callbackB64 ? { 'x-oss-callback': callbackB64 } : {}),
        'x-oss-date': gmt2,
        'x-oss-user-agent': 'aliyun-sdk-js/6.18.0 Chrome/134.0.0.0 on Windows 10 64-bit',
      },
      body: xmlBody,
    });
    if (!commitResp.ok) {
      const txt = await commitResp.text().catch(() => '');
      throw new Error('UC OSS 提交分片失败 ' + commitResp.status + ': ' + txt.slice(0, 200));
    }
  }

  // 4) 完成上传
  const finish = await req('POST', `${UC_DRIVE_BASE}/1/clouddrive/file/upload/finish?pr=UCBrowser&fr=pc&uc_param_str=`, {
    task_id: taskId,
    obj_key: objKey,
  });
  if (!(finish.code === 0 && finish.data && finish.data.finish === true)) {
    throw new Error('UC完成上传失败: ' + JSON.stringify(finish).slice(0, 200));
  }
  fileId = finish.data.fid || fileId || preData.fid;

  // 5) 创建公开分享（不设提取码）—— 分享【文件夹】而非 zip 本身，
  //    用户点开分享链接先看到「日期，盘达pandel今日分享密码」文件夹 → 点进去才是 zip（嵌套一层文件夹）
  //    返回 task_id，需轮询任务拿 share_id
  const share = await req('POST', `${UC_DRIVE_BASE}/1/clouddrive/share?pr=UCBrowser&fr=pc&uc_param_str=`, {
    fid_list: [folderId],
    title: folderName,
    url_type: 1,
    expired_type: 1,
    expire_time: 0,
  });
  const shareTaskId = share.data && (share.data.task_id || share.data.share_id || share.data.shareId);
  if (!shareTaskId) throw new Error('UC创建分享失败: ' + JSON.stringify(share).slice(0, 200));
  // 轮询任务状态（status=2 成功；最多 10 次，每次 1.5s）
  let shareId = null;
  for (let i = 0; i < 10; i++) {
    const st = await req('GET', `${UC_DRIVE_BASE}/1/clouddrive/task?pr=UCBrowser&fr=pc&uc_param_str=&task_id=${shareTaskId}&retry_index=${i}`);
    const stData = st.data || {};
    if (stData.status === 2) {
      shareId = stData.share_id || shareTaskId;
      break;
    }
    if (stData.status === 3) throw new Error('UC分享任务失败: ' + JSON.stringify(stData).slice(0, 200));
    await new Promise((r) => setTimeout(r, 1500));
  }
  if (!shareId) throw new Error('UC分享任务超时（10 次轮询未完成）');

  // 6) 拿分享链接
  const link = await req('POST', `${UC_DRIVE_BASE}/1/clouddrive/share/password?pr=UCBrowser&fr=pc&uc_param_str=`, {
    share_id: shareId,
  });
  const shareUrl = link.data && (link.data.share_url || link.data.url || '');
  if (!shareUrl) throw new Error('UC获取分享链接失败: ' + JSON.stringify(link).slice(0, 200));

  const result = { date: today, code, provider: 'uc', folder_id: folderId, file_id: fileId, share_id: shareId, share_url: shareUrl, created_at: Date.now() };
  saveTodayPassword(result);
  // 2026-08-29 增：同夸克，清理 7 天前的旧密码文件夹
  await cleanupOldPwdFolders(req, UC_DRIVE_BASE, 'UCBrowser', today);
  return result;
}
// =====================================================================
//  移动云盘（139）自动生成器 —— 参考 KongHen02/cloud_driver_sdk (Yun139)
//  凭证 = yun.139.com 登录后的 Basic Token（Authorization 头，形如 Basic <base64>）
//  ⚠️ 与解析用的网页 Cookie 不同：自动生成需「Basic Token」，后台 Cookie 框填 Token 本体（可带 Basic 前缀）
// =====================================================================
const MCLOUD_DRIVE = 'https://personal-kd-njs.yun.139.com';
const MCLOUD_SHARE = 'https://yun.139.com/orchestration/personalCloud-rebuild/outlink/v1.0/getOutLink';
const MCLOUD_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36';

function mcloudSign(body, ts, randStr) {
  // 与 SDK 一致：body URL 编码 → 字符排序 → base64 → md5，与 ts:rand 的 md5 拼接再 md5 大写
  let b = encodeURIComponent(body);
  b = b.split('').sort().join('');
  b = Buffer.from(b, 'utf8').toString('base64');
  const bodyMd5 = crypto.createHash('md5').update(b, 'utf8').digest('hex');
  const tsRandMd5 = crypto.createHash('md5').update(`${ts}:${randStr}`, 'utf8').digest('hex');
  return crypto.createHash('md5').update(bodyMd5 + tsRandMd5, 'utf8').digest('hex').toUpperCase();
}
function mcloudHeaders(token) {
  const ts = new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 19).replace('T', ' ');
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let randStr = '';
  for (let i = 0; i < 16; i++) randStr += alphabet[Math.floor(Math.random() * alphabet.length)];
  return {
    'User-Agent': MCLOUD_UA,
    Accept: 'application/json, text/plain, */*',
    Authorization: token.startsWith('Basic ') ? token : 'Basic ' + token,
    Caller: 'web',
    'Cms-Device': 'default',
    'Mcloud-Channel': '1000101',
    'Mcloud-Client': '10701',
    'Mcloud-Route': '001',
    'Mcloud-Sign': `${ts},${randStr},`,
    'Mcloud-Version': '7.14.0',
    'x-DeviceInfo': '||9|7.14.0|chrome|120.0.0.0|||windows 10||zh-CN|||',
    'x-huawei-channelSrc': '10000034',
    'x-inner-ntwk': '2',
    'x-m4c-caller': 'PC',
    'x-m4c-src': '10002',
    'x-SvcType': '1',
    'X-Yun-Api-Version': 'v1',
    'X-Yun-App-Channel': '10000034',
    'X-Yun-Channel-Source': '10000034',
    'X-Yun-Client-Info': '||9|7.14.0|chrome|120.0.0.0|||windows 10||zh-CN|||dW5kZWZpbmVk||',
    'X-Yun-Module-Type': '100',
    'X-Yun-Svc-Type': '1',
    Origin: 'https://yun.139.com',
    Referer: 'https://yun.139.com/',
  };
}
// 移动云盘签名是「先算好 Sign 再发请求」，故 req 内临时替换 Mcloud-Sign 占位
async function mcloudReq(token, url, method, data) {
  const headers = mcloudHeaders(token);
  const body = data === undefined ? '' : JSON.stringify(data);
  // 用占位签名即可（SDK 实际也是拿 body 算；若校验严格再补全）
  headers['Mcloud-Sign'] = headers['Mcloud-Sign'] + mcloudSign(body, headers['Mcloud-Sign'].split(',')[0], headers['Mcloud-Sign'].split(',')[1]);
  const init = { method, headers };
  if (method === 'POST' && data !== undefined) { headers['Content-Type'] = 'application/json;charset=UTF-8'; init.body = body; }
  const resp = await fetchTimeout(url, init);
  const j = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error(`移动云盘 HTTP ${resp.status}: ${JSON.stringify(j).slice(0, 200)}`);
  if (j.success !== true && j.code !== 0) throw new Error(`移动云盘 ${j.code || j.error_code || ''}: ${j.message || JSON.stringify(j).slice(0, 150)}`);
  return j.data || j;
}

// 从移动云盘 Cookie 中提取 Authorization 凭证（2026-08-19 重写根因：
// 后台存的是网页登录 Cookie，含 authorization/auth_token 字段，不是裸 Basic token）
function mcloudTokenFromCookie(cookie) {
  const c = String(cookie || '');
  const m = c.match(/authorization=([^;]+)/i);
  if (m) return decodeURIComponent(m[1].trim());
  const m2 = c.match(/auth_token=([^;]+)/i);
  if (m2) return decodeURIComponent(m2[1].trim());
  const m3 = c.match(/token=([^;]+)/i);
  if (m3) return decodeURIComponent(m3[1].trim());
  // 兼容直接传 Basic base64 的旧用法
  if (/^Basic\s/i.test(c.trim()) || /^[A-Za-z0-9+/=]{24,}$/.test(c.trim())) return c.trim();
  return '';
}

// 2026-08-29 修（P0）：同 quarkRunDaily，失败回滚本次新建的文件夹
async function mcloudRunDaily(cookie) {
  const rb = {};
  try {
    return await mcloudRunDailyInner(cookie, rb);
  } catch (e) {
    if (rb.newFolderId && rb.token) {
      try {
        await mcloudReq(rb.token, `${MCLOUD_DRIVE}/hcy/recyclebin/batchTrash`, 'POST', {
          fileIdList: [rb.newFolderId],
        });
        console.log('[daily-pwd] 回滚(移动)：已删除本次新建的残留文件夹', rb.newFolderId);
      } catch (e2) {
        console.log('[daily-pwd] 回滚(移动) 删除失败(忽略):', e2.message);
      }
    }
    throw e;
  }
}
async function mcloudRunDailyInner(cookie, _rb) {
  // 2026-08-19：cookie 是网页登录态，需先提取 authorization 凭证
  const token = mcloudTokenFromCookie(cookie);
  if (!token) throw new Error('未配置移动云盘 Token（cookie 中缺少 authorization 字段）');
  const code = genCode();
  const today = dateStrCN();
  // 2026-08-21 参考结构：解析密码_YYYYMMDD_HHMM.zip（内层双层引导）
  const mk = makeZip(code, today, '移动云盘', '2026热门资源合集', { stable: true });
  const folderName = mk.name.replace(/\.zip$/, '');
  const zip = mk.zip;
  const zipFileName = mk.name;
  // zipFileName 已由 mk.name 提供

  // 1) 建外层文件夹（复用同名）
  let folderId = null;
  const listData = await mcloudReq(token, `${MCLOUD_DRIVE}/hcy/file/list`, 'POST', {
    pageInfo: { pageSize: 200, pageCursor: null },
    orderBy: 'name', orderDirection: 'ASC', parentFileId: '/',
  });
  const existing = (listData.fileList || listData.files || []);
  for (const it of existing) if (it.name === folderName && it.type === 'folder') { folderId = it.id || it.fileId; break; }
  if (!folderId) {
    const c = await mcloudReq(token, `${MCLOUD_DRIVE}/hcy/file/create`, 'POST', {
      parentFileId: '/', name: folderName, description: '', type: 'folder', fileRenameMode: 'force_rename',
    });
    folderId = c.id || c.fileId || (c.file && c.file.id) || (c.file && c.file.fileId);
    if (!folderId) throw new Error('创建移动云盘文件夹失败: ' + JSON.stringify(c).slice(0, 200));
    if (_rb) { _rb.newFolderId = folderId; _rb.token = token; } // 供外层回滚
  }

  // 2) 删除文件夹内旧 zip（同名残留会冲突）——必须在 folderId 目录内重新列一次
  try {
    const inFolder = await mcloudReq(token, `${MCLOUD_DRIVE}/hcy/file/list`, 'POST', {
      pageInfo: { pageSize: 200, pageCursor: null },
      orderBy: 'name', orderDirection: 'ASC', parentFileId: folderId,
    });
    for (const it of (inFolder.fileList || inFolder.files || [])) {
      if (it.name === zipFileName && it.type === 'file') {
        try { await mcloudReq(token, `${MCLOUD_DRIVE}/hcy/recyclebin/batchTrash`, 'POST', { fileIdList: [it.id || it.fileId] }); } catch {}
        break;
      }
    }
  } catch {}

  // 3) 建上传任务（SHA256 + partInfos；小文件单分片）
  const size = zip.length;
  const sha256 = crypto.createHash('sha256').update(zip).digest('hex');
  const create = await mcloudReq(token, `${MCLOUD_DRIVE}/hcy/file/create`, 'POST', {
    parentFileId: folderId, name: zipFileName, type: 'file', size,
    fileRenameMode: 'auto_rename', contentHash: sha256, contentHashAlgorithm: 'SHA256',
    contentType: 'application/zip', parallelUpload: false,
    partInfos: [{ parallelHashCtx: { partOffset: 0 }, partNumber: 1, partSize: size }],
  });
  if (create.rapidUpload === true) { /* 秒传 */ }
  else {
    const fileId = create.id || create.fileId || (create.file && create.file.id);
    const uploadId = create.uploadId || (create.data && create.data.uploadId);
    const part = (create.partInfos && create.partInfos[0]) || (create.data && create.data.partInfos && create.data.partInfos[0]);
    if (!part || !part.uploadUrl) throw new Error('移动云盘上传任务缺少分片地址: ' + JSON.stringify(create).slice(0, 200));
    // 4) PUT 分片
    const putResp = await fetchTimeout(part.uploadUrl, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/oct-stream', Origin: 'https://yun.139.com', Referer: 'https://yun.139.com/' },
      body: zip,
    });
    if (!putResp.ok) throw new Error(`移动云盘分片上传失败 ${putResp.status}: ${(await putResp.text()).slice(0, 200)}`);
    // 5) 完成
    await mcloudReq(token, `${MCLOUD_DRIVE}/hcy/file/complete`, 'POST', {
      fileId, uploadId, contentHash: sha256, contentHashAlgorithm: 'SHA256',
    });
  }
  const zipFileId = create.id || create.fileId || (create.file && create.file.id);

  // 6) 创建分享（分享外层文件夹；无提取码）
  const tokenB64 = (token.startsWith('Basic ') ? token.slice(6) : token).trim();
  const splits = Buffer.from(tokenB64, 'base64').toString('utf8').split(':');
  const share = await mcloudReq(token, MCLOUD_SHARE, 'POST', {
    getOutLinkReq: {
      subLinkType: 0, encrypt: 0, coIDLst: [], caIDLst: [folderId], pubType: 1,
      dedicatedName: folderName, periodUnit: 1, viewerLst: [],
      extInfo: { isWatermark: 0, shareChannel: '3001' },
      commonAccountInfo: { account: splits[1] || '', accountType: 1 },
    },
  });
  const resSet = share.getOutLinkRes && share.getOutLinkRes.getOutLinkResSet;
  const shareUrl = share.shareUrl || share.outLink || share.url
    || (share.getOutLinkResp && share.getOutLinkResp.shareUrl)
    // 2026-08-20 修：移动云盘实际返回 getOutLinkRes.getOutLinkResSet[0].linkUrl（之前漏解析 → 误判创建失败）
    || (resSet && resSet[0] && (resSet[0].linkUrl || resSet[0].shareUrl || resSet[0].url)) || '';
  if (!shareUrl) throw new Error('移动云盘创建分享失败: ' + JSON.stringify(share).slice(0, 250));

  const result = { date: today, code, provider: 'mcloud', folder_id: folderId, file_id: zipFileId, share_url: shareUrl, created_at: Date.now() };
  saveTodayPassword(result);
  return result;
}

// =====================================================================
//  迅雷云盘自动生成器 —— Google Drive 风格 API（api-pan.xunlei.com）
//  凭证 = 网页登录 Cookie（含 device_id）+ X-Device-Id；分享/上传需 Authorization（由 Cookie 会话支撑）
// =====================================================================
const XUNLEI_API = 'https://api-pan.xunlei.com';
const XUNLEI_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36';

// 2026-08-20 修：迅雷 captcha token 自举（52pojie 逆向硬编码 sign 纯 API，同 xunlei_download.py）
const XUNLEI_CAPTCHA_SIGN = '1.fe2108ad808a74c9ac0243309242726c';
async function xunleiCaptchaInit(deviceId) {
  const body = {
    client_id: 'Xqp0kJBXWhwaTpB6', action: 'get:/drive/v1/share', device_id: deviceId,
    meta: { username: '', phone_number: '', email: '', package_name: 'pan.xunlei.com', client_version: '1.45.0', captcha_sign: XUNLEI_CAPTCHA_SIGN, timestamp: '1645241033384', user_id: '0' },
  };
  const resp = await fetchTimeout('https://xluser-ssl.xunlei.com/v1/shield/captcha/init', {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'User-Agent': XUNLEI_UA }, body: JSON.stringify(body),
  });
  const j = await resp.json().catch(() => ({}));
  return j.captcha_token || '';
}
// 2026-08-20 修：迅雷 access token 自举——读浏览器捕获的 JWT 缓存（xunlei_page.py 解析时刷新）
function loadXunleiJwt() {
  try {
    const p = '/home/ubuntu/pwand-playwright/xunlei_jwt_cache.json';
    return (JSON.parse(require('fs').readFileSync(p, 'utf8')) || {}).jwt || '';
  } catch { return ''; }
}
// 2026-08-20 修：captcha_sign 硬编码已被迅雷轮换失效（400 invalid captcha_sign，服务器无法伪造 WASM）。
//   优先读 xunlei_page.py 真实浏览器捕获的 captcha token 缓存（xunlei_token.json，TTL 6h）——WASM 生成的才有效。
function loadXunleiToken() {
  try {
    const d = JSON.parse(require('fs').readFileSync('/home/ubuntu/pwand-playwright/xunlei_token.json', 'utf8'));
    if (d.token && Date.now() / 1000 - (d.ts || 0) < 6 * 3600) return d.token;
    return '';
  } catch { return ''; }
}
function xunleiHeaders(cookie, captchaToken, accessToken) {
  // 2026-08-19 修：迅雷 device_id 格式为 wdi10.<hex>（含 w/d/i/点号），[a-f0-9-] 匹配不到 → 改 [^;]+ 到分号为止
  let deviceId = (String(cookie).match(/device[_]?id=([^;]+)/i) || [])[1] || '';
  // 2026-08-19 修：浏览器实际发 X-Device-Id 不带 wdi10. 前缀（token 设备绑定校验），
  //   cookie 值形如 wdi10.<hex> → 剥掉前缀，否则 POST 报 captcha_invalid
  deviceId = deviceId.replace(/^wdi10\./i, '');
  return {
    'User-Agent': XUNLEI_UA,
    Origin: 'https://pan.xunlei.com',
    Referer: 'https://pan.xunlei.com/',
    'Content-Type': 'application/json',
    Accept: 'application/json, text/plain, */*',
    ...(cookie ? { Cookie: cookie } : {}),
    ...(deviceId ? { 'X-Device-Id': deviceId } : {}),
    // 2026-08-19 接上：迅雷 API 强制要求 x-captcha-token（52pojie 逆向，ck0. 开头，有效期 6-24h）
    ...(captchaToken ? { 'x-captcha-token': captchaToken } : {}),
    // 2026-08-19 修：迅雷 API 校验 x-client-id（web 端固定值，与 captcha token 绑定）
    'x-client-id': 'Xqp0kJBXWhwaTpB6',
    // 2026-08-19 修：迅雷 API 要求 Authorization: Bearer <access_token>（invalid auth header）
    ...(accessToken ? { 'Authorization': 'Bearer ' + accessToken } : {}),
  };
}
async function xunleiReq(cookie, url, method, data, captchaToken, accessToken) {
  const headers = xunleiHeaders(cookie, captchaToken, accessToken);
  const init = { method, headers };
  if (data !== undefined) init.body = JSON.stringify(data);
  const resp = await fetchTimeout(url, init);
  const j = await resp.json().catch(() => ({}));
  if (!resp.ok || (j.error_code && j.error_code !== 0)) {
    const msg = (j.error_details || []).map((e) => e.detail || '').filter(Boolean).join('；') || j.message || `HTTP ${resp.status}`;
    throw new Error(`迅雷 ${msg}`);
  }
  return j.data || j;
}

async function xunleiRunDaily(cookie, captchaToken, accessToken) {
  // 2026-08-21 停用：迅雷每日密码需登录态浏览器验证码（服务器不可行），用户已放弃。
  // 2026-08-21 清理（全局审计 P2）：删除 throw 后的 ~80 行死代码——
  //   其中还有两个真 bug（makeZip(code, today) 缺 providerName/resourceName 参数、
  //   zipFileName 未定义），留着会误导后续维护。历史实现见 git log (1d42a49 之前)。
  throw new Error('迅雷每日密码已停用（上传需登录态浏览器验证码，服务器不可行）');
}

module.exports = { ucRunDaily, quarkRunDaily, mcloudRunDaily, xunleiRunDaily, loadDailyPasswords, loadTodayPassword, saveTodayPassword, genCode, makeZip, dateStrCN };
