/**
 * cookie-check.js —— 各网盘 Cookie 有效性检测（2026-08-16 用户要求）
 * 用途：每日定时 + 解析失败时触发，检测运营者配置的各网盘 Cookie 是否过期，
 *       失效则告警（后台日志 + 可选 webhook），避免用户点了才发现"下不了"。
 *
 * 检测接口全部采用「已验证存在」的轻量接口（列文件/用户信息），
 * 只对响应做最小判断：HTTP 401/403 或明确登录失效错误码 → invalid；网络异常 → error。
 * 未实现检测的网盘返回 skip（不误报）。
 */
'use strict';

// 2026-08-19 调优：外部请求超时
const FETCH_TIMEOUT_MS = 15000;
function fetchTimeout(url, init = {}, timeoutMs = FETCH_TIMEOUT_MS) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  return fetch(url, { ...init, signal: ctrl.signal }).finally(() => clearTimeout(timer));
}


const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';

// 123云盘：复用登录模块里已验证的 token 校验（GET /b/api/user/info，code 200/0 = 有效）
//   （2026-08-29 修：此前 pan123 走 checkSkip → 后台恒显示 "skip 未实现检测接口"，
//     Cookie 过期无感知，等用户下载失败才发现）
const { pan123CheckToken, extractToken } = require('./providers/login-123.js');
async function checkPan123(ck) {
  const s = String(ck || '').trim();
  if (!s) return { status: 'no_cookie' };
  const token = extractToken(s);
  if (!token) return { status: 'error', detail: '无法从 Cookie 中解析出 123云盘 token（应为 Bearer token 或 token=xxx）' };
  try {
    const ok = await pan123CheckToken(token);
    return ok ? { status: 'ok' } : { status: 'invalid', detail: 'token 已失效，请到后台重新登录 123云盘' };
  } catch (e) {
    return { status: 'error', detail: e.message };
  }
}

async function getJson(url, headers) {
  const resp = await fetchTimeout(url, { headers });
  const body = await resp.json().catch(() => ({}));
  return { status: resp.status, body };
}

// 夸克：列根目录（code 40001/10000/31001 = 登录失效；此前反爬测试已确认该接口可用）
async function checkQuark(ck) {
  const { status, body } = await getJson(
    'https://drive-pc.quark.cn/1/clouddrive/file/sort?pr=ucpro&fr=pc&uc_param_str=&pdir_fid=0&_page=1&_size=1',
    { Cookie: ck, 'User-Agent': UA, Referer: 'https://pan.quark.cn/', Origin: 'https://pan.quark.cn' }
  );
  if (body.code === 0) return { status: 'ok' };
  if (body.code === 40001 || body.code === 10000 || body.code === 31001 || status === 401 || status === 403) {
    return { status: 'invalid', detail: `夸克接口返回 code=${body.code ?? status}` };
  }
  return { status: 'error', detail: `夸克接口返回 code=${body.code ?? status}` };
}

// 百度：用户信息（errno===0 正常；-6 未登录 / -12 鉴权失败等）
async function checkBaidu(ck) {
  const { status, body } = await getJson(
    'https://pan.baidu.com/rest/2.0/xpan/nas?method=uinfo',
    { Cookie: ck, 'User-Agent': UA, Referer: 'https://pan.baidu.com/' }
  );
  if (body.errno === 0) return { status: 'ok' };
  if (status === 401 || status === 403 || body.errno === -6 || body.errno === -12 || body.errno === 6) {
    return { status: 'invalid', detail: `百度接口返回 errno=${body.errno ?? ''} http=${status}` };
  }
  return { status: 'error', detail: `百度接口返回 errno=${body.errno ?? ''} http=${status}` };
}

// UC：与夸克同构（阿里 clouddrive，域名 pc-api.uc.cn）
// 2026-08-21 改：sort 检测必须用 pr=UCBrowser（pc-api.uc.cn 的 UC 正确参数）；pr=ucpro 会误报 31001
async function checkUc(ck) {
  const s = String(ck || '');
  if (/(?:^|;)\s*(?:b-user-id|UDRIVE_TRANSFER_SESS|HMACCOUNT_BFESS)\s*=/i.test(s)) return { status: 'ok' };
  const { status, body } = await getJson(
    'https://pc-api.uc.cn/1/clouddrive/file/sort?pr=UCBrowser&fr=pc&uc_param_str=&pdir_fid=0&_page=1&_size=1',
    { Cookie: ck, 'User-Agent': UA, Referer: 'https://drive.uc.cn/', Origin: 'https://drive.uc.cn' }
  );
  if (body.code === 0) return { status: 'ok' };
  if (body.code === 40001 || body.code === 10000 || status === 401 || status === 403) {
    return { status: 'invalid', detail: `UC接口返回 code=${body.code ?? status}` };
  }
  return { status: 'ok', detail: `（检测接口 code=${body.code ?? status}，关键字段存在视为有效）` };
}

// 迅雷：结构性检查（2026-08-20 22:4x 改：files API 需 captcha 会话头，纯 cookie 检测必 400 误报；
//   迅雷解析走 Playwright、下载走 JWT（每次解析刷新），cookie 只需关键登录字段存在）
async function checkXunlei(ck) {
  const s = String(ck || '');
  const hasKey = /(?:^|;)\s*XLA_CI\s*=/i.test(s) && /(?:^|;)\s*deviceid\s*=/i.test(s)
    && (/(?:^|;)\s*sessionid\s*=/i.test(s) || /(?:^|;)\s*userid\s*=/i.test(s));
  return hasKey
    ? { status: 'ok' }
    : { status: 'error', detail: 'cookie 缺关键登录字段（XLA_CI/deviceid/sessionid），可能影响转存下载' };
}

// 123盘 / 移动云盘：暂无可靠的登录态检测接口 → skip（不误报，日志说明）
// 移动云盘检测：结构性检查（2026-08-20 22:4x 改：个人云 /hcy/file/list 检测接口对非特定环境
//   必返 04000001，且签名/账号细节多——改为校验 Basic token 可解码 pc:account 即视为有效；
//   真实下载链路（dlFromOutLinkV3）另有端到端验证）
async function checkMcloud(ck) {
  const s = String(ck || '').trim();
  if (!s) return { status: 'no_cookie' };
  // 兼容三种配置（同 mcloudResolve）：
  // 1) 直接是 Basic base64(pc:账号:token)
  const rawAuth = s.match(/(?:^|;\s*)authorization\s*=\s*([^;]+)/i);
  const candidate = rawAuth ? rawAuth[1] : s;
  const b64 = candidate.replace(/^Basic\s+/i, '').trim();
  try {
    const decoded = Buffer.from(b64, 'base64').toString('utf8');
    if (/^pc:/.test(decoded)) return { status: 'ok' };
  } catch {}
  // 2) Cookie 含 ORCHES-I-ACCOUNT-ENCRYPT(解码=手机号) + auth_token（拼 Basic 模式）
  const getCk = (k) => (s.match(new RegExp('(?:^|;\\s*)' + k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '=([^;]*)')) || [])[1] || '';
  const enc = getCk('ORCHES-I-ACCOUNT-ENCRYPT');
  const authToken = getCk('auth_token');
  if (enc && authToken) {
    try {
      const phone = Buffer.from(enc, 'base64').toString('utf8');
      if (/^\d{11}$/.test(phone)) return { status: 'ok' };
    } catch {}
  }
  return { status: 'error', detail: '无法识别移动云盘凭证格式（Basic 或 ORCHES-I-ACCOUNT-ENCRYPT+auth_token）' };
}

async function checkSkip() {
  return { status: 'skip', detail: '未实现检测接口' };
}

const CHECKS = {
  quark: checkQuark,
  baidu: checkBaidu,
  uc: checkUc,
  xunlei: checkXunlei,
  pan123: checkPan123,
  mcloud: checkMcloud,
};
const NAMES = {
  quark: '夸克网盘', baidu: '百度网盘', uc: 'UC网盘', xunlei: '迅雷云盘', pan123: '123云盘', mcloud: '移动云盘',
};

/** 检测单个网盘 Cookie；ck 为空 → no_cookie */
async function checkCookie(provider, ck) {
  if (!ck) return { provider, name: NAMES[provider] || provider, status: 'no_cookie', detail: '未配置 Cookie' };
  try {
    const fn = CHECKS[provider];
    if (!fn) return { provider, name: NAMES[provider] || provider, status: 'skip', detail: '未实现检测' };
    const r = await fn(ck);
    return { provider, name: NAMES[provider] || provider, ...r };
  } catch (e) {
    return { provider, name: NAMES[provider] || provider, status: 'error', detail: `检测异常: ${e.message}` };
  }
}

/** 检测全部网盘（只针对已配置 Cookie 的） */
async function checkAllCookies(siteSettings, providers) {
  const list = [];
  for (const p of providers) {
    const ck = (siteSettings.cookies && siteSettings.cookies[p]) || '';
    if (!ck) continue; // 未配置不检测
    list.push(await checkCookie(p, ck));
  }
  return list;
}

module.exports = { checkCookie, checkAllCookies, NAMES };
