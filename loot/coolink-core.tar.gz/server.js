/**
 * coolink 后端 —— 零依赖 Node 服务（Node 原生 http + fetch）
 * 核心机制：搜索 / 解析密码墙 / 四道限额墙 / 每日任务换额度
 * 并加入「真实网盘直链解析」：用【你自己的】网盘 Cookie 调官方接口拿直链
 *   - 夸克：分享token → 列文件 → 转存到自己网盘 → file/download 直链（__puus 自动续期）
 *   - 百度：wxlist → tplconfig(sign) → sharedownload dlink（BDUSS Cookie）
 * 参考实现（均开源、声明仅用自己账号，合法）：
 *   github.com/muyan556/gopeed-extension-quark
 *   github.com/code-hasaki/gopeed-extension-baiduwp
 *
 * 运行：node server.js   （默认 http://localhost:3000）
 */
'use strict';

const http = require('http');
const zlib = require('zlib');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
// 夸克自动程序：每天生成「今日密码」并上传分享（用户 2026-08-15 构想）
const { ucRunDaily, quarkRunDaily, mcloudRunDaily, xunleiRunDaily, loadDailyPasswords, loadTodayPassword, saveTodayPassword, genCode, dateStrCN } = require('./quark-auto.js');
// Cookie 有效性检测（2026-08-16 用户要求：每日定时 + 解析失败时触发，失效告警）
const { checkAllCookies, checkCookie } = require('./cookie-check.js');
const { URL } = require('url');
const { toSVG: qrToSVG } = require('./tools/qrcode');
// 2026-08-19 渐进拆分 Step 1：纯工具函数（零状态依赖）→ lib/utils.js
const {
  quarkSenderCookie, ucSenderCookie,
  dayStr, todayStr, parseCookies,
  flattenForShare, collectFileNodes, buildDisplayTree,
  parseBaiduUrl, buildBaiduCookie,
} = require('./lib/utils.js');
// 2026-08-19 渐进拆分 Step 2：网盘 HTTP 请求封装 + API 常量 → lib/http.js
const {
  QUARK_API, QUARK_DRIVE, BAIDU_API, UC_API, UC_DRIVE,
  refreshPuus, quarkRequest, baiduRequest, parseQuarkUrl,
  fetchTimeout,
} = require('./lib/http.js');
// 2026-08-19 渐进拆分 Step 3：各网盘「列目录」实现 → providers/list-trees.js
const { quarkListTree, baiduListTree, ucListTree } = require('./providers/list-trees.js');
// 2026-08-19 渐进拆分 Step 4：百度/123/迅雷/移动 解析 → providers/resolve-other.js
const { baiduResolve, pan123Resolve, xunleiResolve, mcloudResolve, runXunleiPage, getXunleiPwd, xunleiTransfer, baiduListPage, baiduPageDownload, baiduTransfer, pan123Sign } = require('./providers/resolve-other.js');
// 2026-08-19：123盘 账号密码登录（过期凭证改登录，自动刷新 token）→ providers/login-123.js
const { pan123SignIn, pan123CheckToken, pan123RefreshToken, extractToken } = require('./providers/login-123.js');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const PARSE_PASSWORD = '1234'; // demo 用的"压缩包四位密码"

const MB = 1024 * 1024;
const GB = 1024 * MB;
// 双轨额度契约（用户 2026-08-15 确认）：
//   <= SMALL_FILE_MAX（200MB）= 小体积文件 → 按「字节总量」限额（每日 2GB，任务追加）
//   >  SMALL_FILE_MAX 且 <= LARGE_FILE_SIZE_CAP（2GB）= 大文件 → 按「个数」限额（每日 20 个）
//   >  LARGE_FILE_SIZE_CAP（2GB）= 超大文件 → 需做任务解锁「大文件权限」，解锁后个数与 2GB 以内大文件相通（同一个 count 池）
const SMALL_FILE_MAX = 200 * MB;
const LARGE_FILE_SIZE_CAP = 2 * GB;
// 「使用教程」导航指向的腾讯文档（2026-08-16 用户指定；教电脑小白用 gopeed；
// v5（2026-08-16 用户纠错）：配图修正——请求头截图移到第 4 节百度网盘位置；
// v8（2026-08-17 用户要求字号大几号+行距多一点）：frontmatter 加 fontSize: large + spacing: loose
// （smartcanvas API 无法原地改样式，只能重建；内容与 v7 完全一致）
const TUTORIAL_URL = 'https://docs.qq.com/aio/DZWVxcFR1cXBObk5p';

// ---------- 内存存储 ----------
const devices = new Map();      // device_id -> 当日配额
// 设备配额/任务状态持久化（用户 2026-08-15 要求：做完任务奖励已下发，重启后仍显示已完成，不重复做）
// 存 data/devices.json；防抖 2 秒写盘；启动时加载；跨天条目自动丢弃（getQuota 按 date 重建）
const DEVICES_FILE = path.join(__dirname, '..', 'data', 'devices.json');
let _devicesSaveTimer = null;
function loadDevices() {
  try {
    if (fs.existsSync(DEVICES_FILE)) {
      const obj = JSON.parse(fs.readFileSync(DEVICES_FILE, 'utf8'));
      for (const [k, v] of Object.entries(obj || {})) if (k && v) devices.set(k, v);
    }
  } catch {}
}
function saveDevices() {
  clearTimeout(_devicesSaveTimer);
  _devicesSaveTimer = setTimeout(() => {
    try {
      const obj = {};
      for (const [k, v] of devices) obj[k] = v;
      fs.mkdirSync(path.dirname(DEVICES_FILE), { recursive: true });
      fs.writeFileSync(DEVICES_FILE, JSON.stringify(obj));
    } catch {}
  }, 2000);
}
loadDevices();

// ---------- 埋点 & 运营日志 & 站点设置 ----------
const actionLogs = [];   // {ts, deviceId, action, kw, provider, success, detail}
const adminLogs = [];    // {ts, action, detail}
const downloadLogs = []; // {ts, deviceId, file_name, file_size, provider, download_link} 我的下载记录

// ---------- 日志持久化（用户 2026-08-16 要求：存服务器磁盘，每小时换新文件防全部损坏，便于纠错）----------
// data/logs/logs-YYYYMMDD-HH.json 每小时一个文件；内存数组照旧（实时读取），定时整批写盘
const LOGS_DIR = path.join(__dirname, '..', 'data', 'logs');
function logHourKey() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}`;
}
function persistLogsNow() {
  try {
    fs.mkdirSync(LOGS_DIR, { recursive: true });
    const file = path.join(LOGS_DIR, `logs-${logHourKey()}.json`);
    fs.writeFileSync(file, JSON.stringify({
      hour: logHourKey(),
      savedAt: Date.now(),
      admin: adminLogs,
      actions: actionLogs,
      downloads: downloadLogs,
    }));
  } catch (e) { console.log('[logs] 写盘失败:', e.message); }
}
// 每分钟写盘一次（每小时文件 key 变化 → 自动换新文件；旧文件保留不会互相覆盖）
setInterval(persistLogsNow, 60 * 1000);
// 读取某小时的日志（后台纠错用）：GET /api/admin/logs?hour=YYYYMMDD-HH，缺省读当前小时
function readLogHour(hour) {
  try {
    const file = path.join(LOGS_DIR, `logs-${hour || logHourKey()}.json`);
    if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {}
  return null;
}
// 后台安全：密码从环境变量读（未设置则用默认值并警告）；登录失败限流；token 绑定 IP
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';
if (!process.env.ADMIN_PASSWORD) console.log('⚠️ 未设置 ADMIN_PASSWORD 环境变量，正在使用默认密码（生产环境务必修改）');
// 后台隐蔽路径：不在任何前端页面暴露，仅管理员知道（可通过环境变量覆盖）
const ADMIN_PATH = (process.env.ADMIN_PATH || '/panel-x7k9f2').replace(/\/+$/, '');
let adminSession = null; // { token, ip, expiresAt }
const loginFails = new Map(); // ip -> { count, lockedUntil }
const MAX_LOGIN_FAILS = 5;
const LOGIN_LOCK_MS = 15 * 60 * 1000; // 15 分钟

function isAdmin(req) {
  if (!adminSession) return false;
  if (Date.now() > adminSession.expiresAt) { adminSession = null; return false; }
  const cookies = parseCookies(req.headers.cookie || '');
  if (cookies.admin_token !== adminSession.token) return false;
  // token 绑定登录时 IP，换 IP 失效
  const ip = req.socket.remoteAddress || '';
  return adminSession.ip === ip;
}

function checkLoginLocked(ip) {
  const f = loginFails.get(ip);
  if (f && f.lockedUntil && Date.now() < f.lockedUntil) {
    return Math.ceil((f.lockedUntil - Date.now()) / 1000);
  }
  return 0;
}
function recordLoginFail(ip) {
  const f = loginFails.get(ip) || { count: 0, lockedUntil: 0 };
  f.count++;
  if (f.count >= MAX_LOGIN_FAILS) { f.lockedUntil = Date.now() + LOGIN_LOCK_MS; f.count = 0; }
  loginFails.set(ip, f);
  if (loginFails.size > 1000) { for (const k of loginFails.keys()) if (k !== ip) loginFails.delete(k); }
}
function clearLoginFails(ip) { loginFails.delete(ip); }

// ---------- 反爬：敏感 API 的 IP 频率限制（用户 2026-08-16 按 反爬报告加固）----------
// 限流桶：ip -> { windowStart, count }；窗口 60s，超过阈值返回 429
const rateBuckets = new Map();
const RATE_WINDOW_MS = 60 * 1000;
const RATE_LIMITS = {
  '/api/quark/downloader-cookie': 10,   // 下载器 cookie：防批量白嫖（原 10 连发全 200 → 现超 10 次/分钟 429）
  '/api/parse': 60,
  '/api/search/reveal-links': 60,
  '/api/daily-tasks/complete': 30,
  '/api/daily-tasks/claim': 30,
  '/api/feedback': 5,                    // 反馈提交：防刷屏（5 条/分钟/IP）
  // 2026-08-19 安全加固：fetch（发送到下载器）会转存到运营者网盘（占空间），必须限流防滥用
  '/api/quark/fetch': 20, '/api/baidu/fetch': 20, '/api/uc/fetch': 20,
  '/api/pan123/fetch': 20, '/api/mcloud/fetch': 20, '/api/xunlei/restore-files': 20,
};
function rateLimit(req, pathname) {
  // fetch 系列（拿直链+完整 Cookie 的接口）：限流防批量抓取（20 次/分钟/IP）
  let max = RATE_LIMITS[pathname];
  if (!max && (pathname.endsWith('/fetch') || pathname === '/api/xunlei/restore-files')) max = 20;
  if (!max) return true; // 未配置限流的端点放行
  const ip = req.socket.remoteAddress || '';
  const now = Date.now();
  // 每个接口独立计数桶（修复：原实现所有接口共用一个 ip 桶，一个接口被刷会拖累其他接口）
  const key = ip + '|' + pathname;
  let b = rateBuckets.get(key);
  if (!b || now - b.windowStart > RATE_WINDOW_MS) {
    b = { windowStart: now, count: 0 };
    rateBuckets.set(key, b);
  }
  b.count++;
  if (b.count > max) {
    rateBuckets.set(key, { windowStart: now, count: max + 1 }); // 重置窗口，避免一直锁死
    return false;
  }
  return true;
}
// 定期清理限流桶，防内存增长
setInterval(() => {
  const now = Date.now();
  for (const [k, b] of rateBuckets) if (now - b.windowStart > RATE_WINDOW_MS) rateBuckets.delete(k);
}, 5 * 60 * 1000);

// ---- 用户反馈持久化：data/feedbacks.json（上限 200 条，新的在前）----
const FEEDBACK_FILE = path.join(__dirname, '..', 'data', 'feedbacks.json');
function loadFeedbacks() {
  try {
    if (fs.existsSync(FEEDBACK_FILE)) {
      const d = JSON.parse(fs.readFileSync(FEEDBACK_FILE, 'utf8'));
      if (Array.isArray(d)) return d;
    }
  } catch {}
  return [];
}
function saveFeedbacks(list) {
  try {
    fs.mkdirSync(path.dirname(FEEDBACK_FILE), { recursive: true });
    fs.writeFileSync(FEEDBACK_FILE, JSON.stringify(list.slice(0, 200), null, 2));
  } catch (e) {
    console.log('[feedback] 写入失败:', e.message);
  }
}

// 夸克「发送器 Cookie」子集：下载器推送只需 __sdid/Video-Auth/__kuus/__uus（前端 mu 白名单），
// 绝不回传 b-user-id / xlly_s / __puus / __uss 等账号会话字段（防第三方用完整 cookie 冒用运营者夸克账号）

// 2026-08-19 安全加固：UC 发送器 cookie 脱敏（与夸克同构，白名单字段一致；绝不泄露登录会话字段）

// ===== 网盘元数据（单一事实来源：前端显示 / 后台配置 / 解析能力 统一从这里取）=====
const PROVIDERS = ['quark', 'baidu', 'xunlei', 'pan123', 'mcloud', 'uc'];
const PROVIDER_NAME = {
  quark: '夸克网盘', baidu: '百度网盘', xunlei: '迅雷网盘',
  pan123: '123盘', mcloud: '移动云盘', uc: 'UC网盘',
};
// 已真实接入解析的网盘（其余前端可见，但标注「即将支持」）
const SUPPORTED_PROVIDERS = ['quark', 'baidu', 'uc', 'pan123', 'xunlei', 'mcloud'];

// 站点配置持久化（用户 2026-08-15 反馈：Cookie 一刷新就没 → 根因 siteSettings 只在内存、从不写盘）
// 存 data/settings.json：启动加载、保存时写盘；Cookie 不回显明文但持久化在服务器
// ⚠️ 2026-08-16 加固：Cookie 明文存盘有泄露风险（服务器文件被读即全泄露）→ 改为
//    AES-256-GCM 加密写盘，密钥由 ADMIN_PASSWORD 经 scrypt 派生（启动解密、修改加密写盘）
const SETTINGS_FILE = path.join(__dirname, '..', 'data', 'settings.json');
function settingsKey() {
  const pwd = process.env.ADMIN_PASSWORD || '';
  // 固定 salt（保证重启可解密）；未设置 ADMIN_PASSWORD 时用默认口令并打警告（生产必须设）
  const salt = Buffer.from('pandel-settings-v1', 'utf8');
  return crypto.scryptSync(pwd || 'pandel-default-key', salt, 32, { N: 16384, r: 8, p: 1 });
}
function encryptSettings(obj) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', settingsKey(), iv);
  const pt = Buffer.from(JSON.stringify(obj), 'utf8');
  const ct = Buffer.concat([cipher.update(pt), cipher.final()]);
  const tag = cipher.getAuthTag();
  return JSON.stringify({ enc: true, v: 1, data: Buffer.concat([iv, tag, ct]).toString('base64') }, null, 2);
}
function decryptSettings(raw) {
  const saved = JSON.parse(raw);
  if (saved && saved.enc === true && typeof saved.data === 'string') {
    const buf = Buffer.from(saved.data, 'base64');
    if (buf.length < 28) throw new Error('settings 密文长度异常');
    const decipher = crypto.createDecipheriv('aes-256-gcm', settingsKey(), buf.subarray(0, 12));
    decipher.setAuthTag(buf.subarray(12, 28));
    return JSON.parse(Buffer.concat([decipher.update(buf.subarray(28)), decipher.final()]).toString('utf8'));
  }
  return saved; // 旧明文格式（enc 标记缺失）
}
function loadSettings() {
  try {
    if (fs.existsSync(SETTINGS_FILE)) {
      const raw = fs.readFileSync(SETTINGS_FILE, 'utf8');
      const saved = decryptSettings(raw);
      // 明文迁移：旧版本是明文 JSON（无 enc 标记）→ 备份明文 + 立即加密写盘
      if (!(saved && saved.enc === true)) {
        try { fs.copyFileSync(SETTINGS_FILE, SETTINGS_FILE + '.plain.bak'); } catch {}
      }
      // 深合并到默认值（保留默认结构，覆盖已保存字段）
      if (saved.parsePassword) siteSettings.parsePassword = saved.parsePassword;
      if (typeof saved.smallDailyLimitMB === 'number') siteSettings.smallDailyLimitMB = saved.smallDailyLimitMB;
      if (typeof saved.smallRewardMB === 'number') siteSettings.smallRewardMB = saved.smallRewardMB;
      if (typeof saved.largeDailyLimit === 'number') siteSettings.largeDailyLimit = saved.largeDailyLimit;
      if (typeof saved.sizeCapGB === 'number') siteSettings.sizeCapGB = saved.sizeCapGB;
      for (const p of PROVIDERS) {
        if (saved.cookies && typeof saved.cookies[p] === 'string') siteSettings.cookies[p] = saved.cookies[p];
        if (saved.promo && saved.promo[p]) siteSettings.promo[p] = { ...siteSettings.promo[p], ...saved.promo[p] };
      }
      // 2026-08-19 修：loadSettings 漏恢复 xunleiCaptchaToken/xunleiDeviceId →
      //   server 重启后内存默认空值覆盖磁盘，token 必丢（后台填了也没用）
      if (typeof saved.xunleiCaptchaToken === 'string') siteSettings.xunleiCaptchaToken = saved.xunleiCaptchaToken;
      if (typeof saved.xunleiDeviceId === 'string') siteSettings.xunleiDeviceId = saved.xunleiDeviceId;
      if (typeof saved.xunleiAccessToken === 'string') siteSettings.xunleiAccessToken = saved.xunleiAccessToken;
      // 2026-08-19 修：pan123Account 同样漏恢复（重启后账号丢失，token 续期失效）
      if (saved.pan123Account && typeof saved.pan123Account.username === 'string') {
        siteSettings.pan123Account = {
          ...siteSettings.pan123Account,
          username: saved.pan123Account.username,
          password: typeof saved.pan123Account.password === 'string' ? saved.pan123Account.password : '',
        };
      }
      // 迁移后立即加密落盘
      if (!(saved && saved.enc === true)) saveSettings();
    }
  } catch (e) {
    console.log('[settings] 解密/读取失败:', e.message, '（保留磁盘文件，本次使用内存默认值）');
    pushAdminLog('settings_err', 'settings.json 解密失败: ' + e.message);
  }
}
function saveSettings() {
  try {
    fs.mkdirSync(path.dirname(SETTINGS_FILE), { recursive: true });
    fs.writeFileSync(SETTINGS_FILE, encryptSettings(siteSettings));
  } catch (e) {
    console.log('[settings] 加密写盘失败:', e.message);
  }
}
const siteSettings = {
  parsePassword: PARSE_PASSWORD, // 可被后台改
  // 参考站 双轨额度（用户确认）：
  //   小体积文件（<=200MB）：按字节总量限额，默认每日 2GB
  //   大文件（>200MB）：按个数限额，默认每日 20 个
  //   >2GB 超大文件：需任务解锁权限，解锁后个数与大文件相通
  smallDailyLimitMB: 2048,   // 小体积文件每日字节额度（MB）
  smallRewardMB: 500,        // 每次任务奖励追加的小文件流量（MB）
  largeDailyLimit: 20,       // 大文件每日个数限额
  sizeCapGB: 2,              // 单文件大小权限线（>2GB 需任务解锁；解锁后不再限制大小）
  // 运营者自己的网盘会员账号 Cookie（6 网盘统一，仅在管理员后台配置，绝不回显给用户）
  cookies: { quark: '', baidu: '', xunlei: '', pan123: '', mcloud: '', uc: '' },
  // 2026-08-19：123盘 账号密码登录（过期凭证改登录；sign_in 自动拿 token 存 cookies.pan123）
  pan123Account: { username: '', password: '' },
  // 2026-08-19：迅雷无感验证码 token（52pojie 逆向：ck0.xxx，有效期 6-24h，浏览器抓一次填这里）
  xunleiCaptchaToken: '',
  xunleiDeviceId: '', // 迅雷 token 绑定 device_id（抓 token 时浏览器用的，必须一起存）
  xunleiAccessToken: '', // 2026-08-19：迅雷 Bearer access_token（API 要求 Authorization 头）
  // 各网盘「推广口令 / 二维码 / 推广链接」配置（变现核心，6 网盘统一）
  // passcode = 网盘口令（复制去 App 粘贴）；link = 带追踪的推广分享链接；qrUrl = 二维码图（可选，缺省用 link 生成）
  // auto_daily = 是否启动「每日自动化程序」：勾选后每天 00:00 自动生成该网盘今日密码并分享（用户 2026-08-15 确认）
  promo: {
    quark:  { passcode: '复制口令到夸克网盘获取解析密码', link: '', qrUrl: '', auto_daily: false },
    baidu:  { passcode: '复制口令到百度网盘获取解析密码', link: '', qrUrl: '', auto_daily: false },
    xunlei: { passcode: '复制口令到迅雷网盘获取解析密码', link: '', qrUrl: '', auto_daily: false },
    pan123: { passcode: '复制口令到123盘获取解析密码', link: '', qrUrl: '', auto_daily: false },
    mcloud: { passcode: '复制口令到移动云盘获取解析密码', link: '', qrUrl: '', auto_daily: false },
    uc:     { passcode: '复制口令到UC网盘获取解析密码', link: '', qrUrl: '', auto_daily: false },
  },
};
// 启动时从 data/settings.json 加载已保存配置（Cookie/推广等），服务重启不丢
loadSettings();
function pushAction(deviceId, action, extra = {}) {
  actionLogs.push({ ts: Date.now(), deviceId, action, ...extra });
  if (actionLogs.length > 2000) actionLogs.splice(0, actionLogs.length - 2000);
}

// 2026-08-19：每日访问日志（按天聚合，每天一个 JSON 文件）
// 用途：管理后台总览「每 15 天访问用户柱状图」+「总访问次数+已访问人数」
// 设计：异步写不阻塞请求主流程；保留 30 天自动清理
// 2026-08-19 用户要求：访问次数(每次+1) 与 访问用户(设备指纹去重) 分开统计；
//   同一台电脑刷新 N 次 = 1 个用户 + N 次访问（此前按 cookie device_id 每刷新算 1 用户，错误）
const ACCESS_LOG_DIR = path.join(__dirname, '..', 'data', 'access');
const ACCESS_LOG_TTL_DAYS = 30;
const accessLogInMemory = new Map(); // day -> {devices: Set, total: number, pending: boolean}


function ensureAccessDir() {
  try { fs.mkdirSync(ACCESS_LOG_DIR, { recursive: true }); } catch {}
}

function recordAccess(fingerprint) {
  try {
    if (!fingerprint) fingerprint = 'fp:anon';
    const day = dayStr();
    let bucket = accessLogInMemory.get(day);
    if (!bucket) {
      // 从文件加载（如果存在）
      const file = path.join(ACCESS_LOG_DIR, day + '.json');
      let devices = new Set(), total = 0;
      if (fs.existsSync(file)) {
        try {
          const o = JSON.parse(fs.readFileSync(file, 'utf8'));
          devices = new Set(o.devices || []);
          total = o.total || 0;
        } catch {}
      }
      bucket = { devices, total, pending: false };
      accessLogInMemory.set(day, bucket);
    }
    if (!bucket.devices.has(fingerprint)) {
      bucket.devices.add(fingerprint);
    }
    bucket.total += 1;
    if (!bucket.pending) {
      bucket.pending = true;
      // 异步写盘（不阻塞当前请求）
      setImmediate(() => flushAccessBucket(day));
    }
  } catch {}
}

function flushAccessBucket(day) {
  const bucket = accessLogInMemory.get(day);
  if (!bucket) return;
  try {
    ensureAccessDir();
    const file = path.join(ACCESS_LOG_DIR, day + '.json');
    fs.writeFileSync(file, JSON.stringify({
      date: day,
      devices: Array.from(bucket.devices),
      total: bucket.total,
    }));
  } catch {}
  bucket.pending = false;
}

function sweepAccessLogs() {
  // 每天清理一次过期文件（启动时 + 每 24h）
  try {
    ensureAccessDir();
    const now = Date.now();
    const cutoff = now - ACCESS_LOG_TTL_DAYS * 86400 * 1000;
    for (const f of fs.readdirSync(ACCESS_LOG_DIR)) {
      if (!f.endsWith('.json')) continue;
      const d = f.replace('.json', '');
      const t = new Date(d + 'T00:00:00Z').getTime();
      if (!isNaN(t) && t < cutoff) {
        fs.unlinkSync(path.join(ACCESS_LOG_DIR, f));
      }
    }
  } catch {}
  // 内存中过期 bucket 也清掉
  for (const k of Array.from(accessLogInMemory.keys())) {
    const t = new Date(k + 'T00:00:00Z').getTime();
    if (!isNaN(t) && t < Date.now() - ACCESS_LOG_TTL_DAYS * 86400 * 1000) {
      accessLogInMemory.delete(k);
    }
  }
}
sweepAccessLogs();
setInterval(sweepAccessLogs, 24 * 3600 * 1000);

// 读 N 天的 access 聚合（按 day 排序返回）
function getAccessSeries(days) {
  const result = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(Date.now() - i * 86400 * 1000);
    const day = dayStr(d);
    let devices = 0, total = 0;
    // 优先内存
    const mem = accessLogInMemory.get(day);
    if (mem) {
      devices = mem.devices.size;
      total = mem.total;
    } else {
      try {
        const file = path.join(ACCESS_LOG_DIR, day + '.json');
        if (fs.existsSync(file)) {
          const o = JSON.parse(fs.readFileSync(file, 'utf8'));
          devices = (o.devices || []).length;
          total = o.total || 0;
        }
      } catch {}
    }
    result.push({ date: day, devices, total });
  }
  return result;
}

// 近 N 天去重用户数（扫所有天文件/内存的指纹集合做并集，跨天不重复计数）
function countUniqueUsers(days) {
  const all = new Set();
  for (let i = days - 1; i >= 0; i--) {
    const day = dayStr(new Date(Date.now() - i * 86400 * 1000));
    const mem = accessLogInMemory.get(day);
    if (mem) {
      for (const f of mem.devices) all.add(f);
      continue;
    }
    try {
      const file = path.join(ACCESS_LOG_DIR, day + '.json');
      if (fs.existsSync(file)) {
        const o = JSON.parse(fs.readFileSync(file, 'utf8'));
        for (const f of (o.devices || [])) all.add(f);
      }
    } catch {}
  }
  return all.size;
}

// 读 N 天的 parse/fetch 聚合（从 actionLogs 汇总，3 条线：成功/下载/失败）
function getParseSeries(days) {
  const buckets = {};
  for (let i = days - 1; i >= 0; i--) {
    const d = dayStr(new Date(Date.now() - i * 86400 * 1000));
    buckets[d] = { ok: 0, download: 0, fail: 0 };
  }
  for (const a of actionLogs) {
    const d = dayStr(new Date(a.ts));
    if (!buckets[d]) continue;
    if (a.action === 'parse' && a.success) buckets[d].ok += 1;
    else if (a.action === 'fetch' && a.success) buckets[d].download += 1;
    else if ((a.action === 'parse' || a.action === 'fetch') && !a.success) buckets[d].fail += 1;
  }
  return Object.keys(buckets).sort().map((d) => ({ date: d, ...buckets[d] }));
}
function pushAdminLog(action, detail) {
  adminLogs.push({ ts: Date.now(), action, detail });
  if (adminLogs.length > 500) adminLogs.splice(0, adminLogs.length - 500);
}

// 记录用户「今日解析」日志（/api/my-downloads 数据源）
// 去重：同一 deviceId+provider+shareId+file_name 仅保留最新一条
function recordDownloadLog(deviceId, provider, shareId, file, extra = {}) {
  for (let i = downloadLogs.length - 1; i >= 0; i--) {
    const d = downloadLogs[i];
    if (d.deviceId === deviceId && d.provider === provider && d.shareId === shareId && d.file_name === (file.name || file.file_name)) {
      downloadLogs.splice(i, 1);
    }
  }
  downloadLogs.push({
    ts: Date.now(),
    deviceId,
    provider,
    shareId: shareId || '',
    providerName: PROVIDER_NAME[provider] || provider,
    file_name: file.name || file.file_name || '',
    file_size: Number(file.size || file.file_size) || 0,
    download_link: file.url || file.download_link || '',
    ...extra,
  });
  if (downloadLogs.length > 2000) downloadLogs.splice(0, downloadLogs.length - 2000);
}

// 格式化日期：08-15/10:20:51（「今日解析和额度」表格期望格式）
function fmtParseTime(ts) {
  const d = new Date(ts);
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  const ss = String(d.getSeconds()).padStart(2, '0');
  return `${m}-${day}/${hh}:${mm}:${ss}`;
}


function getQuota(deviceId) {
  let q = devices.get(deviceId);
  const t = todayStr();
  if (!q || q.date !== t) {
    q = {
      date: t,
      unlocked: false,
      // 双轨额度：大文件按个数（20/日），小体积文件按字节总量（2GB/日）
      largeCountLeft: siteSettings.largeDailyLimit,
      smallFileUnlocked: false,          // 小文件解析/下载需先做任务解锁
      smallSizeLeft: siteSettings.smallDailyLimitMB * MB, // 小文件每日字节额度
      sizeCapUnlocked: false,            // >2GB 超大文件权限（任务解锁）
      claimedTasks: {},
      completedTasks: {},
      taskProviders: {}, // task_id -> 用户实际完成该任务所用的网盘（用于「追加任务用不同网盘」校验）
      downloaderUnlocked: {}, // provider -> 该网盘「发送到下载器」是否已解锁（任务奖励）
    };
    devices.set(deviceId, q);
    saveDevices();
  }
  return q;
}

// ---------- 设备识别（cookie）----------

function attachDevice(req, res) {
  const cookies = parseCookies(req.headers.cookie || '');
  let did = cookies.device_id;
  let needSet = false;
  if (!did) {
    did = crypto.randomBytes(8).toString('hex');
    needSet = true;
  }
  req.deviceId = did;
  req._needSetCookie = needSet;
  res._needSetCookie = needSet;
  res._deviceId = did;
  // 2026-08-19：设备指纹（统计「访问用户」去重用）
  // 同一台电脑刷新 N 次：device_id cookie 相同 → 指纹相同 → 算 1 个用户
  // 兜底：cookie 被清/变化时用 IP+UA 粗指纹（尽力识别同一设备）
  req.fingerprint = deviceFingerprint(req, did);
}

// 设备指纹：优先 device_id cookie；cookie 缺失时退化为 IP+UA 粗指纹
function deviceFingerprint(req, did) {
  if (did && /^[a-f0-9]{8,}$/i.test(did)) return 'ck:' + did;
  const ip = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
  const ua = String(req.headers['user-agent'] || '').slice(0, 200);
  try {
    return 'fp:' + crypto.createHash('sha1').update(ip + '|' + ua).digest('hex').slice(0, 16);
  } catch {
    return 'fp:anon';
  }
}

// ---- 访客来源日志（内测版整体改善：记录页面访问来源，后台「访客来源」统计）----
const visitorLogs = []; // {ts, host, path, uaType, deviceId}
const VISITOR_LOG_MAX = 2000;
function recordVisitor(req, pathname) {
  try {
    const ref = String(req.headers.referer || req.headers.referrer || '');
    let host = '';
    if (ref) {
      try { host = new URL(ref).hostname; } catch {}
    }
    if (host === 'coolink.cc.cd' || host === '127.0.0.1' || host === 'localhost') host = ''; // 站内跳转不记来源
    const ua = String(req.headers['user-agent'] || '');
    const uaType = /mobile|android|iphone|ipad/i.test(ua) ? 'mobile' : 'pc';
    visitorLogs.unshift({ ts: Date.now(), host, path: pathname, uaType, deviceId: req.deviceId || '' });
    if (visitorLogs.length > VISITOR_LOG_MAX) visitorLogs.length = VISITOR_LOG_MAX;
  } catch {}
}

// CORS 白名单：仅允许本站域名跨域读取（反爬：收紧 ACAO，杜绝任意站点读取 API 响应）
// 同源请求（无 Origin 或 Origin=本站）正常；跨域且不在白名单 → 不返回 ACAO（浏览器拦截）
const CORS_ALLOWED = (process.env.CORS_ORIGINS || 'https://coolink.cc.cd,http://coolink.cc.cd')
  .split(',').map((s) => s.trim()).filter(Boolean);
function corsOrigin(req) {
  const origin = req.headers.origin || '';
  if (!origin) return null; // 同源/无浏览器（curl）→ 不需要 ACAO
  try {
    const u = new URL(origin);
    const host = u.hostname;
    // 允许本机回环（本地调试）与配置白名单
    if (host === '127.0.0.1' || host === 'localhost') return origin;
    if (CORS_ALLOWED.some((o) => o.toLowerCase() === origin.toLowerCase())) return origin;
  } catch {}
  return false; // 非法来源：明确不给 ACAO
}
function sendJson(res, code, obj) {
  let body = JSON.stringify(obj);
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Headers': 'Content-Type, X-Requested-With',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'X-Content-Type-Options': 'nosniff',
  };
  // 2026-08-19 性能优化：允许 CDN（Cloudflare）边缘缓存 share/detail 列表响应
  // （后端已有 5 分钟内存缓存；加 CDN-Cache-Control 后 Cloudflare 配置缓存规则即可
  //   边缘直接返回，用户点文件夹网络延迟也砍半。直链类接口不设此头，必须实时）
  if (res._cacheable) {
    headers['Cache-Control'] = 'public, max-age=300';
    headers['CDN-Cache-Control'] = 'public, max-age=300';
  }
  // res._req 由主服务器统一注入（见 http.createServer）
  const co = corsOrigin(res._req || { headers: {} });
  if (co) headers['Access-Control-Allow-Origin'] = co;
  if (res._needSetCookie) {
    headers['Set-Cookie'] = `device_id=${res._deviceId}; Path=/; Max-Age=2592000; SameSite=Lax`;
  }
  res.writeHead(code, headers);
  res.end(body);
}

function readBody(req, maxBytes = 5 * MB) {
  return new Promise((resolve, reject) => {
    let data = '';
    let overflow = false;
    req.on('data', (c) => {
      data += c;
      if (data.length > maxBytes) { overflow = true; data = data.slice(0, maxBytes); }
    });
    req.on('end', () => {
      if (overflow) return reject(new Error('请求体过大'));
      try { resolve(data ? JSON.parse(data) : {}); } catch { resolve({}); }
    });
    req.on('error', () => reject(new Error('请求读取失败')));
  });
}

// ===== 兼容辅助函数 =====

// 前端 share/detail 通用处理：返回 data + result 两套结构覆盖所有前端消费路径
async function pandlShareHandle(req, res, provider, body, mode = 'share') {
  const url = body.url || body.share_url || body.shareUrl || body.share_url || '';
  // 2026-08-19 性能优化：share/detail 列表响应允许 CDN 缓存（配合后端内存缓存消除进入文件夹卡顿）
  res._cacheable = true;
  try {
    // detail（点击进入文件夹）时前端传凭证模式 {pwd_id, stoken, pdir_fid}，无 url
    // → 用凭证直接列**指定子层**（2026-08-19 修复：此前只认 body.url，前端不传 url 就报"夸克接口失败"；
    //   且此前整树递归拍平，文件夹无法逐层进入）
    if (mode === 'detail' && provider === 'quark' && (body.pwd_id || body.share_id) && (body.pdir_fid || body.parent_id)) {
      const cookieRef = { value: siteSettings.cookies[provider] || '' };
      let stoken = String(body.stoken || '').trim();
      const pwdId = String(body.pwd_id || body.share_id || '').trim();
      const pdirFid = String(body.pdir_fid || body.parent_id || '').trim();
      // 2026-08-19 性能优化：点文件夹列表缓存 5 分钟（消除重复进入卡顿）
      const cached = resolveCacheGet(provider, pwdId, 'layer:' + pdirFid);
      let tree, fileNodes;
      if (cached) {
        tree = cached.tree; fileNodes = cached.files;
      } else {
        // stoken 缺失时重新换取（分享页公开接口，无需 Cookie）
        if (!stoken) {
          const tokenRes = await quarkRequest('POST',
            `${QUARK_API}/1/clouddrive/share/sharepage/token?pr=ucpro&fr=pc&__dt=${Date.now()}`,
            { pwd_id: pwdId, passcode: body.passcode || body.pass_code || '' }, cookieRef);
          stoken = (tokenRes.data && tokenRes.data.stoken) || '';
          if (!stoken) throw new Error('获取夸克分享凭证失败');
        }
        tree = await quarkListTree(cookieRef, pwdId, stoken, pdirFid, false);
        fileNodes = collectFileNodes(tree);
        resolveCacheSet(provider, pwdId, 'layer:' + pdirFid, { tree, files: fileNodes, stoken });
      }
      // 2026-08-19 性能优化：预取本层所有子文件夹的列表进缓存（后台并行，不阻塞响应）
      // 用户点进子文件夹时缓存已命中 → 秒开，消除「进入文件夹卡顿」
      prefetchQuarkLayers(cookieRef, pwdId, stoken, tree);
      const fileList = flattenForShare(tree, fileNodes.map((f) => ({ name: f.name, size: f.size, fid_token: f.fid_token })));
      return sendJson(res, 200, {
        ok: true,
        result: { files: fileList, list: fileList, dir: pdirFid, randsk: '', from_own_netdisk: false, provider },
        data: {
          list: fileList, detail_info: { list: fileList },
          token_info: { stoken: stoken || (cached && cached.stoken) || '' },
          pass_code_token: '', passcode_token: '',
          pass_code: body.pass_code || '', pwd_id: pwdId, share_id: pwdId, provider,
        },
        files: fileList,
      });
    }
    // detail（点击进入文件夹）时前端传凭证模式 {pwd_id, stoken, pdir_fid}，无 url
    // → 用凭证直接列**指定子层**（2026-08-19 修复：此前只认 body.url，前端不传 url 就报"夸克接口失败"；
    //   且此前整树递归拍平，文件夹无法逐层进入）
    if (mode === 'detail' && provider === 'uc' && (body.share_id || body.pwd_id) && (body.pdir_fid || body.parent_id)) {
      const cookieRef = { value: siteSettings.cookies[provider] || '' };
      let stoken = String(body.stoken || '').trim();
      const shareId = String(body.share_id || body.pwd_id || '').trim();
      const pdirFid = String(body.pdir_fid || body.parent_id || '').trim();
      const ucRequest = async (method, path, payload) => {
        const headers = {
          'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120 Safari/537.36',
          'Referer': 'https://drive.uc.cn/', 'Origin': 'https://drive.uc.cn', 'Content-Type': 'application/json',
        };
        if (cookieRef.value) headers.Cookie = cookieRef.value;
        const fullUrl = /^https?:\/\//i.test(path) ? path : `${UC_API}${path}`;
        const resp = await fetchTimeout(fullUrl, { method, headers, body: payload ? JSON.stringify(payload) : undefined });
        const data = await resp.json().catch(() => ({}));
        if (data.code === 41006) throw new Error('分享链接不存在或已失效');
        if (data.code === 31001) throw new Error('此分享需要提取码，请在链接末尾加 ?pwd=密码');
        if (data.code === 31002) throw new Error('分享链接已失效或被取消');
        return data;
      };
      // 2026-08-19 性能优化：点文件夹列表缓存 5 分钟（消除重复进入卡顿）
      const cached = resolveCacheGet(provider, shareId, 'layer:' + pdirFid);
      let tree, fileNodes;
      if (cached) {
        tree = cached.tree; fileNodes = cached.files;
      } else {
        if (!stoken) {
          const tokenRes = await ucRequest('POST',
            `/1/clouddrive/share/sharepage/token?entry=ft&fr=pc&pr=UCBrowser&__dt=${Date.now()}`,
            { pwd_id: shareId, passcode: body.passcode || body.pass_code || '' });
          stoken = (tokenRes.data && tokenRes.data.stoken) || '';
          if (!stoken) throw new Error('获取 UC 分享凭证失败');
        }
        tree = await ucListTree(ucRequest, shareId, stoken, pdirFid, false);
        fileNodes = collectFileNodes(tree);
        resolveCacheSet(provider, shareId, 'layer:' + pdirFid, { tree, files: fileNodes, stoken });
      }
      // 2026-08-19 性能优化：预取本层子文件夹列表进缓存（后台并行，不阻塞响应）
      prefetchUcLayers(ucRequest, shareId, stoken, tree);
      const fileList = flattenForShare(tree, fileNodes.map((f) => ({ name: f.name, size: f.size, fid_token: f.fid_token })));
      // 2026-08-19 修（UC 前端契约）：UC 前端 detail 分支读 result.uc.data.* → 补 uc
      const ucData = {
        list: fileList, detail_info: { list: fileList },
        token_info: { stoken: stoken || (cached && cached.stoken) || '' },
        pass_code_token: '', passcode_token: '',
        pass_code: body.pass_code || '', pwd_id: shareId, share_id: shareId, provider,
      };
      return sendJson(res, 200, {
        ok: true,
        result: { files: fileList, list: fileList, dir: pdirFid, randsk: '', from_own_netdisk: false, provider, uc: { data: ucData } },
        data: ucData,
        files: fileList,
      });
    }
    // detail（点击进入文件夹）凭证分支：pan123 前端传 {share_url, parent_file_id} 无 url 的完整链接依赖
    if (mode === 'detail' && provider === 'pan123' && body.parent_file_id) {
      // 前端已持有 share_url，直接用凭证列指定层
      const { key: pKey, pwd: pPwd, shareHost: pHost } = (() => {
        const rawUrl = String(body.share_url || body.url || '');
        let key = (rawUrl.match(/\/s\/([A-Za-z0-9_-]+)/) || [])[1] || '';
        if (!key) {
          const m = rawUrl.match(/(?:123pan|123pan\.cn)\/[A-Za-z0-9]+\/([A-Za-z0-9_-]+)/);
          key = m ? m[1] : '';
        }
        // 2026-08-19 修：前端把 pwd 拆出单独传，URL 无 ?pwd= → 用 body.pass_code 兜底（同 Baidu 处理）
        const pwd = (rawUrl.match(/[?&#]pwd=([a-zA-Z0-9]+)/i) || [])[1] || body.pass_code || body.passcode || '';
        let host = 'https://www.123pan.com';
        try { host = new URL(rawUrl).origin; } catch {}
        return { key, pwd, shareHost: host };
      })();
      if (!pKey) throw new Error('无法识别123网盘分享链接');
      const parentFileId = String(body.parent_file_id || '').trim();
      const headers = {
        'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
        'Referer': pHost + '/', 'Origin': pHost, 'Accept': 'application/json, text/plain, */*',
      };
      const ck = siteSettings.cookies[provider] || '';
      if (ck) headers.Cookie = ck;
      const apiBase = 'https://api.123pan.cn';
      // 2026-08-19 性能优化：点文件夹列表缓存 5 分钟（消除重复进入卡顿）
      const cached = resolveCacheGet(provider, pKey, 'layer:' + parentFileId);
      let tree, fileNodes;
      if (cached) {
        tree = cached.tree; fileNodes = cached.files;
      } else {
        const qs = `shareKey=${encodeURIComponent(pKey)}&sharePwd=${encodeURIComponent(pPwd)}` +
          `&ParentFileId=${parentFileId || 0}&Page=1&limit=100&orderBy=fileId&orderDirection=asc&next=0`;
        const r = await fetchTimeout(`${apiBase}/api/share/get?${qs}`, { headers });
        const j = await r.json().catch(() => ({}));
        if (j.code !== 0) throw new Error(j.message || '获取123网盘分享信息失败');
        const items = (j.data && j.data.InfoList) || [];
        tree = items.map((f) => {
          const name = f.FileName || f.fileName || '';
          const isDir = f.Type === 1 || f.IsFolder === true;
          if (isDir) return { name, type: 'folder', fid: String(f.FileId || f.fileId || '') };
          return {
            name, type: 'file', size: f.Size || f.fileSize || 0,
            fid: String(f.FileId || f.fileId || ''),
            url: f.DownloadUrl || f.downloadUrl || '',
            s3keyFlag: f.S3KeyFlag || f.S3keyFlag || f.s3keyFlag || '',
            etag: f.Etag || f.etag || '',
          };
        });
        fileNodes = collectFileNodes(tree);
        resolveCacheSet(provider, pKey, 'layer:' + parentFileId, { tree, files: fileNodes, stoken: '' });
      }
      const fileList = flattenForShare(tree, fileNodes.map((f) => ({ name: f.name, size: f.size, fid_token: f.fid_token })));
      return sendJson(res, 200, {
        ok: true,
        result: { files: fileList, list: fileList, dir: parentFileId, randsk: '', from_own_netdisk: false, provider },
        data: { list: fileList, detail_info: { list: fileList }, token_info: { stoken: '' }, pass_code_token: '', passcode_token: '', pass_code: body.pass_code || '', pwd_id: pKey, share_id: pKey, provider },
        files: fileList,
      });
    }
    // detail（点击进入文件夹）凭证分支：baidu 前端传 {share_url, dir:路径} 无 url 之外凭证
    if (mode === 'detail' && provider === 'baidu' && body.share_url && (body.dir !== undefined || body.parent_id || body.parent_file_id)) {
      const bduss = siteSettings.cookies[provider] || '';
      // 2026-08-20 修：兼容完整 Cookie 串 / 纯 BDUSS 值两种格式
      const cookie = buildBaiduCookie(bduss);
      // 2026-08-19 修：前端把 pwd 拆出单独传，URL 无 ?pwd= → 传 body.pass_code 兜底
      const { surl, pwd } = parseBaiduUrl(String(body.share_url), body.pass_code || body.passcode);
      const dir = String(body.dir !== undefined ? body.dir : (body.parent_id || body.parent_file_id || '/')).trim();
      // 2026-08-19 性能优化：点文件夹列表缓存 5 分钟（消除重复进入卡顿）
      const cached = resolveCacheGet(provider, surl, 'layer:' + dir);
      let tree, fileNodes;
      if (cached) {
        tree = cached.tree; fileNodes = cached.files;
      } else {
        try {
          tree = await baiduListTree(surl, pwd, cookie, dir === '/' ? '' : dir, [], false);
        } catch (e) {
          // 2026-08-20：wxlist 子目录已被百度弃用（-130）→ 页面方案兜底（Playwright 真实点击捕获）
          console.warn('[baidu] wxlist 子目录失败，走页面方案:', String(e.message || '').slice(0, 80));
          // 2026-08-20 修：dir 可能是 /sharelink{uk}-{fs_id} 或纯 fs_id 或多级 fs_id 路径 →
          //   清理成 fs_id 路径（去掉 sharelink{uk}- 前缀）整体传给页面方案（脚本支持 a/b/c 多级逐层点击）
          const fsPath = String(dir).split('/').filter(Boolean)
            .map((x) => x.replace(/^sharelink\d+-/, ''))
            .join('/');
          const pageFiles = await baiduListPage(surl.replace(/^1/, ''), pwd, fsPath);
          tree = pageFiles.map((f) => f.is_dir
            ? { name: f.name, type: 'folder', fs_id: f.fs_id, children: [] }
            : { name: f.name, type: 'file', size: f.size, fs_id: f.fs_id, url: '' });
        }
        fileNodes = collectFileNodes(tree);
        resolveCacheSet(provider, surl, 'layer:' + dir, { tree, files: fileNodes, stoken: '' });
      }
      const fileList = flattenForShare(tree, fileNodes.map((f) => ({ name: f.name, size: f.size, fs_id: f.fs_id })));
      return sendJson(res, 200, {
        ok: true,
        result: { files: fileList, list: fileList, dir, randsk: '', from_own_netdisk: false, provider },
        data: { list: fileList, detail_info: { list: fileList }, token_info: { stoken: '' }, pass_code_token: '', passcode_token: '', pass_code: body.pass_code || '', pwd_id: surl, share_id: surl, provider },
        files: fileList,
      });
    }
    // detail（点击进入文件夹）凭证分支：mcloud 前端传 {share_url, parent_file_id}
    // 2026-08-19 修：旧分支 URL 解析只支持 shareCode=/m/i?，漏掉真实 /w/i/ 形态（yun.139.com/shareweb/#/w/i/xxx）
    //   → 进入文件夹一直「无法识别移动云盘分享链接」；且旧用 caiyun.139.com/stapi/outlink/info（服务器连不上）。
    //   现直接复用 mcloudResolve（已支持三种链接 + 新接口 share-kd-njs），再在完整树里取 parent 的子层，
    //   并支持深层文件夹（旧 build 仅能匹配顶层 parentId）。
    if (mode === 'detail' && provider === 'mcloud' && body.share_url && body.parent_file_id) {
      const cookie = siteSettings.cookies[provider] || '';
      const parentId = String(body.parent_file_id || '').trim();
      // 复用分享解析（listOnly 不请求下载接口），拿完整嵌套树
      const resolved = await mcloudResolve(String(body.share_url), cookie, { listOnly: true });
      const fullTree = resolved.tree || [];
      // 在完整树中递归定位 parentId 并取其子层（支持深层）
      const findChildren = (nodes) => {
        for (const n of nodes || []) {
          if (String(n.fid || n.fs_id || '') === parentId && n.children) return n.children;
          if (n.children && n.children.length) {
            const r = findChildren(n.children);
            if (r) return r;
          }
        }
        return null;
      };
      const childNodes = findChildren(fullTree) || [];
      const fileNodes = collectFileNodes(childNodes);
      const fileList = flattenForShare(childNodes, fileNodes.map((f) => ({ name: f.name, size: f.size, fid_token: f.fid })));
      return sendJson(res, 200, {
        ok: true,
        result: { files: fileList, list: fileList, dir: parentId, randsk: '', from_own_netdisk: false, provider },
        data: { list: fileList, detail_info: { list: fileList }, token_info: { stoken: '' }, pass_code_token: '', passcode_token: '', pass_code: body.pass_code || '', pwd_id: '', share_id: '', provider },
        files: fileList,
      });
    }
    // detail（点击进入文件夹）凭证分支：xunlei 前端传 {share_id, parent_id}（无 pass_code！）
    // 2026-08-19 改：Playwright 页面方案（旧 POST /drive/v1/share 需要 captcha token，
    //   服务器无 WASM 无法生成，改用服务器浏览器自动 init token）
    // 2026-08-20 修：前端 detail 请求只带 share_id/parent_id/pass_code_token，
    //   body 无 pass_code → 迅雷 PASS_CODE_EMPTY。用 share 阶段按 shareId 缓存的提取码兜底
    if (mode === 'detail' && provider === 'xunlei' && body.share_id && body.parent_id) {
      const shareId = String(body.share_id || '').trim();
      const parentId = String(body.parent_id || '').trim();
      const pwd = String(body.passcode || body.pass_code || '').trim() || getXunleiPwd(shareId);
      const r = await runXunleiPage(shareId, pwd, parentId, String(body.stoken || body.pass_code_token || ''));
      if (!r.ok) throw new Error(r.error || '迅雷进入文件夹失败');
      const st = r.share_status || '';
      if (st && st !== 'OK') throw new Error('迅雷分享不可用（' + st + '）');
      const fullTree = (r.files || []).map((f) => f.kind === 'drive#folder'
        ? { name: f.name, type: 'folder', fid: f.id, children: [] }
        : { name: f.name, type: 'file', size: f.size || 0, fid: f.id });
      const fileNodes = collectFileNodes(fullTree);
      // 2026-08-19 性能优化：点文件夹列表缓存 5 分钟（消除重复进入卡顿）
      resolveCacheSet(provider, shareId, 'layer:' + parentId, { tree: fullTree, files: fileNodes, stoken: r.pass_code_token || '' });
      const fileList = flattenForShare(fullTree, fileNodes.map((f) => ({ name: f.name, size: f.size, fid_token: f.fid_token })));
      return sendJson(res, 200, {
        ok: true,
        result: { files: fileList, list: fileList, dir: parentId, randsk: '', from_own_netdisk: false, provider },
        data: { list: fileList, detail_info: { list: fileList }, token_info: { stoken: r.pass_code_token || '' }, pass_code_token: r.pass_code_token || '', passcode_token: r.pass_code_token || '', pass_code: body.pass_code || '', pwd_id: shareId, share_id: shareId, provider },
        files: fileList,
      });
    }
    // share / detail(url 模式)：listOnly=true 只用公开接口列当前层，不转存不动 Cookie
    // 2026-08-19 性能优化：share 列表结果缓存 5 分钟（点文件夹/返回上一级秒开，消除卡顿）
    // 2026-08-20 22:3x 修：缓存扩展到**所有 provider**（之前只有 quark/uc；百度 wxlist 失效后
    //   每次走 buildBaiduFullTree Playwright 34s → 列表卡顿，缓存后同一分享 5 分钟内秒开）
    let r = null;
    {
      const cacheKey = url || body.share_url || '';
      const subKey = mode === 'detail' ? 'detail:' + (body.pdir_fid || body.parent_id || '') : 'root';
      const hit = resolveCacheGet(provider, cacheKey, subKey);
      if (hit) {
        r = { provider, providerName: PROVIDER_NAME[provider], tree: hit.tree, files: hit.files, stoken: hit.stoken };
      } else {
        try {
          r = await resolveProvider(provider, url, {
            allowSave: false, listOnly: true,
            pass_code: body.pass_code || body.passcode || '',
          });
        } catch (e) {
          return sendJson(res, 200, { ok: false, error: pandlErrorCode(e), message: e.message || '解析失败' });
        }
        resolveCacheSet(provider, cacheKey, subKey, {
          tree: r.tree, files: r.files, stoken: r.stoken || '',
        });
      }
    }
    // 2026-08-19（用户拍板）：share 递归拿完整树 → 响应同时给：
    //   - result.files/data.list：仅**根层**（前端首屏渲染，文件夹可点击）
    //   - full_tree：完整嵌套树（前端 buildDisplayTree 后本地切层，点文件夹零请求）
    // 根层 = tree 第一层节点；子层由前端从 full_tree 取
    const rootNodes = (r.tree || []).filter((n) => n); // 第一层
    const fileList = rootNodes.map((n) => {
      const isDir = n.type === 'folder';
      return {
        dir: isDir, is_dir: isDir, isdir: isDir, kind: isDir ? 'drive#folder' : 'drive#file',
        id: n.fid || n.fs_id || `f_${Math.random().toString(36).slice(2, 8)}`,
        parent_id: n.parent_id || '',
        fid: n.fid || n.fs_id || '',
        pdir_fid: n.parent_id || '',
        file_name: n.name,
        server_filename: n.name,
        name: n.name,
        size: n.size || 0,
        fid_token: n.fid_token || n.share_fid_token || '',
        // 2026-08-19：保留直链（123盘 解析时已取直链）+ 下载参数
        url: n.url || '', download_url: n.url || '',
        s3keyFlag: n.s3keyFlag || n.S3KeyFlag || '',
        etag: n.etag || n.Etag || '',
        // 2026-08-19 修：透传节点真实创建时间（不再 Date.now() 写死）
        // 前端 Vp() 用 Number(created_at)——给数字毫秒值
        created_at: n.created_at ? new Date(n.created_at).getTime() : Date.now(), created_time: n.created_at ? new Date(n.created_at).toISOString() : '',
        updated_at: n.updated_at || Date.now(), md5: '',
        // 内置子层引用（前端本地切层直接用，无需再请求）
        children: isDir && n.children ? buildDisplayTree(n.children) : undefined,
      };
    });
    const fullTree = buildDisplayTree(r.tree || []);
    // 2026-08-19 修（UC 前端契约）：UC 前端分支读 result.uc.data.{token_info.stoken, list/detail_info.list}
    //   旧响应只在 result.files 给数据 → n=e.result.uc 恒为 undefined → UC 列表恒空白「暂无解析数据」。
    //   此处按前端契约补 result.uc（仅 UC 生效），其余网盘继续走 result.files，互不影响。
    const pandlData = {
      list: fileList,
      detail_info: { list: fileList },
      token_info: { stoken: String(r.stoken || body.stoken || '') },
      pass_code_token: '',
      passcode_token: '',
      pass_code: body.pass_code || '',
      pwd_id: '',
      share_id: '',
      provider,
    };
    sendJson(res, 200, {
      ok: true,
      result: {
        files: fileList,
        list: fileList,
        dir: '/',
        randsk: '',
        from_own_netdisk: false,
        provider,
        ...(provider === 'uc' ? { uc: { data: pandlData } } : {}),
      },
      data: pandlData,
      files: fileList,
      full_tree: fullTree,
    });
  } catch (e) {
    warnCookieOnError(provider, e);
    const u = String(body && (body.url || body.share_url || '') || '').slice(0, 60);
    pushAdminLog('parse_err', `${provider} 解析失败: ${String(e.message || '').slice(0, 100)} | url=${u}`);
    sendJson(res, 200, { ok: false, error: pandlErrorCode(e), message: e.message });
  }
}

// 前端 fetch 处理：返回 download_url/dlink 兼容夸克/百度
// 关键：fetch = 用户点击「获取下载链接/发送到下载器」→ 此时才转存（allowSave=true）+ 记录「今日解析」
// 2026-08-21（用户拍板，参考 pdpb.cn 密码墙）：网盘「发送到下载器」解锁检查（公共）
//   存在启用中的 dl_{provider} 任务 → 该网盘需先解锁（完成任务→校验今日密码→claim→downloaderUnlocked=true）。
//   返回 need_unlock 响应体（引导去「任务绑定的网盘」拿今日密码）或 null（无需解锁/已解锁）。
function needUnlockResponse(provider, req) {
  const lockTask = dailyTasks.find((t) => t.id === 'dl_' + provider && t.enabled !== false);
  if (!lockTask) return null;
  const qq = getQuota(req.deviceId);
  if (!qq.downloaderUnlocked) qq.downloaderUnlocked = {};
  if (qq.downloaderUnlocked[provider]) return null;
  const dp = loadDailyPasswords() || {};
  const unlockProv = lockTask.task_provider || provider;
  const promo = siteSettings.promo[unlockProv] || {};
  return {
    ok: false,
    need_unlock: true,
    provider,
    unlock_provider: unlockProv,
    provider_name: PROVIDER_NAME[unlockProv] || unlockProv,
    task_id: lockTask.id,
    passcode_hint: promo.passcode || DEFAULT_PROMO_PASSCODE[unlockProv] || '请前往网盘获取今日解析密码',
    link: promo.link || '',
    qr_url: promo.qrUrl || '',
    today_share: (dp.shares && dp.shares[unlockProv]) || '',
    has_today_password: !!(dp.codes && dp.codes[unlockProv]),
    message: `请前往${PROVIDER_NAME[unlockProv] || unlockProv}获取今日解析密码`,
  };
}

async function pandlFetchHandle(req, res, provider, body) {
  // 2026-08-20 15:53 用户核心需求：**只在点「发送到下载器」才转存（prepare=true）→ 发送 → 删除**。
  //   fetch（点文件「下载」按钮）默认不转存，只返回元信息+凭证+needs_transfer=true；
  //   前端 wg() 发送前调 /api/prepare-download（prepare=true）→ 后端转存+直链+登记待删除 → 前端推送。
  //   —— 彻底解决「每次点下载就转存占满运营者网盘」问题。
  const prepare = body.prepare === true || body.prepare === 'true' || body.prepare === 1 || body.action === 'prepare';
  const url = body.url || body.share_url || body.shareUrl || '';
  // 2026-08-20 14:55 修复：UC/夸克等凭证模式前端不传 url 只传 share_id → 构造 url
  let resolvedUrl = url;
  if (!resolvedUrl && body.share_id) {
    if (provider === 'uc') resolvedUrl = 'https://drive.uc.cn/s/' + body.share_id;
    else if (provider === 'quark') resolvedUrl = 'https://pan.quark.cn/s/' + body.share_id;
    else if (provider === 'xunlei') resolvedUrl = 'https://pan.xunlei.com/s/' + body.share_id;
  }
  const fileName = body.file_name || body.fileName || body.name || '';
  // 2026-08-21（用户拍板，参考 pdpb.cn 密码墙）：发送到下载器前，该网盘须先「解锁」
  //   （完成任务 → 校验输入 = 该网盘今日密码 → 领取奖励 → downloaderUnlocked[provider]=true）。
  //   未解锁 → 返回 need_unlock，前端弹「去网盘获取今日密码 + 输入 4 位密码」引导。
  if (prepare && provider) {
    const _unl = needUnlockResponse(provider, req);
    if (_unl) return sendJson(res, 200, _unl);
  }
  try {
    let target;
    if (provider === 'quark' && (body.pwd_id || body.share_id) && (body.fid || body.file_id)) {
      // 凭证模式（前端夸克真实协议 2026-08-16 实锤）：
      //   前端点「下载」传 {pwd_id, stoken, pdir_fid, fid, share_fid_token, fid_token, file_name, ...}，
      //   **不传 url** —— 后端直接凭凭证拿直链（免转存 → 失败转存）
      const t = await quarkFetchDirect(body);
      target = t;
      if (t.updatedCookie && t.updatedCookie !== siteSettings.cookies.quark) {
        siteSettings.cookies.quark = t.updatedCookie;
        saveSettings(); // 2026-08-19 code-review: cookie 续期必须写盘，否则重启回滚旧 cookie
        pushAdminLog('cookie_refresh', '夸克 __puus 自动续期并已写回');
      }
    } else if (provider === 'baidu' && (body.fs_id || body.dir || body.parent_id)) {
      // 2026-08-20 14:05：百度下载 = 「转存下载删除」（分享直链 2026 已失效）
      //   baidu_transfer.py：Playwright 拿 sekey → share/transfer 转存管理员网盘 →
      //   locatedownload 自己网盘直链 → 删除转存文件。下载走管理员账号（用户方案）
      const { surl, pwd } = parseBaiduUrl(url, body.pass_code || body.passcode || '');
      const fsId = String(body.fs_id || '').trim()
        || String(body.dir || '').split('/').filter(Boolean).pop() || '';
      if (!fsId) throw new Error('百度下载缺少文件 fs_id');
      if (!prepare) {
        // 2026-08-20 15:53：fetch 阶段不转存（只在点「发送到下载器」才转存）→ 返回凭证
        target = { name: fileName || '百度网盘文件', size: 0, url: '', needs_transfer: true, fs_id: fsId, surl, pwd };
      } else {
        const tf = await baiduTransfer(surl.replace(/^1/, ''), pwd, fsId);
        target = { name: tf.name, size: tf.size || 0, url: tf.url, expiresAt: 0, transferred: true, transferredUrl: '' };
        // 2026-08-20 15:53：登记待删除（后删除机制：发送后 /api/downloader-push-log 上报删除 / TTL 兜底）
        if (tf.to_path) {
          registerPendingSave('baidu', String(body.share_id || surl), fileName || tf.name, [tf.to_path], siteSettings.cookies.baidu);
        }
      }
    } else if (provider === 'xunlei') {
      if (!prepare) {
        // 2026-08-20 15:53：fetch 阶段不转存（只在点「发送到下载器」才转存）→ 只解析返回元信息
        const r0 = await resolveProvider(provider, resolvedUrl, {
          listOnly: true,
          pass_code: body.pass_code || body.passcode || getXunleiPwd(String(body.share_id || body.pwd_id || '')),
        });
        const f0 = (r0.files || []).find((f) => f.name === fileName);
        target = { name: f0 ? f0.name : fileName || '迅雷云盘文件', size: f0 ? f0.size : 0, url: '', needs_transfer: true };
      } else {
        // 2026-08-20：迅雷无公开直链 → 转存到运营者迅雷云盘，返回真实下载直链
        const r = await resolveProvider(provider, resolvedUrl, {
          allowSave: true,
          pass_code: body.pass_code || body.passcode || getXunleiPwd(String(body.share_id || body.pwd_id || '')),
          // 2026-08-20 13:36：按用户点的目标文件转存（body.file_name 来自前端）
          target_file: body.file_name || body.fileName || body.name || '',
        });
        const tf = r.transfer;
        if (!tf || !tf.ok || !tf.transferred) {
          throw new Error('迅雷转存失败：' + ((tf && tf.error) || '请稍后重试'));
        }
        const newFid = (tf.new_file_ids || [])[0] || '';
        // 构造「我的云盘」网页链接（用户可直接打开下载，兜底用）
        const webUrl = newFid
          ? 'https://pan.xunlei.com/?path=' + encodeURIComponent(tf.title || '') + '&dir_id=' + encodeURIComponent(newFid)
          : 'https://pan.xunlei.com/';
        // 2026-08-20 13:35：xunlei_download.py 已扩展拿真实下载直链
        //   （restore 转存 → usage=CONSUME → medias[].link.url，vip-lixian 会员加速节点）
        //   → url 优先真实直链（可直接发下载器），webUrl 作转存兜底
        const dlUrl = tf.url || '';
        target = {
          name: tf.title || '迅雷云盘文件',
          size: Number(tf.size) || 0,
          url: dlUrl || webUrl,
          expiresAt: 0, transferred: true, newFileIds: tf.new_file_ids || [],
          transferredUrl: webUrl,
        };
        // 标记：迅雷走「转存成功」提示，不当作普通直链
        req._xunleiTransferred = true;
        // 2026-08-20 15:53：登记待删除（后删除机制）
        if (tf.new_file_ids && tf.new_file_ids.length) {
          registerPendingSave('xunlei', String(body.share_id || ''), body.file_name || body.fileName || body.name || tf.title || 'all', tf.new_file_ids, siteSettings.cookies.xunlei);
        }
      }
    } else {
      const r = await resolveProvider(provider, resolvedUrl, {
        // 2026-08-20 15:53：默认不转存！只有 prepare（点发送到下载器）才 allowSave 转存
        allowSave: !!prepare,
        // 2026-08-19：fetch 也要提取码（前端把 ?pwd= 拆出放 body.pass_code）
        pass_code: body.pass_code || body.passcode || '',
        // 2026-08-20 14:55：透传 UC 凭证（前端进入文件夹后调 fetch 不传 url，用 share_id + pdir_fid + stoken）
        stoken: body.stoken || '',
        pdir_fid: body.pdir_fid || '',
        fid_token: body.fid_token || '',
        target_fid: body.fid || '',
        target_file: fileName,
      });
      const found = (r.files || []).find((f) => f.name === fileName);
      if (found && found.url) {
        target = found;
      } else if (!prepare && found) {
        // 2026-08-20 15:53：需要转存的 provider（uc/pan123）fetch 阶段不转存 → 返回凭证 + needs_transfer
        target = { name: found.name, size: found.size || 0, url: '', needs_transfer: true, fid: found.fid || '', transferFileId: found.transferFileId || '' };
      }
      // 2026-08-20 21:55 修（123 副本堆积真凶之二）：123 prepare（秒传转存）的副本**必须登记**
      //   否则 push-log/TTL 找不到 pendingSaves 记录 → 永不删除 → 账号被转存副本塞满
      if (found && found.url && prepare && provider === 'pan123' && found.transferFileId) {
        registerPendingSave('pan123', String(body.share_id || shareId || ''), fileName || found.name, [found.transferFileId], siteSettings.cookies.pan123);
      }
    }
    if (!target) throw new Error('未找到目标文件，请重新获取文件列表');
    if (prepare && !target.url) throw new Error('未获取到下载直链，请稍后重试');
    // 提取 shareId（供"今日解析"记录 + 再次发送定位）
    let shareId = '';
    try { shareId = new URL(url).pathname.split('/').pop() || ''; } catch {}
    // 记录用户「今日解析」（/api/my-downloads 数据源，去重；prepare 是发送动作不重复记录）
    if (!prepare) recordDownloadLog(req.deviceId, provider, shareId || body.pwd_id || body.share_id || '', target);
    // 2026-08-19 code-review: 每次 fetch 递减每日额度（让 ip-quota 统计准确；不强制拦截保 demo 可用）
    if (!prepare) {
      try {
        const qq = getQuota(req.deviceId);
        if (qq && qq.largeCountLeft > 0) qq.largeCountLeft -= 1;
      } catch {}
    }
    // 2026-08-20 14:45 修复：result 字段构造移到 cookie 设置之后，
    //   否则 1137/1142 行 result.xxx = ck 被这里的 = 覆盖（前端拿不到 cookie → useSpecialHeaders 报错"UC直链缺少发送 Cookie"）
    //   同时给 123/移动/百度/迅雷补 account cookie（用户需求：下载走管理员账号凭证）
    if (provider === 'quark' && siteSettings.cookies.quark) {
      const ck = quarkSenderCookie(siteSettings.cookies.quark);
      target._cookie = ck;
    }
    if (provider === 'uc' && siteSettings.cookies.uc) {
      const ck = ucSenderCookie(siteSettings.cookies.uc);
      target._cookie = ck;
    }
    if (provider === 'baidu' && siteSettings.cookies.baidu) {
      target._cookie = buildBaiduCookie(siteSettings.cookies.baidu);
    }
    if (provider === 'pan123' && siteSettings.cookies.pan123) {
      target._cookie = siteSettings.cookies.pan123;
    }
    if (provider === 'mcloud' && siteSettings.cookies.mcloud) {
      target._cookie = siteSettings.cookies.mcloud;
    }
    if (provider === 'xunlei' && siteSettings.cookies.xunlei) {
      target._cookie = siteSettings.cookies.xunlei;
    }
    const result = {
      download_url: target.url,
      dlink: target.url,
      url: target.url,
      file_name: target.name,
      file_size: target.size || 0,
      expires_at: target.expiresAt || 0,
      provider,
    };
    // 2026-08-20 15:53：fetch 阶段未转存的网盘 → 通知前端「发送到下载器时再生成直链」
    if (target.needs_transfer) {
      result.needs_transfer = true;
      if (target.fs_id) result.fs_id = target.fs_id;
      if (target.fid) result.fid = target.fid;
      if (target.transferFileId) result.transfer_file_id = target.transferFileId;
    }
    // 2026-08-20：转发管理员 cookie 给下载器（按 provider 命名，匹配前端 useSpecialHeaders / Yu()/Eu() 等）
    if (target._cookie) {
      result.cookie = target._cookie;
      if (provider === 'quark') { result.quark_sender_cookie = target._cookie; result.quark_account_cookie = target._cookie; }
      if (provider === 'uc') { result.uc_sender_cookie = target._cookie; result.uc_account_cookie = target._cookie; }
      if (provider === 'baidu') { result.baidu_sender_cookie = target._cookie; result.baidu_account_cookie = target._cookie; }
      if (provider === 'pan123') { result.pan123_account_cookie = target._cookie; }
      if (provider === 'mcloud') { result.mcloud_account_cookie = target._cookie; }
      if (provider === 'xunlei') { result.xunlei_account_cookie = target._cookie; }
    }
    // 2026-08-20：迅雷转存成功 → 前端展示「已转存到迅雷云盘」卡片（非普通直链）
    if (provider === 'xunlei' && target.transferred) {
      result.transferred = true;
      result.transferred_ids = target.newFileIds || [];
      result.transferred_title = target.name || '';
      result.message = '已转存到你的迅雷云盘，打开链接即可下载';
    }
    sendJson(res, 200, {
      ok: true,
      result,
      data: {
        download_url: target.url,
        dlink: target.url,
        url: target.url,
        file_name: target.name,
        file_size: target.size || 0,
        expires_at: target.expiresAt || 0,
        provider,
      },
      download_url: target.url,
      dlink: target.url,
      file_name: target.name,
    });
  } catch (e) {
    warnCookieOnError(provider, e);
    // 记录真实失败原因（含收到的 url 前 60 字符，便于定位前端传参问题）
    const u = String(body && (body.url || body.share_url || '') || '').slice(0, 60);
    pushAdminLog('parse_err', `${provider} 获取下载链接失败: ${String(e.message || '').slice(0, 100)} | url=${u}`);
    sendJson(res, 200, { ok: false, error: pandlErrorCode(e), message: e.message });
  }
}

// 解析失败且错误像 Cookie 失效 → 实时检测该网盘并告警（2026-08-16）
function warnCookieOnError(provider, e) {
  const msg = String((e && e.message) || '');
  if (!msg) return;
  if (!/(Cookie|登录|未登录|鉴权|token)/i.test(msg)) return;
  const ck = siteSettings.cookies[provider] || '';
  if (!ck) return;
  checkCookie(provider, ck)
    .then((r) => { if (r.status === 'invalid') return alertCookieIssue(r.provider, r.name, r.status, r.detail); })
    .catch(() => {});
}
// 树形结果 → 前端需要的文件项结构
// 前端 Vp() 用 {dir, fid, pdir_fid, file_name, size, created_at}（夸克路径）
//         Ip() 用 {dir, fs_id, server_filename, ...}（百度路径）
// 同时给两种命名让所有网盘前端逻辑都能消费

// 错误 → 错误码（前端有完整中文映射表，只需给 key）
function pandlErrorCode(e) {
  const m = String(e && e.message || '');
  if (m.includes('Cookie')) return 'scan_cmd_not_configured';
  if (m.includes('提取码') || m.includes('密码')) return 'invalid_parse_password';
  if (m.includes('失效') || m.includes('已取消') || m.includes('不存在')) return 'share_not_found';
  if (m.includes('容量') || m.includes('空间')) return 'ip_single_size_exceeded';
  if (m.includes('未接入')) return 'node_not_configured';
  // 按网盘细分（2026-08-16：原来一律兜底「网盘 Node 服务响应异常」，用户看不到真实原因）
  if (/夸克/.test(m)) return 'quark_request_failed';
  if (/UC/.test(m)) return 'uc_api_error';
  if (/百度/.test(m)) return 'baidu_request_failed';
  if (/123|pan123/.test(m)) return 'pan123_request_failed';
  if (/迅雷/.test(m)) return 'xunlei_request_failed';
  // 移动云盘 / 转存失败：前端无对应错误码 → 回落笼统提示（避免未知码显示空白）
  if (m.includes('失败')) return 'node_response_not_json';
  return 'node_response_not_json';
}

// 额度视图（前端字段）
function pandlQuotaView(q) {
  return {
    unlocked: q.unlocked,
    large_count_left: q.largeCountLeft,
    small_file_unlocked: q.smallFileUnlocked,
    small_size_left_mb: Math.round(q.smallSizeLeft / MB),
    size_cap_unlocked: q.sizeCapUnlocked,
    size_cap_gb: q.sizeCapUnlocked ? 0 : siteSettings.sizeCapGB,
    ip_daily_count_remaining: q.largeCountLeft,
    ip_daily_size_remaining: Math.round(q.smallSizeLeft / MB),
    device_daily_count_remaining: q.largeCountLeft,
    device_daily_size_remaining: Math.round(q.smallSizeLeft / MB),
  };
}

// =====================================================================
//  真实网盘解析（用你自己的 Cookie，调网盘官方/公开接口）
// =====================================================================



// 从树中收集所有文件节点（用于批量取直链）

// 2026-08-19：把后端 tree（{name,type,fid,children}）转成前端可直接渲染的嵌套结构
// （前端 Vp() 需要 dir/fid/file_name/size，children 递归保留 → 前端本地切层零请求）

async function quarkResolve(url, cookie, opts = {}) {
  const cookieRef = { value: cookie };
  const { pwdId, passcode, pdirFid } = parseQuarkUrl(url, opts.pass_code || opts.passcode);

  // 1) 拿 stoken —— 分享页公开接口，无需 Cookie（2026-08-19 实测：无 cookie 正常返回 stoken）
  const tokenRes = await quarkRequest('POST',
    `${QUARK_API}/1/clouddrive/share/sharepage/token?pr=ucpro&fr=pc&__dt=${Date.now()}`,
    { pwd_id: pwdId, passcode: passcode || '' }, cookieRef);
  if (tokenRes.code !== 0) {
    if (tokenRes.code === 31001) throw new Error('此分享需要提取码，请在链接末尾加 ?pwd=密码');
    if (tokenRes.code === 31002) throw new Error('分享链接已失效或被取消');
    throw new Error(`获取 Token 失败: ${tokenRes.message}`);
  }
  const stoken = tokenRes.data.stoken;

  // 2) 列出分享内文件/文件夹（树形）
  //    2026-08-19（用户拍板）：share 解析阶段**递归拿完整树**（recursive=true），前端本地持树、
  //    点文件夹本地切层零请求（不再逐层调 API）；detail 凭证分支仍只列当前层（兜底/直接进入子层）。
  //    fetch 阶段（allowSave=true，url 模式兜底找目标文件）同样递归完整树
  const tree = await quarkListTree(cookieRef, pwdId, stoken, pdirFid, true);
  const fileNodes = collectFileNodes(tree);
  if (fileNodes.length === 0 && tree.length === 0) throw new Error('该分享没有可解析的文件（可能是空文件夹）');

  // 2.5) 解析阶段（listOnly）：不取直链、不动 Cookie（用户 2026-08-19 需求）
  //     tree 为完整嵌套树（前端 buildDisplayTree 后本地切层零请求）
  //     stoken 仍要返回（前端凭证模式下载需要，2026-08-19 修复：此前 stoken 缺失导致前端无法获取文件）
  if (opts.listOnly) {
    return {
      tree,
      files: fileNodes.map((f) => ({ name: f.name, size: f.size, url: '', expiresAt: 0, needSave: true, fid_token: f.fid_token })),
      stoken,
      updatedCookie: cookieRef.value,
    };
  }

  const fids = fileNodes.map((f) => f.fid);
  const tokens = fileNodes.map((f) => f.fid_token);

  // 3) 取直链：fetch 阶段（allowSave=true）**转存优先**（2026-08-19 修复，参考 gopeed-extension-quark）
  //    参考项目标准流程：转存 sharepage/save → 拿转存副本直链（自己账号可下载）→ 发直链 → 下载完成删除副本
  //    之前「免转存优先」的 bug：免转存拿到的 guest 直链下载必 403（CDN 校验登录态），
  //    但代码误判「成功」→ 转存被短路 → 用户拿到 403 直链。现改为先转存，转存失败才回退免转存。
  //    - 解析阶段（share/detail，allowSave=false / listOnly=true）：直链留空，不转存不动 Cookie
  //    - 点击下载阶段（fetch，allowSave=true）：转存拿直链 → 登记副本 → 下载完成/ TTL 后删除
  let dlData = null;
  let savedFids = null;
  if (opts.allowSave) {
    // ===== fetch 阶段：转存优先 =====
    try {
      savedFids = await quarkSave(fids, tokens, pwdId, stoken, cookieRef);
      const dl = await quarkRequest('POST',
        `${QUARK_DRIVE}/1/clouddrive/file/download?pr=ucpro&fr=pc`,
        { fids: savedFids }, cookieRef);
      if (Array.isArray(dl.data) && dl.data.length) dlData = dl.data;
    } catch (saveErr) {
      // 转存失败（41017 禁止转存自己的分享 / 32003 容量不足等）→ 回退免转存直链（尽力而为）
      try {
        const dl = await quarkRequest('POST',
          `${QUARK_DRIVE}/1/clouddrive/file/download?pr=ucpro&fr=pc`,
          { fids, fid_token_list: tokens, stoken, pwd_id: pwdId }, cookieRef);
        if (Array.isArray(dl.data) && dl.data.length) dlData = dl.data;
      } catch (e2) {
        throw new Error('获取夸克直链失败：转存未成功（' + (saveErr.message || saveErr) + '），免转存回退也失败');
      }
    }
  } else {
    // ===== 解析阶段（listOnly / allowSave=false）：不取直链 =====
    try {
      const dl = await quarkRequest('POST',
        `${QUARK_DRIVE}/1/clouddrive/file/download?pr=ucpro&fr=pc`,
        { fids, fid_token_list: tokens, stoken, pwd_id: pwdId }, cookieRef);
      if (Array.isArray(dl.data) && dl.data.length) dlData = dl.data;
    } catch (e) {
      // 解析阶段不转存：直链留空，前端列表正常展示，点击下载时 fetch 再拿
      // 转存仅当用户真正要下载时发生（避免解析即转存白占网盘空间）
    }
  }
  // 解析阶段若免转存失败，返回空直链（前端列表仍可见，下载时 fetch 会再拿）
  if (!dlData && !opts.allowSave) {
    return {
      tree,
      files: fileNodes.map((f) => ({ name: f.name, size: f.size, url: '', expiresAt: 0, needSave: true })),
      updatedCookie: cookieRef.value,
    };
  }
  if (!dlData) throw new Error('获取夸克直链失败（转存未成功，请重试）');

  // 4) 转存副本保留登记：不立即删除（直链有有效期，用户下载可能晚于解析）
  //    由「下载完成上报」或「TTL 兜底清理」负责删除
  //    2026-08-19 安全加固：副本达上限时立即删除刚转存的副本（防占满运营者网盘）
  if (savedFids && savedFids.length) {
    if (!registerPendingSave('quark', pwdId, 'all', savedFids, cookieRef.value)) {
      try { await quarkDelete(savedFids, cookieRef); } catch {}
      throw new Error('转存副本已达上限，请稍后重试');
    }
  }

  // 5) 按请求顺序把直链写回文件节点（download 返回顺序与 fids 一致）
  fileNodes.forEach((n, i) => {
    const d = dlData[i];
    if (d) { n.url = d.download_url; n.expiresAt = d.expires_at || null; }
  });

  return { tree, files: fileNodes.map((f) => ({ name: f.name, size: f.size, url: f.url, expiresAt: f.expiresAt, fid_token: f.fid_token })), stoken, updatedCookie: cookieRef.value };
}

// 删除夸克网盘文件（action_type=2 移入回收站；参考 gopeed-extension-quark / quark-auto-save）
async function quarkDelete(filelist, cookieRef) {
  if (!Array.isArray(filelist) || !filelist.length) return;
  await quarkRequest('POST',
    `${QUARK_DRIVE}/1/clouddrive/file/delete?pr=ucpro&fr=pc&uc_param_str=`,
    { action_type: 2, filelist, exclude_fids: [] }, cookieRef);
}

async function quarkSave(fids, tokens, pwdId, stoken, cookieRef) {
  const save = await quarkRequest('POST',
    `${QUARK_DRIVE}/1/clouddrive/share/sharepage/save?pr=ucpro&fr=pc`,
    { fid_list: fids, fid_token_list: tokens, to_pdir_fid: '0', pwd_id: pwdId, stoken, pdir_fid: '0', scene: 'link' },
    cookieRef);
  let savedFids = save.data?.task_resp?.data?.save_as?.save_as_top_fids;
  if (!Array.isArray(savedFids) || savedFids.length === 0) {
    const taskId = save.data?.task_id;
    if (!taskId) throw new Error('转存未返回任务，可能 Cookie 无转存权限');
    savedFids = await quarkPoll(taskId, cookieRef);
  }
  return savedFids;
}

// 夸克「凭证模式」拿单文件直链（2026-08-16 前端契约实锤）
// 前端点「下载」传 {pwd_id, stoken, pdir_fid, fid, share_fid_token, fid_token, file_name}，不传 url
// 流程：转存优先（参考 gopeed-extension-quark）→ 拿转存副本直链（可下载）→ 登记副本 → 下载完成删除
//       转存失败（41017 自己的分享 / 32003 容量不足）→ 回退免转存直链（尽力而为）
async function quarkFetchDirect(creds) {
  const pwdId = String(creds.pwd_id || creds.share_id || '').trim();
  const fid = String(creds.fid || creds.file_id || '').trim();
  if (!pwdId || !fid) throw new Error('缺少夸克下载凭证（pwd_id/fid）');
  const cookieRef = { value: siteSettings.cookies.quark };
  let stoken = String(creds.stoken || '').trim();
  // stoken 缺失时重新换取（前端可能不带）
  if (!stoken) {
    const tokenRes = await quarkRequest('POST',
      `${QUARK_API}/1/clouddrive/share/sharepage/token?pr=ucpro&fr=pc&__dt=${Date.now()}`,
      { pwd_id: pwdId, passcode: creds.passcode || creds.pass_code || '' }, cookieRef);
    stoken = (tokenRes.data && tokenRes.data.stoken) || '';
    if (!stoken) throw new Error('获取夸克分享凭证失败');
  }
  const fids = [fid];
  const tokens = [String(creds.share_fid_token || creds.fid_token || '').trim()];
  let dlData = null;
  let savedFids = null;
  // ===== 转存优先 =====
  try {
    savedFids = await quarkSave(fids, tokens, pwdId, stoken, cookieRef);
    const dl = await quarkRequest('POST',
      `${QUARK_DRIVE}/1/clouddrive/file/download?pr=ucpro&fr=pc`,
      { fids: savedFids }, cookieRef);
    if (Array.isArray(dl.data) && dl.data.length) dlData = dl.data;
  } catch (saveErr) {
    // 转存失败（41017 禁止转存自己的分享 / 32003 容量不足等）→ 回退免转存直链
    try {
      const dl = await quarkRequest('POST',
        `${QUARK_DRIVE}/1/clouddrive/file/download?pr=ucpro&fr=pc`,
        { fids, fid_token_list: tokens, stoken, pwd_id: pwdId }, cookieRef);
      if (Array.isArray(dl.data) && dl.data.length) dlData = dl.data;
    } catch (e2) {
      throw new Error('获取夸克直链失败：转存未成功（' + (saveErr.message || saveErr) + '），免转存回退也失败');
    }
  }
  if (!dlData || !dlData[0] || !dlData[0].download_url) {
    throw new Error('获取夸克直链失败（转存未成功，请重试）');
  }
  // 转存副本登记清理（与 quarkResolve 一致：下载完成上报或 TTL 兜底删除）
  // 2026-08-19 安全加固：副本达上限时立即删除刚转存的副本
  if (savedFids && savedFids.length) {
    if (!registerPendingSave('quark', pwdId, 'all', savedFids, cookieRef.value)) {
      try { await quarkDelete(savedFids, cookieRef); } catch {}
      throw new Error('转存副本已达上限，请稍后重试');
    }
  }
  const item = dlData[0];
  return {
    name: item.file_name || creds.file_name || '',
    size: item.size || 0,
    url: item.download_url || '',
    expiresAt: (item.expires_at || 0) * 1000 || 0,
    updatedCookie: cookieRef.value,
  };
}

async function quarkPoll(taskId, cookieRef) {
  for (let i = 0; i < 60; i++) {
    await new Promise((r) => setTimeout(r, 1000));
    const r = await quarkRequest('GET',
      `${QUARK_DRIVE}/1/clouddrive/task?pr=ucpro&fr=pc&task_id=${taskId}&__dt=${Date.now()}`, null, cookieRef);
    const fids = r.data?.save_as?.save_as_top_fids || r.data?.save_as?.save_as_select_top_fids;
    if (Array.isArray(fids) && fids.length) return fids;
    if (r.data?.status === 3) throw new Error('转存失败：网盘空间不足或风控');
  }
  throw new Error('转存超时');
}

// ---------- 百度（分享方式，用 BDUSS）----------


// ---------- UC 网盘（与夸克同构：阿里 clouddrive API，域名换 pc-api.uc.cn）----------
// 参考：gucheng910/gopeed-cloud-extensions + hmjz100/LinkSwift（UC 与夸克 sharepage 完全同构，已实测确认）
// UC 分享链接：https://drive.uc.cn/s/{shareId}（可带 # 内 pwd 或 ?pwd= 提取码）
async function ucResolve(url, cookie, opts = {}) {
  const cookieRef = { value: cookie };
  // ⚠️ 实测（2026-08-15）：UC 直链是 OSS 签名 URL，但下载时 CDN 校验 client_token 绑定登录态，
  //    无 Cookie 拿到的直链下载必 403「require login [auth not found]」。
  //    因此 UC 与夸克一致，下载阶段必须配置运营者 Cookie；解析阶段（listOnly）免 Cookie 只列文件。
  if (!cookie && !opts.listOnly) throw new Error('UC 网盘需要配置运营者账号 Cookie（直链下载需登录态），请在后台填写');
  const rawUrl = String(url || '');
  const shareId = (rawUrl.match(/\/s\/([A-Za-z0-9_-]+)/) || [])[1] || '';
  if (!shareId) throw new Error('无法识别 UC 分享链接');
  // 提取码：优先 URL 里的 pwd 参数
  const passcode = (rawUrl.match(/[?&#]pwd=([a-zA-Z0-9]+)/i) || [])[1] || '';

  // 通用请求（UC 与夸克同构，仅域名/参数不同）
  const ucRequest = async (method, path, body) => {
    const headers = {
      'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120 Safari/537.36',
      'Referer': 'https://drive.uc.cn/',
      'Origin': 'https://drive.uc.cn',
      'Content-Type': 'application/json',
    };
    if (cookieRef.value) headers.Cookie = cookieRef.value;
    // path 可能是相对路径（/1/...）或完整 URL（https://...）；完整 URL 直接使用，避免拼接错误
    const fullUrl = /^https?:\/\//i.test(path) ? path : `${UC_API}${path}`;
    const resp = await fetchTimeout(fullUrl, { method, headers, body: body ? JSON.stringify(body) : undefined });
    const data = await resp.json().catch(() => ({}));
    if (data.code === 41006) throw new Error('分享链接不存在或已失效');
    if (data.code === 31001) throw new Error('此分享需要提取码，请在链接末尾加 ?pwd=密码');
    if (data.code === 31002) throw new Error('分享链接已失效或被取消');
    if (data.code === 41019) throw new Error('分享地址已过期（请向分享者索要新链接）');
    return data;
  };

  // 1) 拿 stoken
  const tokenRes = await ucRequest('POST',
    `/1/clouddrive/share/sharepage/token?entry=ft&fr=pc&pr=UCBrowser&__dt=${Date.now()}`,
    { pwd_id: shareId, passcode: passcode || '' });
  const stoken = tokenRes.data && tokenRes.data.stoken;
  if (!stoken) throw new Error('获取 UC 分享凭证失败，请检查分享链接与提取码');

  // 2) 列出分享内文件/文件夹（2026-08-19 用户拍板：解析阶段递归拿完整树，前端本地切层零请求）
  // 2026-08-20 14:58 修复：前端进入文件夹后调 fetch（凭证模式）传 pdir_fid+target_fid
  //   把 pdir_fid 传给 ucListTree（第四参数是起始父 ID）→ 只列子层而不是整树
  //   filter target_fid 避免转存整分享（只转存目标文件）
  // 2026-08-20 22:3x 修（UC 点发送久等）：prepare/fetch **复用 share 阶段缓存树**，
  //   之前每次重新整树递归（大分享几十秒）；缓存命中直接找目标文件
  const cacheKey = rawUrl || url || '';
  const cachedTree = resolveCacheGet('uc', cacheKey, 'root');
  let tree, allNodes;
  if (cachedTree && cachedTree.tree && Array.isArray(cachedTree.tree)) {
    tree = cachedTree.tree;
    allNodes = collectFileNodes(tree);
  } else {
    tree = await ucListTree(ucRequest, shareId, stoken, opts.pdir_fid || '', !opts.target_fid);
    allNodes = collectFileNodes(tree);
    if (opts.target_fid) {
      resolveCacheSet('uc', cacheKey, 'root', { tree, files: allNodes, stoken });
    }
  }
  let fileNodes = opts.target_fid ? allNodes.filter((f) => String(f.fid) === String(opts.target_fid)) : allNodes;
  // 2026-08-20 16:05 兜底：前端凭证模式可能未传 pdir_fid（或层级不对）→ 只列了子层/根层没有目标文件
  //   → 递归全树重找 target_fid（下载单个文件，多列几次 detail 无副作用；找到后替换 tree 供返回）
  if (!fileNodes.length && opts.target_fid) {
    try {
      const fullTree = await ucListTree(ucRequest, shareId, stoken, '', true);
      const fullNodes = collectFileNodes(fullTree);
      const hit = fullNodes.filter((f) => String(f.fid) === String(opts.target_fid));
      if (hit.length) { tree = fullTree; allNodes = fullNodes; fileNodes = hit; }
    } catch (e) {
      console.warn('[uc] 全树兜底失败:', String(e.message || e).slice(0, 100));
    }
  }
  if (!fileNodes.length && !tree.length) throw new Error('该分享没有可解析的文件（可能是空文件夹）');
  // 2026-08-20 15:05 兜底：前端进入文件夹后调 fetch 不带 fid_token（空字符串）→ 转存无 token 失败
  //   主动用 opts.stoken 调 detail 重拿 share_fid_token 填充
  if (fileNodes.length && opts.stoken && fileNodes.every((f) => !f.fid_token)) {
    try {
      const d2 = await ucRequest('GET',
        `/1/clouddrive/share/sharepage/detail?entry=ft&fr=pc&pr=UCBrowser&pwd_id=${shareId}` +
        `&stoken=${encodeURIComponent(opts.stoken)}&pdir_fid=${encodeURIComponent(opts.pdir_fid || '')}&_size=100&__dt=${Date.now()}`);
      const items = (d2.data && d2.data.list) || [];
      for (const f of fileNodes) {
        const m = items.find((x) => String(x.fid) === String(f.fid));
        if (m) f.fid_token = m.share_fid_token || m.fid_token || f.fid_token;
      }
    } catch (e) {
      console.warn('[uc] fid_token 兜底失败:', String(e.message || e).slice(0, 100));
    }
  }

  // 2.5) 解析阶段（listOnly）：只列文件、不取直链、不动 Cookie（用户 2026-08-19 需求）
  //     stoken/fid_token 仍返回（前端凭证模式下载需要，2026-08-19 修复）
  if (opts.listOnly) {
    return {
      tree,
      files: fileNodes.map((f) => ({ name: f.name, size: f.size, url: '', expiresAt: 0, needSave: true, fid_token: f.fid_token })),
      stoken,
    };
  }

  // 2026-08-20 22:2x 修（UC 点发送卡 30-60s）：prepare 只转存**目标文件**（opts.target_file），
  //   之前对分享所有文件整批转存（100 文件 → ucSave + ucPoll 轮询 60s）。
  const targetFile = opts.target_file ? String(opts.target_file) : '';
  let fids, tokens;
  if (targetFile) {
    const tf = fileNodes.find((f) => f.name === targetFile);
    fids = tf ? [tf.fid] : [];
    tokens = tf ? [tf.fid_token] : [];
  } else {
    fids = fileNodes.map((f) => f.fid);
    tokens = fileNodes.map((f) => f.fid_token);
  }

  // 3) 取直链：fetch 阶段（allowSave=true）**转存优先**（2026-08-19 与夸克对齐，参考 gopeed 系扩展）
  //    UC 直链 CDN 校验登录态，免转存 guest 直链下载必 403 → 先转存拿自己账号副本直链，
  //    转存失败（41017 自己的分享 / 容量不足）才回退免转存（尽力而为）
  let dlData = null;
  let savedFids = null;
  if (opts.allowSave) {
    // ===== fetch 阶段：转存优先 =====
    try {
      savedFids = await ucSave(ucRequest, fids, tokens, shareId, stoken, cookieRef);
      const dl = await ucRequest('POST',
        `${UC_DRIVE}/1/clouddrive/file/download?entry=ft&fr=pc&pr=UCBrowser`,
        { fids: savedFids });
      if (Array.isArray(dl.data) && dl.data.length) dlData = dl.data;
    } catch (saveErr) {
      // 2026-08-20 22:4x 修（UC 慢/不稳根因）：运营者 UC cookie 未登录（guest）→ 转存必 31001 require login
      //   → 游客免转存直链时好时坏（部分 403）→ 明确标注，让用户知道要填登录 Cookie
      const isLogin = /require login|31001|未登录|login/i.test(String(saveErr.message || saveErr) || '');
      try {
        const dl = await ucRequest('POST',
          `${UC_DRIVE}/1/clouddrive/file/download?entry=ft&fr=pc&pr=UCBrowser`,
          { fids, fid_token_list: tokens, stoken, pwd_id: shareId });
        if (Array.isArray(dl.data) && dl.data.length) {
          dlData = dl.data;
          if (isLogin) console.log('[uc] 转存不可用（UC 账号未登录），回退游客直链（可能 403/限速）');
        }
      } catch (e2) {
        throw new Error('获取 UC 直链失败：转存未成功（' + (saveErr.message || saveErr) + '），免转存回退也失败' + (isLogin ? '。UC 运营者账号未登录，请在后台配置已登录的 UC Cookie' : ''));
      }
    }
  } else {
    // ===== 解析阶段（listOnly / allowSave=false）：不取直链 =====
    try {
      const dl = await ucRequest('POST',
        `${UC_DRIVE}/1/clouddrive/file/download?entry=ft&fr=pc&pr=UCBrowser`,
        { fids, fid_token_list: tokens, stoken, pwd_id: shareId });
      if (Array.isArray(dl.data) && dl.data.length) dlData = dl.data;
    } catch (e) {
      // 解析阶段不转存：直链留空，点击下载时 fetch 再拿
    }
  }
  // 解析阶段免转存失败：返回空直链（列表可见，点击下载时 fetch 再拿）
  if (!dlData && !opts.allowSave) {
    return {
      tree,
      files: fileNodes.map((f) => ({ name: f.name, size: f.size, url: '', expiresAt: 0, needSave: true })),
    };
  }
  if (!dlData) throw new Error('获取 UC 直链失败（转存未成功，请重试）');

  // 4) 转存副本保留登记（不立即删除）：下载完成后由前端上报或 TTL 兜底清理
  //    2026-08-19 安全加固：副本达上限时立即删除刚转存的副本
  if (savedFids && savedFids.length) {
    if (!registerPendingSave('uc', shareId, 'all', savedFids, cookieRef.value)) {
      try {
        await fetchTimeout(`${UC_DRIVE}/1/clouddrive/file/delete?entry=ft&fr=pc&pr=UCBrowser`, {
          method: 'POST',
          headers: { 'User-Agent': 'Mozilla/5.0', 'Referer': 'https://drive.uc.cn/', 'Origin': 'https://drive.uc.cn', 'Content-Type': 'application/json', ...(cookieRef.value ? { Cookie: cookieRef.value } : {}) },
          body: JSON.stringify({ action_type: 2, filelist: savedFids, exclude_fids: [] }),
        });
      } catch {}
      throw new Error('转存副本已达上限，请稍后重试');
    }
  }

  // 5) 直链写回文件节点
  fileNodes.forEach((n, i) => {
    const d = dlData[i];
    if (d) { n.url = d.download_url; n.expiresAt = d.expires_at || null; }
  });
  return { tree, files: fileNodes.map((f) => ({ name: f.name, size: f.size, url: f.url, expiresAt: f.expiresAt })) };
}


// UC 转存（与夸克同构）
async function ucSave(ucRequest, fids, tokens, shareId, stoken, cookieRef) {
  const save = await ucRequest('POST',
    `/1/clouddrive/share/sharepage/save?entry=ft&fr=pc&pr=UCBrowser`,
    { fid_list: fids, fid_token_list: tokens, to_pdir_fid: '0', pwd_id: shareId, stoken, pdir_fid: '0', scene: 'link' });
  let savedFids = save.data && save.data.task_resp && save.data.task_resp.data && save.data.task_resp.data.save_as && save.data.task_resp.data.save_as.save_as_top_fids;
  if (!Array.isArray(savedFids) || savedFids.length === 0) {
    const taskId = save.data && save.data.task_id;
    if (!taskId) throw new Error('转存未返回任务，可能 Cookie 无转存权限');
    savedFids = await ucPoll(ucRequest, taskId);
  }
  return savedFids;
}

async function ucPoll(ucRequest, taskId) {
  for (let i = 0; i < 60; i++) {
    await new Promise((r) => setTimeout(r, 1000));
    const r = await ucRequest('GET',
      `/1/clouddrive/task?entry=ft&fr=pc&pr=UCBrowser&task_id=${taskId}&__dt=${Date.now()}`);
    const fids = (r.data && (r.data.save_as && r.data.save_as.save_as_top_fids || r.data.save_as && r.data.save_as.save_as_select_top_fids));
    if (Array.isArray(fids) && fids.length) return fids;
    if (r.data && r.data.status === 3) throw new Error('转存失败：网盘空间不足或风控');
  }
  throw new Error('转存超时');
}

// ---------- 123网盘（参考 gucheng910/gopeed-cloud-extensions：页面 shareInfo 直链）----------
// 链接格式：
//   https://www.123pan.com/s/{key}-{pwd}.html
//   https://{uid}.share.123pan.cn/123pan/{key}?pwd=xxx
// 说明：小文件（<100MB）页面 shareInfo 自带直链，免登录；大文件需 Cookie/token，返回明确提示

// ---------- 迅雷网盘（参考 gucheng910/gopeed-cloud-extensions：LinkSwift API）----------
// 链接：https://pan.xunlei.com/s/{shareId}（可带 ?pwd=）
// 分享接口：POST https://api-pan.xunlei.com/drive/v1/share（带 shorturl + passcode + X-Device-Id）
// ⚠️ 迅雷拿直链需要运营者账号凭证（device_id + Authorization）；解析阶段（listOnly）尝试免 Cookie 列文件

// ---------- 移动云盘（参考 gucheng910/gopeed-cloud-extensions：LinkSwift API）----------
// 链接：https://caiyun.139.com/m/i?{code} 或 ?shareCode={code}
// ⚠️ 移动云盘分享接口有风控：解析阶段（listOnly）免 Cookie 尝试列文件，若接口要求登录则提示配置 Cookie

// ---------- 其它网盘（演示占位，真实接入同理）----------
async function genericResolve(url, provider) {
  throw new Error(`「${provider}」的真实解析尚未接入。夸克/百度/UC/123/迅雷/移动 已可用。`);
}

// =====================================================================
//  每日任务（任务=奖励类型，完成方式=多个可选网盘的推广口令，后台可管理）
// =====================================================================
// 任务类型（reward_type 契约）：
//   unlock_small_file        → 解锁小文件流量机制（一次性）
//   unlock_large_file        → 解除单文件大小限制（一次性）
//   small_file_all_providers → 全部网盘小文件 +N GB
//   small_file_single_provider → 指定网盘小文件 +N GB（配合 reward_provider）
//   single_provider          → 指定网盘 +N 次（配合 reward_provider）
//   (默认)                   → 全部网盘 +N 次
// 每个任务可关联多个网盘（providers）作为「完成方式」——用户任选其一做推广口令任务，
// 做完任意一个即拿到该任务奖励。providers 为空则用「答案」完成（reveal-answer）。
// 任务位（用户 2026-08-15 确认的完整清单）：
//   通用 3 个：小文件解锁 / 大文件解锁 / 追加小文件额度
//   网盘 6 个：夸克/百度/UC/迅雷/123/移动 发送到下载器解锁（各配一个密码任务）
// 每个任务位都在后台任务管理界面独立展示、独立配置（奖励/完成网盘/启用开关）
const TASK_SLOT_META = {
  small_unlock:  { type: 'password', icon: '📦', slot: 'small_unlock',   category: '小文件',   title: '解锁小文件解析',       description: '完成任一网盘口令任务，解锁小体积文件（≤200MB）解析与下载', reward_type: 'unlock_small_file', reward_count: 0 },
  large_unlock:  { type: 'password', icon: '📊', slot: 'large_unlock',   category: '大文件',   title: '解除大文件大小限制',   description: '完成任一网盘口令任务，解锁超过 2GB 文件的下载权限', reward_type: 'unlock_large_file', reward_count: 0 },
  small_bonus:   { type: 'password', icon: '🎁', slot: 'small_bonus',    category: '小文件',   title: '追加 1GB 小文件流量',   description: '完成任一网盘口令任务，追加 1GB 小文件下载流量（每台设备每日仅可完成一次）', reward_type: 'small_file_all_providers', reward_count: 1024 },
  dl_quark:      { type: 'password', icon: '🔐', slot: 'dl_quark',       category: '网盘解锁', title: '夸克发送到下载器解锁', description: '完成夸克口令任务，解锁夸克直链发送到下载器', reward_type: 'unlock_downloader', reward_count: 0, reward_provider: 'quark' },
  dl_baidu:      { type: 'password', icon: '🔐', slot: 'dl_baidu',       category: '网盘解锁', title: '百度发送到下载器解锁', description: '完成百度口令任务，解锁百度直链发送到下载器', reward_type: 'unlock_downloader', reward_count: 0, reward_provider: 'baidu' },
  dl_uc:         { type: 'password', icon: '🔐', slot: 'dl_uc',          category: '网盘解锁', title: 'UC发送到下载器解锁',    description: '完成UC口令任务，解锁UC直链发送到下载器', reward_type: 'unlock_downloader', reward_count: 0, reward_provider: 'uc' },
  dl_xunlei:     { type: 'password', icon: '🔐', slot: 'dl_xunlei',      category: '网盘解锁', title: '迅雷发送到下载器解锁',  description: '完成迅雷口令任务，解锁迅雷直链发送到下载器', reward_type: 'unlock_downloader', reward_count: 0, reward_provider: 'xunlei' },
  dl_pan123:     { type: 'password', icon: '🔐', slot: 'dl_pan123',      category: '网盘解锁', title: '123盘发送到下载器解锁', description: '完成123盘口令任务，解锁123盘直链发送到下载器', reward_type: 'unlock_downloader', reward_count: 0, reward_provider: 'pan123' },
  dl_mcloud:     { type: 'password', icon: '🔐', slot: 'dl_mcloud',      category: '网盘解锁', title: '移动云盘发送到下载器解锁', description: '完成移动云盘口令任务，解锁移动云盘直链发送到下载器', reward_type: 'unlock_downloader', reward_count: 0, reward_provider: 'mcloud' },
};
// 默认完成方式：每类任务预设的可选网盘（管理员可改）
const TASK_SLOT_DEFAULT_PROVIDERS = {
  small_unlock: ['quark', 'baidu', 'uc', 'pan123'],
  large_unlock: ['baidu', 'xunlei', 'uc'],
  small_bonus:  ['quark', 'baidu', 'pan123'],
  dl_quark:     ['quark'], dl_baidu: ['baidu'], dl_uc: ['uc'], dl_xunlei: ['xunlei'], dl_pan123: ['pan123'], dl_mcloud: ['mcloud'],
};
// 兜底：每日签到（答案任务，不属于网盘密码任务，但保留在任务列表供领次数）
// 兜底默认任务（仅首次启动无 tasks.json 时使用；之后任务完全由管理员在后台制定、增删改）
// 注意：不预置任何签到/答案任务 —— 所有任务都需管理员在后台创建（用户 2026-08-15 确认）
const DEFAULT_TASKS = [
  ...Object.entries(TASK_SLOT_META).map(([id, m]) => ({
    id, type: m.type, icon: m.icon, title: m.title, description: m.description,
    reward_type: m.reward_type, reward_count: m.reward_count,
    reward_provider: m.reward_provider || '', providers: [...(TASK_SLOT_DEFAULT_PROVIDERS[id] || [])], answer: '', enabled: true,
    slot: m.slot || id, category: m.category || '其它',
  })),
];
// 运行时可被管理员增删改（持久化用 JSON 文件）
const TASKS_FILE = path.join(__dirname, '..', 'data', 'tasks.json');

function loadTasks() {
  // 首次启动（无 tasks.json）→ 用默认 9 任务位；之后 tasks.json 完全由管理员掌控（增删改，不强制重建骨架）
  try {
    if (fs.existsSync(TASKS_FILE)) {
      const arr = JSON.parse(fs.readFileSync(TASKS_FILE, 'utf8'));
      if (Array.isArray(arr)) return arr;
    }
  } catch {}
  return JSON.parse(JSON.stringify(DEFAULT_TASKS));
}
let dailyTasks = loadTasks();
function saveTasks() {
  try {
    fs.mkdirSync(path.dirname(TASKS_FILE), { recursive: true });
    fs.writeFileSync(TASKS_FILE, JSON.stringify(dailyTasks, null, 2));
  } catch {}
}

// 按契约渲染奖励文本
function rewardTextOf(task) {
  const t = task.reward_type || 'default';
  const n = Math.max(1, Number(task.reward_count) || 1);
  if (t === 'unlock_small_file') return '解锁小文件流量机制';
  if (t === 'unlock_large_file') return '解除单文件大小限制';
  if (t === 'unlock_downloader') return `${PROVIDER_NAME[task.reward_provider] || task.reward_provider || '指定网盘'} 发送到下载器解锁`;
  if (t === 'small_file_single_provider') return `${task.reward_provider || '指定网盘'} 小文件 +${n} GB`;
  if (t === 'small_file_all_providers') return `全部网盘小文件 +${n} MB`;
  if (t === 'single_provider') return `${task.reward_provider || '指定网盘'} +${n} 次`;
  return `全部网盘 +${n} 次`;
}

// 应用任务奖励（对齐 reward_type + 双轨额度）
function applyReward(q, task) {
  const t = task.reward_type || 'default';
  const n = Number(task.reward_count) || 0;
  if (t === 'unlock_small_file') {
    // 解锁小文件机制：可解析/下载小文件 + 追加小文件字节额度
    q.smallFileUnlocked = true;
    q.smallSizeLeft += Math.max(n, siteSettings.smallRewardMB) * MB;
  } else if (t === 'unlock_large_file') {
    // 解除单文件大小限制：解锁 >2GB 大文件权限（个数与大文件 count 池相通）
    q.sizeCapUnlocked = true;
  } else if (t === 'unlock_downloader') {
    // 解锁「指定网盘发送到下载器」（用户 2026-08-15 确认：6 网盘各配一个密码任务）
    const prov = task.reward_provider || task.provider || '';
    if (!q.downloaderUnlocked) q.downloaderUnlocked = {};
    if (prov) q.downloaderUnlocked[prov] = true;
  } else if (t === 'small_file_all_providers' || t === 'small_file_single_provider') {
    // 小文件流量任务：解锁 + 追加字节额度（默认 +1GB/次，可多次做累计，但每任务每日一次）
    q.smallFileUnlocked = true;
    q.smallSizeLeft += Math.max(n, siteSettings.smallRewardMB) * MB;
  } else {
    // 次数任务：大文件 count 池追加
    q.largeCountLeft += Math.max(1, n);
  }
}

// =====================================================================
//  路由
// =====================================================================
// 解析核心（供 /api/parse 与 /api/search/reveal-links 共用）
// 用运营者自己的会员账号 Cookie（管理员后台配置），用户侧不传 Cookie
// opts.allowSave：是否允许「转存到运营者网盘拿直链」。
//   - share/detail（解析列表阶段）：false —— 只列文件 + 免转存直链，失败不转存（转存后移）
//   - fetch（用户点击发送下载器阶段）：true —— 此时才转存，且转存副本保留登记，下载完成后删除
// 转存时机构想（用户 2026-08-15 提出）：解析不转存 → 点下载才转存 → 下载完删除（TTL 兜底）
// =====================================================================
//  解析结果缓存（2026-08-19 用户反馈：点击进入文件夹卡顿）
//  每次 share/detail 都实时请求网盘 API（夸克实测 2.8~3.3s），无缓存时
//  返回上一级/再进同一文件夹全部重新拉。加内存缓存（TTL 5 分钟）：
//  第一次 3s，之后毫秒级返回，显著消除点击文件夹卡顿。
//  仅缓存「列表」（share/detail 结果），不缓存直链（直链有时效，必须实时）。
// =====================================================================
const RESOLVE_CACHE_TTL = 5 * 60 * 1000; // 5 分钟
const resolveCache = new Map(); // key: `${provider}:${pwdId}:${layerKey}` → { tree, files, stoken, ts }

function resolveCacheGet(provider, pwdId, layerKey) {
  const k = `${provider}:${pwdId}:${layerKey}`;
  const hit = resolveCache.get(k);
  if (!hit) return null;
  if (Date.now() - hit.ts > RESOLVE_CACHE_TTL) { resolveCache.delete(k); return null; }
  return hit;
}
function resolveCacheSet(provider, pwdId, layerKey, data) {
  const k = `${provider}:${pwdId}:${layerKey}`;
  resolveCache.set(k, { ...data, ts: Date.now() });
}
// 定时清理过期缓存（防内存膨胀）
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of resolveCache) if (now - v.ts > RESOLVE_CACHE_TTL) resolveCache.delete(k);
}, 60 * 1000);

// 2026-08-19 性能优化：后台预取夸克分享某层下所有子文件夹的列表进缓存
// 用户点「进入文件夹」时 detail 缓存已命中 → 秒开（消除卡顿）。
// 不阻塞响应（fire-and-forget），失败静默忽略；已缓存/无子文件夹则跳过。
async function prefetchQuarkLayers(cookieRef, pwdId, stoken, tree) {
  try {
    const folders = (tree || []).filter((n) => n.type === 'folder' && n.fid);
    if (!folders.length) return;
    for (const f of folders) {
      const layerKey = 'layer:' + f.fid;
      if (resolveCacheGet('quark', pwdId, layerKey)) continue; // 已缓存
      try {
        const sub = await quarkListTree(cookieRef, pwdId, stoken, f.fid, false);
        const subFiles = collectFileNodes(sub);
        resolveCacheSet('quark', pwdId, layerKey, { tree: sub, files: subFiles, stoken });
      } catch {}
    }
  } catch {}
}

// 2026-08-19 性能优化：后台预取 UC 分享某层下所有子文件夹的列表进缓存（fire-and-forget）
async function prefetchUcLayers(ucRequest, shareId, stoken, tree) {
  try {
    const folders = (tree || []).filter((n) => n.type === 'folder' && n.fid);
    if (!folders.length) return;
    for (const f of folders) {
      const layerKey = 'layer:' + f.fid;
      if (resolveCacheGet('uc', shareId, layerKey)) continue;
      try {
        const sub = await ucListTree(ucRequest, shareId, stoken, f.fid, false);
        const subFiles = collectFileNodes(sub);
        resolveCacheSet('uc', shareId, layerKey, { tree: sub, files: subFiles, stoken });
      } catch {}
    }
  } catch {}
}

// 2026-08-19：123盘 登录状态（保存/定时/重登时更新，供后台回显，不含敏感值）
let pan123LoginState = { ok: null, error: '', ts: 0 };
let pan123TokenState = { ok: null, msg: '' };
// 2026-08-19：token 有效性缓存（每 5 分钟最多 check 一次）
let pan123TokenCache = { ok: null, prefix: '', len: 0, checkedAt: 0, error: '' };
async function refreshPan123TokenCache(force = false) {
  const ck = siteSettings.cookies && siteSettings.cookies.pan123 || '';
  const tk = extractToken(ck);
  if (!tk) { pan123TokenCache = { ok: null, prefix: '', len: 0, checkedAt: Date.now(), error: '' }; return; }
  const now = Date.now();
  if (!force && now - pan123TokenCache.checkedAt < 5 * 60 * 1000 && pan123TokenCache.prefix) return;
  try {
    const ok = await pan123CheckToken(tk);
    pan123TokenCache = { ok, prefix: tk.slice(0, 8), len: tk.length, checkedAt: now, error: ok ? '' : 'token 失效' };
  } catch (e) {
    pan123TokenCache = { ok: false, prefix: tk.slice(0, 8), len: tk.length, checkedAt: now, error: '检查异常: ' + e.message };
  }
}

const pendingSaves = new Map(); // key: `${provider}:${shareId}:${fileName}` → {provider, savedFids, cookie, ts}

// 2026-08-19 安全加固：转存副本并发上限（防恶意刷转存占满运营者网盘）
// 含义：同一时刻「待清理的转存副本」最多 N 个（正常用户下载完即删，远用不完；仅防恶意堆积）
// 超限：registerPendingSave 返回 false → 调用方立即删除刚转存的副本，避免泄漏
const MAX_PENDING_SAVES = 100;

// 转存登记：fetch 阶段转存成功后调用，登记副本供下载完成后删除
// 返回 true=已登记 / false=副本已达上限（调用方应尽快删掉刚转存的副本）
function registerPendingSave(provider, shareId, fileName, savedFids, cookie) {
  if (!Array.isArray(savedFids) || !savedFids.length) return true;
  // 先清掉过期记录（防 Map 里堆满失效项导致误判超限）
  const now = Date.now();
  for (const [k, rec] of pendingSaves) {
    if (now - rec.ts > SAVE_TTL || rec.ts === undefined) pendingSaves.delete(k);
  }
  if (pendingSaves.size >= MAX_PENDING_SAVES) return false;
  const key = `${provider}:${shareId}:${fileName}`;
  pendingSaves.set(key, { provider, shareId, fileName, savedFids, cookie, ts: Date.now() });
  console.log(`[pending-save] register key=${key} fids=${JSON.stringify(savedFids)}`);
  return true;
}

// 下载完成上报：前端下载器任务完成后调用 → 立即删除对应转存副本
// ============ 转存副本删除实现（2026-08-20 15:53 补全：百度/迅雷/123 之前只登记不删 → 网盘被塞满）============
// 百度：filemanager opera=delete（bdstoken 动态获取）；savedFids 存的是转存后的 to_path（/文件名）
async function baiduDelete(paths, cookie) {
  if (!Array.isArray(paths) || !paths.length) return;
  const CK = buildBaiduCookie(cookie || '');
  const h = { 'User-Agent': 'netdisk;11.4.51.4.19', 'Referer': 'https://pan.baidu.com/', 'Cookie': CK };
  let bd = '';
  try {
    const r = await fetchTimeout('https://pan.baidu.com/api/gettemplatevariable?fields=%5B%22bdstoken%22%5D', { headers: h });
    const j = await r.json().catch(() => ({}));
    bd = (j.result && j.result.bdstoken) || '';
  } catch {}
  await fetchTimeout('https://pan.baidu.com/api/filemanager?async=2&opera=delete&onnest=fail&channel=chunlei&web=1&app_id=250528&bdstoken=' + encodeURIComponent(bd) + '&clienttype=0', {
    method: 'POST',
    headers: { ...h, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'filelist=' + encodeURIComponent(JSON.stringify(paths)),
  });
}

// 迅雷：DELETE /drive/v1/files/{id}（复用 xunlei_download.py --delete：JWT + captcha 都在脚本里）
function xunleiDelete(fileIds) {
  if (!Array.isArray(fileIds) || !fileIds.length) return Promise.resolve();
  const py = process.env.XUNLEI_PYTHON || '/home/ubuntu/pwand-playwright/venv/bin/python';
  const py2 = process.env.XUNLEI_DL_PY || '/home/ubuntu/pwand-playwright/xunlei_download.py';
  return new Promise((resolve) => {
    execFile(py, [py2, '--delete', String(fileIds[0])], { timeout: 30000, maxBuffer: 2 * 1024 * 1024 }, (err, stdout, stderr) => {
      console.log(`[xunlei-delete] id=${fileIds[0]} err=${err ? err.message : 'null'} out=${String(stdout).slice(0, 120)} err2=${String(stderr).slice(0, 120)}`);
      resolve();
    });
  });
}

// 123：POST /b/api/file/trash（AList 123 driver 同款：operation:true + fileTrashInfoList）
// 2026-08-20 21:45 修（123 副本堆积真凶）：旧实现 /b/api/file/delete + fileIds 返回 7301「已删除」是**假成功**
//   （实测文件根本没删，验证：删除后秒传 FileId 不变）→ 后删除一直失效 → 123 盘被转存副本塞满。
//   正确接口 = /b/api/file/trash，body {driveId:0, operation:true, fileTrashInfoList:[{FileId}]}
async function pan123Delete(fileIds, cookie) {
  if (!Array.isArray(fileIds) || !fileIds.length) return;
  const tk = String(cookie || '').replace(/^token=/, '').trim();
  if (!tk) return;
  const sign = pan123Sign('/b/api/file/trash', 'alist');
  const qs = new URLSearchParams(sign).toString();
  await fetchTimeout(`https://yun.123pan.com/b/api/file/trash?${qs}`, {
    method: 'POST',
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
      'Origin': 'https://yun.123pan.com', 'Referer': 'https://yun.123pan.com/',
      'platform': 'web', 'app-version': '3', 'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + tk,
    },
    body: JSON.stringify({
      driveId: 0,
      operation: true,
      fileTrashInfoList: fileIds.map((id) => ({ FileId: Number(id) })),
    }),
  });
}

async function cleanupSave(provider, shareId, fileName) {
  const key = `${provider}:${shareId}:${fileName}`;
  const rec = pendingSaves.get(key);
  if (!rec) {
    console.log(`[cleanup-save] NOT FOUND key=${key} pendingSize=${pendingSaves.size}`);
    return { found: false };
  }
  pendingSaves.delete(key);
  console.log(`[cleanup-save] FOUND key=${key} fids=${JSON.stringify(rec.savedFids)} provider=${provider}`);
  try {
    if (provider === 'quark') {
      const cookieRef = { value: rec.cookie };
      await quarkDelete(rec.savedFids, cookieRef);
    } else if (provider === 'uc') {
      const headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120 Safari/537.36',
        'Referer': 'https://drive.uc.cn/', 'Origin': 'https://drive.uc.cn', 'Content-Type': 'application/json',
      };
      if (rec.cookie) headers.Cookie = rec.cookie;
      await fetchTimeout(`${UC_DRIVE}/1/clouddrive/file/delete?entry=ft&fr=pc&pr=UCBrowser`, {
        method: 'POST', headers, body: JSON.stringify({ action_type: 2, filelist: rec.savedFids, exclude_fids: [] }),
      });
    } else if (provider === 'baidu') {
      await baiduDelete(rec.savedFids, rec.cookie);
    } else if (provider === 'xunlei') {
      await xunleiDelete(rec.savedFids);
    } else if (provider === 'pan123') {
      await pan123Delete(rec.savedFids, rec.cookie);
    }
    return { found: true, ok: true };
  } catch (e) {
    return { found: true, ok: false, error: e.message };
  }
}

// 按 provider + file_name 匹配清理转存副本（2026-08-19 用户需求：点发送到下载器 → 转存 → 发直链 → 删副本）
// 前端 /api/downloader-push-log 上报时顺带调用；找不到精确匹配则回退清理该 provider 下最早登记的副本
async function cleanupSaveByFileName(provider, fileName) {
  if (!provider || !fileName) return { found: false };
  // 1) 精确匹配：key = `${provider}:${shareId}:${fileName}`
  for (const [key, rec] of pendingSaves) {
    if (rec.provider === provider && (rec.fileName === fileName || rec.fileName === 'all')) {
      return cleanupSave(provider, key.split(':')[1], rec.fileName);
    }
  }
  // 2) 文件名模糊匹配（文件名可能带扩展名差异）
  const base = String(fileName).replace(/\.[^/.]+$/, '').toLowerCase();
  for (const [key, rec] of pendingSaves) {
    if (rec.provider === provider && String(rec.fileName || '').toLowerCase().includes(base)) {
      return cleanupSave(provider, key.split(':')[1], rec.fileName);
    }
  }
  return { found: false };
}

// TTL 兜底清理：转存副本默认保留 6 小时（超过直链有效期 + 用户下载窗口），超时自动删除
const SAVE_TTL = 6 * 3600 * 1000;
function sweepPendingSaves() {
  const now = Date.now();
  for (const [key, rec] of pendingSaves) {
    if (now - rec.ts > SAVE_TTL) {
      pendingSaves.delete(key);
      const cookieRef = { value: rec.cookie };
      if (rec.provider === 'quark') quarkDelete(rec.savedFids, cookieRef).catch(() => {});
      else if (rec.provider === 'uc') {
        const headers = { 'User-Agent': 'Mozilla/5.0', 'Referer': 'https://drive.uc.cn/', 'Content-Type': 'application/json' };
        if (rec.cookie) headers.Cookie = rec.cookie;
        fetch(`${UC_DRIVE}/1/clouddrive/file/delete?entry=ft&fr=pc&pr=UCBrowser`, {
          method: 'POST', headers, body: JSON.stringify({ action_type: 2, filelist: rec.savedFids, exclude_fids: [] }),
        }).catch(() => {});
      } else if (rec.provider === 'baidu') baiduDelete(rec.savedFids, rec.cookie).catch(() => {});
      else if (rec.provider === 'xunlei') xunleiDelete(rec.savedFids).catch(() => {});
      else if (rec.provider === 'pan123') pan123Delete(rec.savedFids, rec.cookie).catch(() => {});
      pushAdminLog('save_sweep', `TTL 清理转存副本: ${key}`);
    }
  }
}
setInterval(sweepPendingSaves, 30 * 60 * 1000);

// 2026-08-19：123盘 token 定时保鲜（每 6 小时检查一次，失效自动重登——账号密码登录的意义）
setInterval(async () => {
  try {
    const acc = siteSettings.pan123Account;
    const ck = siteSettings.cookies && siteSettings.cookies.pan123;
    if (!acc || !acc.username || !acc.password || !ck) return;
    const tk = extractToken(ck);
    if (!tk) return;
    // 2026-08-19 升级：refresh_token 优先（绕开 sign_in 验证码风控，纯自动续期）
    let renewed = null;
    if (tk) renewed = await pan123RefreshToken(tk);  // 直接用现有 token 换新 token
    if (!renewed && !tk) {
      // 无 token 时用账号密码登录（仅当 sign_in 未被风控时可用）
      if (acc.username && acc.password) {
        try { renewed = await pan123SignIn(acc.username, acc.password); } catch {}
      }
    }
    if (renewed) {
      siteSettings.cookies.pan123 = 'token=' + renewed;
      saveSettings();
      pan123LoginState = { ok: true, error: '', ts: Date.now() };
      pushAdminLog('pan123_login', '123盘 token 自动续期成功（refresh_token）');
    } else if (tk) {
      // refresh 失败但旧 token 可能仍有效
      const ok = await pan123CheckToken(tk);
      pan123LoginState = ok ? { ok: true, error: '', ts: Date.now() } : { ok: false, error: '续期失败且 token 失效', ts: Date.now() };
      pushAdminLog('pan123_login', ok ? '123盘 token 仍有效（refresh 未返回新 token）' : '123盘 token 续期失败');
    }
    await refreshPan123TokenCache(true);
  } catch {}
}, 6 * 60 * 60 * 1000);

// =====================================================================
//  今日密码自动程序（用户 2026-08-15 澄清的模型）
//  网盘密码与任务分开：6 个网盘每天各生成一个独立密码，分享到各网盘「(日期)今日密码」文件夹
//  任务绑定某个网盘的密码任务（task_provider，管理员后台指定）→ 该任务验证密码 = 该网盘今日密码
//  管理员不自己生成密码（防扰乱自动化）——密码全部由本程序每日 00:00 自动生成
// =====================================================================
let _dailyPwdRunning = false;
// 各网盘密码生成器（quark 实测成功 2026-08-16；mcloud/xunlei 协议就绪；uc 2026-08-21 复用夸克链路实测成功）
const DAILY_PWD_GENERATORS = {
  quark: quarkRunDaily,
  mcloud: mcloudRunDaily,
  xunlei: xunleiRunDaily,
  uc: ucRunDaily,
};
async function runDailyPasswordJob() {
  if (_dailyPwdRunning) return { skipped: [{ reason: '已有任务在运行' }], generated: [] };
  // 检查当天是否已生成（跨天/重启容错）。核心规则（用户 2026-08-16 强调）：
  //   已成功（state.status==='ok'）的网盘【绝不重新生成】——防止误触删掉已发出去的分享；
  //   只有「未生成」或「生成失败」的网盘才会被补跑/重试。
  const all = loadDailyPasswords();
  const today = dateStrCN();
  const needProviders = [];
  const skipped = [];
  for (const p of Object.keys(DAILY_PWD_GENERATORS)) {
    // 只在后台勾选「启动每日自动化」（promo[p].auto_daily）且配置了 Cookie 的网盘上生成
    const promo = siteSettings.promo[p] || {};
    if (promo.auto_daily !== true) {
      skipped.push({ provider: p, reason: 'auto_daily 未勾选' });
      continue;
    }
    const ck = siteSettings.cookies[p] || '';
    if (!ck) {
      pushAdminLog('daily_pwd', `${PROVIDER_NAME[p] || p} 已勾选自动化但未配置 Cookie，跳过`);
      skipped.push({ provider: p, reason: '未配置 Cookie' });
      continue;
    }
    // 当天已成功 → 跳过（幂等 + 防误触）
    const state = all && all.state && all.state[p];
    if (state && state.status === 'ok') {
      skipped.push({
        provider: p,
        reason: '今日已生成成功，幂等沿用（不会重复上传/不会因重试而作废）',
        code: all.codes[p],
        share_url: all.shares && all.shares[p],
      });
      continue;
    }
    needProviders.push(p);
  }
  if (!needProviders.length) {
    pushAdminLog('daily_pwd', '今日密码无需生成（全部已存在或无启用项）');
    return { skipped, generated: [] };
  } // 今天全部已生成或没有启用自动化的网盘
  _dailyPwdRunning = true;
  const generated = [];
  try {
    for (const p of needProviders) {
      const ck = siteSettings.cookies[p] || '';
      const gen = DAILY_PWD_GENERATORS[p];
      if (!ck || !gen) continue;
      try {
        // 2026-08-19：迅雷生成器需要 x-captcha-token（验证码 token，6-24h 有效期）+ Bearer access_token；其他网盘忽略
        const r = p === 'xunlei'
          ? await gen(ck, siteSettings.xunleiCaptchaToken || '', siteSettings.xunleiAccessToken || '')
          : await gen(ck);
        pushAdminLog('daily_pwd', `${PROVIDER_NAME[p] || p} 今日密码已生成并分享：${r.share_url}（密码 ${r.code}）`);
        console.log('[daily-pwd]', p, r.share_url, r.code);
        generated.push({ provider: p, code: r.code, share_url: r.share_url, ok: true });
      } catch (e) {
        pushAdminLog('daily_pwd_err', `${p} 今日密码生成失败: ${e.message}`);
        console.log('[daily-pwd]', p, '失败:', e.message);
        // 记录失败状态（前端据此显示红色失败提醒；下次补跑仍会重试此网盘）
        saveTodayPassword({ provider: p, status: 'error', error: String(e.message || e).slice(0, 300) });
        generated.push({ provider: p, ok: false, error: e.message });
      }
    }
  } finally {
    _dailyPwdRunning = false;
  }
  return { generated, skipped };
}
// 零点定时：每小时检查一次，到 00:00-00:10 区间且当天未生成则执行（跨天容错）
setInterval(() => {
  const now = new Date();
  if (now.getHours() === 0 && now.getMinutes() < 10) runDailyPasswordJob();
}, 60 * 1000);
// 启动时若当天未生成，延迟 30 秒补一次（服务可能在零点后重启）
setTimeout(runDailyPasswordJob, 30 * 1000);

// ============ 迅雷 JWT 定时刷新（2026-08-20 用户要求：不手动导，服务器自续期）============
// 策略：解析 JWT exp → 剩余 <2h 时尝试 xunlei_page.py --refresh-creds（浏览器页面用 refresh_token 续期）
//   → 成功写回 settings + jwt 缓存；失败 → 后台告警（提醒手动更新），不再默默过期
function xunleiJwtExp(jwt) {
  try {
    const p = String(jwt || '').split('.')[1];
    if (!p) return 0;
    const d = JSON.parse(Buffer.from(p, 'base64url').toString('utf8'));
    return d.exp ? d.exp * 1000 : 0;
  } catch { return 0; }
}
async function refreshXunleiJwtJob(reason = '定时') {
  const jwt = siteSettings.xunleiAccessToken || '';
  const rt = siteSettings.xunleiRefreshToken || '';
  if (!jwt || !rt) return;
  const exp = xunleiJwtExp(jwt);
  if (exp && exp - Date.now() > 2 * 3600 * 1000) return; // 剩余 >2h 不刷
  console.log(`[xunlei-jwt] ${reason}: 剩余 ${exp ? Math.round((exp - Date.now()) / 60000) + 'min' : '未知'}，尝试刷新`);
  try {
    // 2026-08-20 23:5x 纯 API 刷新（逆向自页面 JS AUTH_TOKEN_URL=/v1/auth/token）：不需要 client_secret！
    const r = await fetchTimeout('https://xluser-ssl.xunlei.com/v1/auth/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/108', Accept: 'application/json' },
      body: JSON.stringify({ client_id: 'Xqp0kJBXWhwaTpB6', grant_type: 'refresh_token', refresh_token: rt }),
    });
    const j = await r.json().catch(() => ({}));
    if (j.access_token && String(j.access_token).length > 200) {
      try {
        require('fs').writeFileSync('/home/ubuntu/pwand-playwright/xunlei_jwt_cache.json', JSON.stringify({ jwt: j.access_token, ts: Math.floor(Date.now() / 1000) }, null, 2));
      } catch {}
      siteSettings.xunleiAccessToken = j.access_token;
      if (j.refresh_token) siteSettings.xunleiRefreshToken = j.refresh_token; // 迅雷可能轮换 refresh_token
      try { saveSettings(); } catch {}
      pushAdminLog('xunlei_jwt', '迅雷 JWT 已自动刷新（纯 API）');
      console.log('[xunlei-jwt] refresh: OK (纯 API)');
    } else {
      pushAdminLog('xunlei_jwt', `迅雷 JWT 刷新失败（${reason}）：${String(j.error_description || j.error || JSON.stringify(j)).slice(0, 120)}`);
      console.log('[xunlei-jwt] refresh: FAIL', String(j.error_description || j.error || '').slice(0, 100));
    }
  } catch (e) {
    pushAdminLog('xunlei_jwt', '迅雷 JWT 刷新异常: ' + String(e.message || e).slice(0, 120));
  }
}
setInterval(() => refreshXunleiJwtJob('定时'), 30 * 60 * 1000);
setTimeout(() => refreshXunleiJwtJob('启动'), 90 * 1000);

// ============ UC __puus 自动续期（2026-08-21：__puus 约 3 小时有效，AList 机制持久化）============
// AList 证实：发一个「不带 __puus」的请求 → 服务端 Set-Cookie 重发新 __puus →
// 每 2 小时刷新一次（早于 3 小时过期），UC 登录态永不失效
async function refreshUcPuusJob(reason = '定时') {
  const ck = siteSettings.cookies.uc || '';
  if (!ck) return;
  const stripped = ck.split(';').map((s) => s.trim()).filter((s) => s && !s.startsWith('__puus=')).join('; ');
  try {
    const resp = await fetchTimeout('https://pc-api.uc.cn/1/clouddrive/file/sort?pr=UCBrowser&fr=pc&pdir_fid=0&_page=1&_size=1&uc_param_str=', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120',
        'Referer': 'https://drive.uc.cn/', 'Origin': 'https://drive.uc.cn',
        'Cookie': stripped, 'Accept': 'application/json, text/plain, */*',
      },
    });
    const setCookies = typeof resp.headers.getSetCookie === 'function' ? resp.headers.getSetCookie() : [];
    let newPuus = '';
    for (const sc of setCookies) {
      if (sc && sc.startsWith('__puus=')) { newPuus = sc.split(';')[0]; break; }
    }
    if (newPuus) {
      const parts = ck.split(';').map((s) => s.trim()).filter((s) => s);
      const idx = parts.findIndex((p) => p.startsWith('__puus='));
      if (idx >= 0) parts[idx] = newPuus; else parts.push(newPuus);
      siteSettings.cookies.uc = parts.join('; ');
      try { saveSettings(); } catch {}
      console.log(`[uc-puus] ${reason}: 已续期`);
    } else {
      console.log(`[uc-puus] ${reason}: 未拿到新 __puus`);
    }
  } catch (e) {
    console.log('[uc-puus] 刷新失败:', String(e.message || e).slice(0, 80));
  }
}
setInterval(() => refreshUcPuusJob('定时'), 2 * 3600 * 1000);
setTimeout(() => refreshUcPuusJob('启动'), 60 * 1000);

// ---- Cookie 有效性检测（2026-08-16 用户要求）----
// 每日 01:25-01:35 检测一次各网盘 Cookie；失效 → 后台日志告警 + 可选 webhook（环境变量 ALERT_WEBHOOK）
async function alertCookieIssue(provider, name, status, detail) {
  pushAdminLog('cookie_warn', `${name} Cookie ${status === 'invalid' ? '已失效' : '异常'}: ${detail}`);
  const webhook = process.env.ALERT_WEBHOOK || '';
  if (!webhook) return;
  try {
    await fetchTimeout(webhook, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'cookie_alert', provider, name, status, detail, ts: Date.now() }),
    });
  } catch (e) {
    console.log('[cookie-alert] webhook 发送失败:', e.message);
  }
}
async function runCookieCheck(reason = '定时') {
  try {
    const results = await checkAllCookies(siteSettings, PROVIDERS);
    for (const r of results) {
      console.log(`[cookie-check] ${r.name}: ${r.status}${r.detail ? '（' + r.detail + '）' : ''}`);
      if (r.status === 'invalid') await alertCookieIssue(r.provider, r.name, r.status, r.detail);
    }
    const bad = results.filter((r) => r.status === 'invalid' || r.status === 'error');
    if (results.length) {
      pushAdminLog(
        'cookie_check',
        bad.length
          ? `${reason}检测：${results.length} 个网盘，异常 ${bad.length} 个（${bad.map((b) => b.name + ':' + b.status).join('、')}）`
          : `${reason}检测：${results.length} 个网盘 Cookie 全部有效`
      );
    }
  } catch (e) {
    pushAdminLog('cookie_check', `检测异常: ${e.message}`);
  }
}
let _cookieCheckDate = '';
setInterval(() => {
  const now = new Date();
  const today = `${now.getFullYear()}-${now.getMonth() + 1}-${now.getDate()}`;
  if (now.getHours() === 1 && now.getMinutes() >= 25 && now.getMinutes() < 35 && _cookieCheckDate !== today) {
    _cookieCheckDate = today;
    runCookieCheck('每日');
  }
}, 60 * 1000);
// 启动后 60 秒先跑一次（快速反馈当前 Cookie 状态）
setTimeout(() => runCookieCheck('启动'), 60 * 1000);

async function resolveProvider(provider, url, opts = {}) {
  // 未接入的网盘：清晰提示（前端仍可见，但标注「即将支持」）
  if (!SUPPORTED_PROVIDERS.includes(provider)) {
    const e = new Error(`「${PROVIDER_NAME[provider] || provider}」真实解析尚未接入，敬请期待`);
    e.code = 4; throw e;
  }
  // 用户 2026-08-19 需求：解析阶段（share/detail）不调用 Cookie，只用公开接口列文件；
  // 只有「输入密码 → 点击发送到下载器」（fetch / allowSave=true）才动用一次 Cookie。
  // listOnly=true（share/detail）→ 不读、不校验、不传 Cookie，直链留空；
  // listOnly=false（fetch）→ 才读运营者 Cookie 并校验（未配置则明确报错）。
  const listOnly = opts.listOnly === true;
  let cookie = '';
  if (!listOnly) {
    cookie = siteSettings.cookies[provider];
    // 123 盘小文件可免登录解析（大文件需登录态）；UC 实测直链下载需登录态（见 ucResolve），
    // 因此 UC 与夸克/百度/迅雷/移动在下载阶段必须配 Cookie（解析阶段均免 Cookie）
    const freeProviders = ['pan123'];
    if (!cookie && !freeProviders.includes(provider)) {
      const e = new Error(`管理员尚未配置 ${PROVIDER_NAME[provider] || provider} 的会员账号 Cookie`);
      e.code = 3; throw e;
    }
  }
  let result;
  if (provider === 'quark') {
    result = await quarkResolve(url, cookie, opts);
    // 夸克解析过程中可能自动续期了 __puus —— 写回后台配置，避免下次解析用过期 Cookie
    if (!listOnly && result.updatedCookie && result.updatedCookie !== siteSettings.cookies.quark) {
      siteSettings.cookies.quark = result.updatedCookie;
      saveSettings(); // 2026-08-19 code-review: cookie 续期必须写盘，否则重启回滚旧 cookie
      pushAdminLog('cookie_refresh', '夸克 __puus 自动续期并已写回');
    }
  }
  else if (provider === 'baidu') result = await baiduResolve(url, cookie, opts);
  else if (provider === 'uc') result = await ucResolve(url, cookie, opts);
  else if (provider === 'pan123') {
    // 2026-08-19：123盘 token 失效自动重登（懒刷新：遇 5112/401 才重登，零额外开销）
    result = await pan123Resolve(url, cookie, {
      ...opts,
      ensureToken: async () => {
        // 2026-08-19 升级：refresh_token 优先（绕开验证码风控），sign_in 兜底
        const cur = extractToken(siteSettings.cookies && siteSettings.cookies.pan123 || '');
        if (cur) {
          const nt = await pan123RefreshToken(cur);
          if (nt) {
            siteSettings.cookies.pan123 = 'token=' + nt;
            saveSettings();
            pan123LoginState = { ok: true, error: '', ts: Date.now() };
            pushAdminLog('pan123_login', '123盘 token 失效已自动续期（refresh_token）');
            return nt;
          }
        }
        const acc = siteSettings.pan123Account;
        if (!acc || !acc.username || !acc.password) return null;
        try {
          const t = await pan123SignIn(acc.username, acc.password);
          if (t) {
            siteSettings.cookies.pan123 = 'token=' + t;
            saveSettings();
            pan123LoginState = { ok: true, error: '', ts: Date.now() };
            pushAdminLog('pan123_login', '123盘 token 失效已自动续期（sign_in）');
            return t;
          }
        } catch {}
        return null;
      },
    });
  }
  else if (provider === 'xunlei') result = await xunleiResolve(url, cookie, {
    ...opts,
    xunleiCaptchaToken: siteSettings.xunleiCaptchaToken || '',
    xunleiDeviceId: siteSettings.xunleiDeviceId || '',
  });
  else if (provider === 'mcloud') result = await mcloudResolve(url, cookie, opts);
  else result = await genericResolve(url, provider);
  return { provider, providerName: PROVIDER_NAME[provider], tree: result.tree, files: result.files, stoken: result.stoken || '', transfer: result.transfer || null };
}

async function handleApi(req, res, pathname) {
  const deviceId = req.deviceId;
  const q = getQuota(deviceId);

  // =====================================================================
  //  兼容层（前端为打包资源，按契约响应）
  //  实际 API 路径：
  //    uc:      /api/uc/{list,detail,fetch}
  //    xunlei:  /api/xunlei/{share,detail,restore-files}
  //    quark:   /api/quark/{share,detail,downloader-cookie,fetch}
  //    baidu:   /api/baidu/{share,detail,fetch}
  //    pan123:  /api/pan123/{share,detail,fetch}
  //    mcloud:  /api/mcloud/{share,detail,fetch}
  //    共用:    /api/parse/verify-password, /api/ip-quota, /api/daily-tasks/*, /api/my-downloads
  // =====================================================================

  // ---- 下载接口（fetch/restore-files）密码墙 ----
  // 2026-08-19 修复：前端没有解锁 UI（demo 密码 1234 无输入框 / 任务墙也未在未解锁时主动弹），
  // 强制解锁会让用户「点了下载按钮却没反应」。这里**仅当 parsePassword 非默认值 '1234' 时才强制**——
  // 生产环境管理员在后台把 parsePassword 改成自定义值即可自动启用密码墙；demo 密码下免 unlock
  // 便于直接体验完整流程（下载端通过 ip-quota + daily-tasks 四道墙限流保护）。
  if (
    siteSettings.parsePassword &&
    siteSettings.parsePassword !== '1234' &&
    /^\/api\/(quark|baidu|uc|xunlei|pan123|mcloud)\/(fetch|restore-files)$/.test(pathname) &&
    !q.unlocked
  ) {
    return sendJson(res, 403, { code: 2, msg: 'locked', ok: false, error: 'need_password', needPassword: true, hint: '请先完成密码墙解锁后再下载' });
  }

  // ---- 夸克 share（百度/UC/迅雷/123/移动云盘 都类似）----
  if (pathname === '/api/quark/share' && req.method === 'POST') return pandlShareHandle(req, res, 'quark', await readBody(req));
  if (pathname === '/api/baidu/share' && req.method === 'POST') return pandlShareHandle(req, res, 'baidu', await readBody(req));
  if (pathname === '/api/xunlei/share' && req.method === 'POST') return pandlShareHandle(req, res, 'xunlei', await readBody(req));
  // 2026-08-19 修：UC 只有 list 路由（之前漏 share），导致 /api/uc/share 404 走兜底返 api_not_found
  if (pathname === '/api/uc/share' && req.method === 'POST') return pandlShareHandle(req, res, 'uc', await readBody(req));
  if (pathname === '/api/uc/list' && req.method === 'POST') return pandlShareHandle(req, res, 'uc', await readBody(req));
  if (pathname === '/api/pan123/share' && req.method === 'POST') return pandlShareHandle(req, res, 'pan123', await readBody(req));
  if (pathname === '/api/mcloud/share' && req.method === 'POST') return pandlShareHandle(req, res, 'mcloud', await readBody(req));
  // detail（夸克/百度/UC/迅雷/123/移动云盘）—— 全部走同一形态
  if (/^\/api\/(quark|baidu|uc|xunlei|pan123|mcloud)\/detail$/.test(pathname) && req.method === 'POST') {
    const provider = pathname.split('/')[2];
    return pandlShareHandle(req, res, provider, await readBody(req), 'detail');
  }
  // fetch（夸克/百度/UC/123/移动云盘）—— 同形态
  if (/^\/api\/(quark|baidu|uc|pan123|mcloud)\/fetch$/.test(pathname) && req.method === 'POST') {
    if (!rateLimit(req, pathname)) return sendJson(res, 429, { ok: false, error: 'too_many_requests', message: '请求过于频繁，请一分钟后再试' });
    const provider = pathname.split('/')[2];
    return pandlFetchHandle(req, res, provider, await readBody(req));
  }
  // 迅雷第三步是 restore-files（不是 fetch）
  if (pathname === '/api/xunlei/restore-files' && req.method === 'POST') {
    if (!rateLimit(req, pathname)) return sendJson(res, 429, { ok: false, error: 'too_many_requests', message: '请求过于频繁，请一分钟后再试' });
    return pandlFetchHandle(req, res, 'xunlei', await readBody(req));
  }

  // ---- 站点元信息（前端启动必调）----
  if (pathname === '/api/public/meta' && req.method === 'GET') {
    const nav = [
      { title: '网站首页', url: '/', icon: 'mdi:home-outline', target: '_self', active: true, placement: 'header', sort: 0 },
      // 使用教程 → 腾讯文档（电脑小白教程，2026-08-16 用户指定；_blank 新窗口打开）
      { title: '使用教程', url: TUTORIAL_URL, icon: 'mdi:book-open-page-variant-outline', target: '_blank', active: true, placement: 'header', sort: 1 },
      // 原「API接口」无实际功能 → 替换为「问题反馈」弹窗（index.html 注入脚本拦截 /feedback 打开弹窗）
      { title: '问题反馈', url: '/feedback', icon: 'mdi:message-text-outline', target: '_self', active: true, placement: 'header', sort: 2 },
    ];
    return sendJson(res, 200, {
      ok: true,
      result: {
        site_title: 'Cool Link',
        custom_js_script: '',
        frontend_qq_group_url: '',
        frontend_qq_group_qrcode_url: '',
        nav_links: nav,
        // 禁用「全网网盘资源搜索」（用户 2026-08-16：需 TG 频道数据源，无实际用途）
        // 前端读 result.search.enabled，false 则搜索入口隐藏/禁用
        search: { enabled: false },
      },
    });
  }

  // ---- 问题反馈（前端弹窗数据源：提交 + 最近 10 条）----
  if (pathname === '/api/feedback' && req.method === 'GET') {
    const list = loadFeedbacks().slice(0, 10).map((f) => ({
      id: f.id, content: f.content || '', created_at: f.created_at || 0,
    }));
    return sendJson(res, 200, { ok: true, list });
  }
  if (pathname === '/api/feedback' && req.method === 'POST') {
    if (!rateLimit(req, pathname)) {
      return sendJson(res, 429, { ok: false, error: 'too_many_requests', message: '提交太频繁，请一分钟后再试' });
    }
    const body = await readBody(req);
    const content = String(body.content || '').trim();
    if (!content) return sendJson(res, 400, { ok: false, error: 'empty', message: '反馈内容不能为空' });
    if (content.length > 500) return sendJson(res, 400, { ok: false, error: 'too_long', message: '反馈内容最多 500 字' });
    // 内测版：反馈统一匿名，不存昵称（用户 2026-08-17 决定去掉昵称自选）
    const list = loadFeedbacks();
    list.unshift({ id: crypto.randomBytes(6).toString('hex'), content, created_at: Date.now() });
    saveFeedbacks(list);
    pushAdminLog('feedback', `新反馈: ${content.slice(0, 80)}`);
    return sendJson(res, 200, { ok: true });
  }

  // ---- 心跳（定时轮询）----
  if (pathname === '/api/public/heartbeat' && req.method === 'POST') {
    return sendJson(res, 200, { ok: true, result: { ts: Date.now() } });
  }

  // ---- 短链/编码（/api/encode：把分享链接转成「本站扫码跳转页」）----
  // 前端 cf() 消费：{ok, qrcode_url, page_url, id}；失败时前端自动兜底到 /api/qrcode 直扫
  if (pathname === '/api/encode' && req.method === 'GET') {
    const u = new URL(req.url, 'http://x');
    const target = u.searchParams.get('target') || '';
    if (!target) return sendJson(res, 400, { ok: false, error: 'missing_target' });
    const id = crypto.createHash('md5').update(target).digest('hex').slice(0, 12);
    return sendJson(res, 200, {
      ok: true,
      id,
      qrcode_url: `/api/qrcode?target=${encodeURIComponent(target)}`,
      page_url: `/?target=${encodeURIComponent(target)}`,
      target,
    });
  }

  // ---- 扫码状态轮询（/api/scan-status：App 扫码后标记已扫）----
  // 无真实扫码链路：直接返回 scanned:false（前端轮询自然结束；不影响功能）
  if (pathname === '/api/scan-status' && req.method === 'GET') {
    return sendJson(res, 200, { ok: true, scanned: false, id: new URL(req.url, 'http://x').searchParams.get('id') || '' });
  }

  // ---- 管理员豁免（/api/search/parse-admin-exempt）----
  // 管理员在后台登录过（同 IP admin token 有效）→ 视为豁免；否则非豁免
  if (pathname === '/api/search/parse-admin-exempt' && req.method === 'GET') {
    return sendJson(res, 200, { ok: true, admin_exempt: isAdmin(req) });
  }

  // ---- 热搜词上报（/api/hot-searches）----
  if (pathname === '/api/hot-searches' && req.method === 'POST') {
    const body = await readBody(req);
    pushAction(deviceId, 'hot_search', { kw: body.term || body.keyword || '' });
    return sendJson(res, 200, { ok: true });
  }

  // ---- 聚合搜索（/api/search）----
  // 站点已禁用全网盘资源搜索（用户 2026-08-16 确认）：返回空结果，避免前端报错
  if (pathname === '/api/search' && req.method === 'GET') {
    return sendJson(res, 200, { code: 0, data: { total: 0, list: [], merged_by_type: {}, message: '搜索已关闭' } });
  }

  // ---- IP 额度（/api/ip-quota）----
  if (pathname === '/api/ip-quota' && req.method === 'POST') {
    return sendJson(res, 200, {
      ok: true,
      data: {
        // 旧字段（兼容）
        ip_daily_count_remaining: q.largeCountLeft,
        ip_daily_size_remaining: Math.round(q.smallSizeLeft / MB),
        device_daily_count_remaining: q.largeCountLeft,
        device_daily_size_remaining: Math.round(q.smallSizeLeft / MB),
        small_file_parse_locked: !q.smallFileUnlocked,
        large_file_size_unlocked: q.sizeCapUnlocked,
        ip_single_size_limit_bytes: (q.sizeCapUnlocked ? 0 : siteSettings.sizeCapGB) * GB,
        unlocked: q.unlocked,
        // 完整契约（前端 Xp() 消费：count_limit/count_left/daily_small_size_*/small_file_max_size_bytes 等）
        count_limit: siteSettings.largeDailyLimit,
        count_used: Math.max(0, siteSettings.largeDailyLimit - q.largeCountLeft),
        count_left: q.largeCountLeft,
        daily_size_limit_bytes: 0,
        daily_size_left_bytes: 0,
        single_size_limit_bytes: q.sizeCapUnlocked ? 0 : LARGE_FILE_SIZE_CAP,
        small_file_split_enabled: true, // 前端 yh() 靠它走「小文件/大文件双轨判断」→ 才会弹解锁任务弹窗
        small_file_parse_enabled: q.smallFileUnlocked,
        small_file_unlocked: q.smallFileUnlocked,
        small_file_max_size_bytes: SMALL_FILE_MAX,
        daily_small_size_limit_bytes: siteSettings.smallDailyLimitMB * MB,
        daily_small_size_left_bytes: Math.max(0, q.smallSizeLeft),
        task_bonus_small_size_bytes: siteSettings.smallRewardMB * MB,
      },
    });
  }

  // ---- 夸克下载器 Cookie（前端 ku() 读 e.result.cookie 配置发送器；对齐契约）----
  // ⚠️ 反爬加固（2026-08-16 按 反爬报告）：
  //   ① 仅回传「发送器 Cookie」子集（__sdid/Video-Auth/__kuus/__uus），不泄露完整运营者账号
  //   ② 单 IP 限流（默认 10 次/分钟），防批量白嫖触发夸克风控
  if (pathname === '/api/quark/downloader-cookie' && req.method === 'GET') {
    if (!rateLimit(req, pathname)) {
      return sendJson(res, 429, { ok: false, error: 'rate_limited', message: '请求过于频繁，请稍后再试' });
    }
    const ck = quarkSenderCookie(siteSettings.cookies.quark || '');
    return sendJson(res, 200, { ok: true, result: { cookie: ck }, data: { cookie: ck } });
  }

  // ---- 发送到下载器前的直链准备（/api/prepare-download）----
  // 2026-08-20 15:53 用户核心需求：**只在点「发送到下载器」才转存**。
  //   前端 wg() 发送前对需要转存的 provider（uc/baidu/pan123/xunlei）调本接口 →
  //   后端转存 → 拿直链 → 登记待删除（pendingSaves）→ 返回 download_url + cookie，
  //   前端再推给本地下载器；推送成功后再上报 /api/downloader-push-log 触发删除。
  if (pathname === '/api/prepare-download' && req.method === 'POST') {
    const body = await readBody(req);
    const prov = String(body.provider || '').toLowerCase();
    if (!SUPPORTED_PROVIDERS.includes(prov)) return sendJson(res, 200, { ok: false, error: '不支持的网盘: ' + prov });
    body.prepare = true;
    return pandlFetchHandle(req, res, prov, body);
  }

  // ---- 发送到下载器前的解锁检查（/api/check-unlock）----
  // 2026-08-21（用户拍板）：quark/mcloud 等不走 prepare 转存的网盘，发送前前端先调本接口
  //   检查该网盘是否已解锁（dl_{provider} 任务 → 今日密码）。未解锁 → need_unlock，前端弹引导。
  if (pathname === '/api/check-unlock' && req.method === 'POST') {
    const body = await readBody(req);
    const prov = String(body.provider || '').toLowerCase();
    if (!SUPPORTED_PROVIDERS.includes(prov)) return sendJson(res, 200, { ok: false, error: '不支持的网盘: ' + prov });
    const _unl = needUnlockResponse(prov, req);
    return sendJson(res, 200, _unl || { ok: true, need_unlock: false, provider: prov });
  }

  // ---- 下载器推送日志（/api/downloader-push-log）----
  // 2026-08-19 用户需求：点「发送到下载器」→ 转存 → 发直链 → 下载完成/推送后删除转存副本。
  // 前端推送时上报 file_name + provider + download_status，这里顺带按文件名匹配清理转存副本
  // （前端不调 transfer-complete 也能删；即使漏删，TTL 兜底 6 小时也会清）
  if (pathname === '/api/downloader-push-log' && req.method === 'POST') {
    const body = await readBody(req);
    pushAction(deviceId, 'downloader_push', { provider: body.provider, file_name: body.file_name, download_status: body.download_status });
    // 对齐契约：失败可退额度
    const refunded = body.download_status === 'error';
    // 顺带清理该文件名对应的转存副本（下载器已接管/完成，不再需要转存副本）
    if (body.provider && body.file_name) {
      cleanupSaveByFileName(String(body.provider), String(body.file_name)).catch(() => {});
    }
    return sendJson(res, 200, { ok: true, quota_refunded: refunded });
  }

  // ---- 下载完成上报（用户构想 2026-08-15：点击发送下载器→转存→下载完成→删除副本）----
  // 前端在下载器任务完成（成功/失败/取消）后调用，立即删除本次转存的副本；
  // 若前端不上报，TTL 兜底清理（默认 6 小时）也会自动删除，不会永久占用网盘
  if (pathname === '/api/transfer-complete' && req.method === 'POST') {
    const body = await readBody(req);
    const provider = body.provider || '';
    const shareId = body.share_id || body.shareId || '';
    const fileName = body.file_name || body.fileName || 'all';
    if (!provider || !shareId) return sendJson(res, 200, { ok: false, error: 'bad_request', message: '缺少 provider/share_id' });
    const r = await cleanupSave(provider, shareId, fileName);
    pushAction(deviceId, 'transfer_complete', { provider, share_id: shareId, cleaned: r.found });
    return sendJson(res, 200, { ok: true, cleaned: r.found, delete_ok: r.ok !== false });
  }

  // ---- 我的下载（参考站 /api/my-downloads：今日解析和额度数据源）----
  // 字段：file_name / file_size / provider / providerName / time / download_link / share_id
  if (pathname === '/api/my-downloads' && req.method === 'POST') {
    const body = await readBody(req);
    const page = Number(body.page) || 1;
    const pageSize = Number(body.page_size) || 50;
    const mine = downloadLogs.filter((d) => d.deviceId === deviceId);
    const list = mine.slice().reverse().slice((page - 1) * pageSize, page * pageSize)
      .map((d) => ({
        file_name: d.file_name,
        file_size: d.file_size,
        provider: d.provider,
        providerName: d.providerName || d.provider,
        // 参考站 前端网盘徽章用 e.kind（= 网盘 key），前端 Fg() 自行映射中文名
        kind: d.provider,
        time: fmtParseTime(d.ts),
        download_link: d.download_link,
        share_id: d.shareId || '',
      }));
    return sendJson(res, 200, { ok: true, data: { page, page_size: pageSize, total: mine.length, list } });
  }

  // ---- 每日任务（参考站 契约：任务=奖励类型，完成方式=多个可选网盘的推广口令）----
  if (pathname === '/api/daily-tasks/today' && (req.method === 'POST' || req.method === 'GET')) {
    // 停用的任务位不展示给用户
    const visibleTasks = dailyTasks.filter((t) => t.enabled !== false);
    const list = visibleTasks.map((t) => {
      // 任务可选网盘 = 后台配的 providers 并集 task_provider（用户只绑定 task_provider 时也能拿到推广口令）
      const promoProviders = [...new Set([...(t.providers || []), ...(t.task_provider ? [t.task_provider] : [])])];
      // 每个任务列出可选网盘的推广口令（用户任选其一完成）
      const promoOptions = promoProviders.map((p) => {
        const promo = siteSettings.promo[p] || {};
        return {
          provider: p,
          provider_name: PROVIDER_NAME[p] || p,
          passcode: promo.passcode || DEFAULT_PROMO_PASSCODE[p] || '复制口令到网盘获取解析密码',
          link: promo.link || '',
          qrUrl: promo.qrUrl || (promo.link ? `/api/qrcode?text=${encodeURIComponent(promo.link)}` : ''),
        };
      });
      return {
        id: t.id,
        task_id: t.id,
        title: t.title,
        description: t.description,
        reward_type: t.reward_type || 'default',
        reward_count: Number(t.reward_count) || 0,
        reward_provider: t.reward_provider || '',
        reward_text: rewardTextOf(t),
        icon: t.icon || '🎯',
        slot: t.slot || '',
        category: t.category || '',
        claimed: !!q.claimedTasks[t.id],
        completed: !!(q.completedTasks && q.completedTasks[t.id]),
        // 完成方式：可选网盘推广口令（任选其一）+ 答案任务
        providers: t.providers || [],
        promo_options: promoOptions,
        is_answer_task: t.type === 'answer' && (!t.providers || !t.providers.length),
        answer: (t.type === 'answer' && (!t.providers || !t.providers.length)) ? (t.answer || '') : '',
        // 任务绑定的网盘密码任务（用户 2026-08-15 澄清：任务绑定网盘，密码跟随该网盘今日密码）
        task_provider: t.task_provider || '',
        provider_name: t.task_provider ? (PROVIDER_NAME[t.task_provider] || t.task_provider) : '',
      };
    });
    return sendJson(res, 200, { ok: true, data: { date: q.date, tasks: list, quota: pandlQuotaView(q) } });
  }
  if (pathname === '/api/daily-tasks/complete' && req.method === 'POST') {
    const body = await readBody(req);
    const task = dailyTasks.find((t) => t.id === (body.task_id || body.taskId));
    if (!task) return sendJson(res, 200, { ok: false, error: 'task_not_found', message: '任务不存在' });
    if (q.claimedTasks[task.id]) return sendJson(res, 200, { ok: false, error: 'already_claimed', message: '已领取过奖励' });
    // 完成方式校验（用户 2026-08-15 澄清的模型）：
    //   任务 = 绑定某个网盘的密码任务（task_provider，管理员后台指定）
    //   该任务的密码 = 该网盘今日密码（自动程序每日生成，管理员不自己生成）
    //   用户输入 4 位密码 → 与「绑定网盘」的今日密码比对
    const input = String(body.answer || body.password || body.parse_password || '').trim();
    const boundProvider = task.task_provider || (task.providers && task.providers.length === 1 ? task.providers[0] : '');
    if (boundProvider) {
      const all = loadDailyPasswords();
      const code = all && all.codes ? all.codes[boundProvider] : '';
      if (!code) {
        return sendJson(res, 200, { ok: false, error: 'no_daily_password', message: `${PROVIDER_NAME[boundProvider] || boundProvider} 今日密码尚未生成，请稍后再试或联系管理员` });
      }
      if (input !== code) {
        return sendJson(res, 200, { ok: false, error: 'wrong_answer', message: `${PROVIDER_NAME[boundProvider] || boundProvider} 今日密码不正确，请前往该网盘分享文件夹获取（zip 内 password.txt）` });
      }
    } else if (task.type === 'answer') {
      // 无绑定网盘的纯答案任务（预留）：验证任务自带 answer 或今日密码
      const all = loadDailyPasswords();
      const firstCode = all && all.codes ? Object.values(all.codes)[0] : '';
      const expected = task.answer || firstCode || '';
      if (!expected) return sendJson(res, 200, { ok: false, error: 'no_daily_password', message: '今日密码尚未生成，请稍后再试' });
      if (input !== expected) return sendJson(res, 200, { ok: false, error: 'wrong_answer', message: '密码不正确' });
    }
    // 记录用户实际完成所用网盘（参考站 前端传 reward_provider）。
    // 注意：任务关联哪些网盘由管理员在后台指定（用户不做选择），因此不做「不同网盘」强制校验，
    // 只记录供运营查看（哪个网盘口令被实际使用过）
    const doneProvider = body.reward_provider || body.provider || '';
    q.completedTasks[task.id] = true;
    if (!q.taskProviders) q.taskProviders = {};
    q.taskProviders[task.id] = doneProvider || q.taskProviders[task.id] || '';
    saveDevices();
    pushAction(deviceId, 'task_complete', { taskId: task.id, provider: doneProvider });
    return sendJson(res, 200, { ok: true, data: { task_id: task.id, provider: doneProvider } });
  }
  if (pathname === '/api/daily-tasks/claim' && req.method === 'POST') {
    const body = await readBody(req);
    const task = dailyTasks.find((t) => t.id === (body.task_id || body.taskId));
    if (!task) return sendJson(res, 200, { ok: false, error: 'task_not_found', message: '任务不存在' });
    if (q.claimedTasks[task.id]) return sendJson(res, 200, { ok: false, error: 'already_claimed', message: '已领取过奖励' });
    if (!q.completedTasks || !q.completedTasks[task.id]) {
      return sendJson(res, 200, { ok: false, error: 'task_not_completed', message: '请先完成任务后再领取奖励' });
    }
    q.claimedTasks[task.id] = true;
    applyReward(q, task);
    saveDevices();
    return sendJson(res, 200, { ok: true, data: { task_id: task.id, reward_text: rewardTextOf(task), quota: pandlQuotaView(q) } });
  }
  if (pathname === '/api/daily-tasks/reveal-answer' && (req.method === 'GET' || req.method === 'POST')) {
    const u = new URL(req.url, 'http://x');
    const taskId = u.searchParams.get('task_id') || '';
    const task = dailyTasks.find((t) => t.id === taskId);
    if (!task) return sendJson(res, 200, { ok: false, error: 'task_not_found', message: '任务不存在' });
    const isAnswerTask = task.type === 'answer' && (!task.providers || !task.providers.length);
    if (!isAnswerTask) return sendJson(res, 200, { ok: false, error: 'no_answer', message: '该任务无答案可查看' });
    // answer 任务答案 = 今日密码（用户需去夸克分享的 zip 获取；此处仅给提示不给明文，防白嫖）
    const todayPwd = loadTodayPassword();
    const answer = todayPwd ? '今日密码见网盘分享「今日密码.zip」' : '今日密码尚未生成';
    return sendJson(res, 200, { ok: true, data: { task_id: task.id, answer } });
  }

  // ---- 解析密码校验（参考站 契约：provider + password）----
  // 2026-08-19 兼容：旧 bundle 会 GET /api/parse/scan-guide?provider=xunlei（扫描引导），
  //   新 server 已移除该路由 → 404 → 前端显示"响应异常"。返回空 ok 兼容。
  if (pathname === '/api/parse/scan-guide' && req.method === 'GET') {
    return sendJson(res, 200, { ok: true, result: { guide: '' }, data: {} });
  }
  if (pathname === '/api/parse/verify-password' && req.method === 'POST') {
    const body = await readBody(req);
    const pwd = String(body.password || '').trim();
    if (pwd === siteSettings.parsePassword) {
      q.unlocked = true;
      saveDevices();
      return sendJson(res, 200, { ok: true, unlocked: true, data: { unlocked: true }, quota: pandlQuotaView(q) });
    }
    return sendJson(res, 200, { ok: false, error: 'invalid_parse_password', message: '解析密码错误，请重新输入', attempts_left: 5 });
  }

  // ---- 搜索状态（参考站 前端检查解锁态：Dc() 读 e.ok && !e.locked → locked 必须返回）----
  if (pathname === '/api/search/auth/status' && req.method === 'GET') {
    return sendJson(res, 200, {
      ok: true,
      unlocked: q.unlocked,
      locked: !q.unlocked,      // 参考站 前端 Dc() 用 !e.locked 判断是否已解锁，缺失会导致密码墙永不弹出
      data: { unlocked: q.unlocked },
      quota: pandlQuotaView(q),
    });
  }
  if (pathname === '/api/search/auth/unlock' && req.method === 'POST') {
    const body = await readBody(req);
    if (String(body.password || '') === siteSettings.parsePassword) {
      q.unlocked = true;
      saveDevices();
      return sendJson(res, 200, { ok: true, unlocked: true, locked: false, quota: pandlQuotaView(q) });
    }
    return sendJson(res, 200, { ok: false, error: 'invalid_parse_password', message: '解析密码错误，请重新输入' });
  }

  // ---- 真实解析 ----
  if (pathname === '/api/parse' && req.method === 'POST') {
    const body = await readBody(req);
    const { url, provider } = body;
    if (!url || !provider) return sendJson(res, 400, { code: 1, msg: '缺少分享链接或网盘类型' });

    // 解析自由：四道墙（密码/流量/大小/大文件次数）统一移到「下载」环节 ( /api/download )
    try {
      const r = await resolveProvider(provider, url, { allowSave: false });
      pushAction(deviceId, 'parse', { provider, success: true });
      // 解析只负责拿直链，不扣额度、不拦截（墙在下载环节）
      return sendJson(res, 200, { code: 0, data: { ...r, quota: quotaView(q) } });
    } catch (e) {
      pushAction(deviceId, 'parse', { provider, success: false, detail: e.message });
      if (e.code === 3 || e.code === 4) return sendJson(res, 400, { code: e.code, msg: e.message });
      return sendJson(res, 502, { code: 8, msg: 'parse_failed', error: e.message });
    }
  }

  // ---- 批量获取下载链接（对齐 参考站 fetch：对指定文件重新取直链；不扣额度）----
  // 前端「批量获取下载链接」对无直链文件逐个调用，name 精确匹配
  if (pathname === '/api/fetch-link' && req.method === 'POST') {
    const body = await readBody(req);
    const { provider, url, name } = body;
    if (!url || !provider) return sendJson(res, 400, { code: 1, msg: '缺少分享链接或网盘类型' });
    if (!name) return sendJson(res, 400, { code: 1, msg: '缺少文件名' });
    try {
      const r = await resolveProvider(provider, url, {
        allowSave: true,
        // 2026-08-19：fetch 也要提取码（前端把 ?pwd= 拆出放 body.pass_code）
        pass_code: body.pass_code || body.passcode || '',
      });
      const target = (r.files || []).find((f) => f.name === name);
      if (!target || !target.url) throw new Error('未获取到该文件的下载链接');
      return sendJson(res, 200, { code: 0, data: { name: target.name, url: target.url, expiresAt: target.expiresAt } });
    } catch (e) {
      return sendJson(res, 502, { code: 8, msg: 'fetch_failed', error: e.message });
    }
  }

  // ---- 解析前置校验（parse-verify-status）----
  if (pathname === '/api/search/parse-verify-status' && req.method === 'GET') {
    const u = new URL(req.url, 'http://x');
    const provider = u.searchParams.get('provider') || 'quark';
    return sendJson(res, 200, {
      code: 0,
      data: {
        provider,
        require_unlock: !q.unlocked,
        unlocked: q.unlocked,
        quota: quotaView(q),
      },
    });
  }

  // ---- 揭示直链（穿透防盗链 → 真实直链 + 提取码，等价于 /api/parse）----
  if (pathname === '/api/search/reveal-links' && req.method === 'POST') {
    const body = await readBody(req);
    const { provider, url, refs } = body;
    if (!url || !provider) return sendJson(res, 400, { code: 1, msg: '缺少分享链接或网盘类型' });
    try {
      const r = await resolveProvider(provider, url, { allowSave: false });
      return sendJson(res, 200, { code: 0, data: { ...r, refs: refs || null, quota: quotaView(q) } });
    } catch (e) {
      if (e.code === 3 || e.code === 4) return sendJson(res, 400, { code: e.code, msg: e.message });
      return sendJson(res, 502, { code: 8, msg: 'reveal_failed', error: e.message });
    }
  }

  // ---- 校验直链有效性（真实 HEAD/GET 探测）----
  if (pathname === '/api/search/check-links' && req.method === 'POST') {
    const body = await readBody(req);
    const urls = Array.isArray(body.urls) ? body.urls : [body.url];
    const results = await Promise.all(urls.filter(Boolean).map(async (u) => {
      try {
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), 6000);
        const resp = await fetchTimeout(u, { method: 'HEAD', redirect: 'follow', signal: ctrl.signal });
        clearTimeout(t);
        return { url: u, ok: resp.ok, status: resp.status };
      } catch (e) {
        return { url: u, ok: false, status: 0, error: e.message };
      }
    }));
    return sendJson(res, 200, { code: 0, data: { results } });
  }

  // ---- 埋点上报 ----
  if (pathname === '/api/search/track-action' && req.method === 'POST') {
    const body = await readBody(req);
    pushAction(deviceId, body.action || 'unknown', { kw: body.kw, provider: body.provider, success: body.success, detail: body.detail });
    return sendJson(res, 200, { code: 0, msg: 'tracked' });
  }

  // ---- 下载环节：才弹四道墙（密码墙 / 小文件流量 / 大小上限 / 大文件次数）----
  if (pathname === '/api/download' && req.method === 'POST') {
    const body = await readBody(req);
    const { provider, items } = body; // items: [{name,size,url}]
    if (!Array.isArray(items) || items.length === 0) return sendJson(res, 400, { code: 1, msg: '无下载项' });

    // 1) 密码墙（代表去网盘保存压缩包获取的4位密码）
    if (!q.unlocked) return sendJson(res, 403, { code: 2, msg: 'locked', needPassword: true, promo: promoView(provider), hint: '扫码或复制口令到网盘转存，获取解析密码后再下载（demo 密码 1234）' });

    const blocked = [];
    let largeUsed = 0, smallUsedBytes = 0;

    // 第一遍：只检查，不扣减 —— 全部通过才真正扣额度（避免先扣后拦截）
    const largePassed = [], smallPassed = [];
    for (const f of items) {
      const size = Number(f.size) || 0;
      // 1) 超大文件权限线（>2GB 需任务解锁；解锁后个数与 2GB 以内大文件相通，走同一个 count 池）
      if (size > LARGE_FILE_SIZE_CAP && !q.sizeCapUnlocked) {
        blocked.push({ name: f.name, reason: 'large_size_locked', hint: `该文件超过 ${LARGE_FILE_SIZE_CAP / GB}GB，需完成「解除大小限制」任务开通大文件下载权限` });
        continue;
      }
      // 2) 大文件（>200MB，含解锁后的超大文件）：按「个数」限额
      if (size > SMALL_FILE_MAX) {
        if (q.largeCountLeft - largePassed.length <= 0) { blocked.push({ name: f.name, reason: 'large_limit', hint: '今日大文件下载次数已用完（每日 20 个），做「每日签到」任务可追加' }); continue; }
        largePassed.push(f);
      } else {
        // 3) 小体积文件（<=200MB）：先解锁，再按「字节总量」限额
        if (!q.smallFileUnlocked) { blocked.push({ name: f.name, reason: 'small_locked', hint: '小体积文件未解锁，完成「去网盘保存」任务可解锁并追加流量' }); continue; }
        if (q.smallSizeLeft - smallUsedBytes < size) { blocked.push({ name: f.name, reason: 'small_traffic', hint: '小文件流量不足（每日 2GB），再做一次保存任务补充' }); continue; }
        smallPassed.push(f); smallUsedBytes += size;
      }
    }
    // 拦截时返回 参考站 前端认识的错误码 → 前端自动弹「额度不足」弹窗 +「免费领取」→ 任务列表弹窗
    //   small_locked       → small_file_parse_locked（解锁小文件任务）
    //   small_traffic      → device_daily_small_size_exceeded（小文件流量用尽 → 追加任务）
    //   large_size_locked  → ip_single_size_exceeded（单文件超限 → 解除大小限制任务）
    //   large_limit        → device_daily_count_exceeded（大文件次数用尽 → 签到任务）
    if (blocked.length > 0) {
      const b0 = blocked[0];
      let errCode = 'download_blocked';
      if (b0.reason === 'small_locked') errCode = 'small_file_parse_locked';
      else if (b0.reason === 'small_traffic') errCode = 'device_daily_small_size_exceeded';
      else if (b0.reason === 'large_size_locked') errCode = 'ip_single_size_exceeded';
      else if (b0.reason === 'large_limit') errCode = 'device_daily_count_exceeded';
      return sendJson(res, 403, { code: 9, msg: errCode, error: errCode, blocked, quota: quotaView(q) });
    }

    // 第二遍：全部通过，统一扣减
    q.largeCountLeft -= largePassed.length;
    q.smallSizeLeft -= smallUsedBytes;
    saveDevices();
    largeUsed = largePassed.length;
    // 记录「我的下载」（/api/my-downloads 数据源，去重后写入）
    for (const f of items) {
      recordDownloadLog(deviceId, provider, '', f, { action: 'download' });
    }
    return sendJson(res, 200, { code: 0, ok: true, quota: quotaView(q), consumed: { largeUsed, smallUsedBytes } });
  }

  // ---- 生成二维码（把推广分享链接转成可扫二维码）----
  if (pathname === '/api/qrcode' && req.method === 'GET') {
    const u = new URL(req.url, 'http://x');
    // 参考站 前端契约：直接扫分享链接用 ?target=xxx；后台 promoView 用 ?text=xxx；兼容三参数
    const text = u.searchParams.get('target') || u.searchParams.get('text') || u.searchParams.get('url') || '';
    if (!text) return sendJson(res, 400, { code: 1, msg: '缺少 target/text/url 参数' });
    try {
      const svg = qrToSVG(text, 4);
      res.writeHead(200, { 'Content-Type': 'image/svg+xml; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end(svg);
    } catch (e) {
      return sendJson(res, 400, { code: 1, msg: '二维码生成失败：' + e.message });
    }
  }

  // ---- 后台：任务管理（增删改查 + 排序）----
  if (pathname === '/api/admin/daily-tasks' && req.method === 'GET') {
    if (!isAdmin(req)) return sendJson(res, 401, { code: 1, msg: '未登录' });
    return sendJson(res, 200, { code: 0, data: { tasks: dailyTasks } });
  }
  if (pathname === '/api/admin/daily-tasks' && req.method === 'POST') {
    if (!isAdmin(req)) return sendJson(res, 401, { code: 1, msg: '未登录' });
    const body = await readBody(req);
    const task = body.task || body;
    if (!task || !task.id) return sendJson(res, 400, { code: 1, msg: '缺少任务 id' });
    const idx = dailyTasks.findIndex((t) => t.id === task.id);
    const clean = {
      id: String(task.id),
      type: String(task.type || 'answer'),
      icon: String(task.icon || '🎯'),
      title: String(task.title || '任务 #' + task.id),
      description: String(task.description || ''),
      reward_type: String(task.reward_type || 'default'),
      reward_count: Number(task.reward_count) || 0,
      reward_provider: String(task.reward_provider || ''),
      providers: Array.isArray(task.providers) ? task.providers.filter(Boolean) : [],
      answer: String(task.answer || ''),
      slot: String(task.slot || ''),
      category: String(task.category || '其它'),
      enabled: task.enabled !== false,
      // 任务绑定的网盘密码任务（用户 2026-08-15 澄清：任务密码跟随绑定网盘的今日密码）
      task_provider: String(task.task_provider || ''),
    };
    if (idx >= 0) dailyTasks[idx] = clean;
    else dailyTasks.push(clean);
    saveTasks();
    pushAdminLog('daily_task', `保存任务 ${clean.id}`);
    return sendJson(res, 200, { code: 0, msg: 'saved', data: { tasks: dailyTasks } });
  }
  // 删除任务：/api/admin/daily-tasks/:id/delete
  if (/^\/api\/admin\/daily-tasks\/[^/]+\/delete$/.test(pathname) && req.method === 'POST') {
    if (!isAdmin(req)) return sendJson(res, 401, { code: 1, msg: '未登录' });
    const id = decodeURIComponent(pathname.split('/')[4]);
    dailyTasks = dailyTasks.filter((t) => t.id !== id);
    saveTasks();
    pushAdminLog('daily_task', `删除任务 ${id}`);
    return sendJson(res, 200, { code: 0, msg: 'deleted', data: { tasks: dailyTasks } });
  }
  // 任务排序：/api/admin/daily-tasks/reorder {ids:[]}
  if (pathname === '/api/admin/daily-tasks/reorder' && req.method === 'POST') {
    if (!isAdmin(req)) return sendJson(res, 401, { code: 1, msg: '未登录' });
    const body = await readBody(req);
    if (Array.isArray(body.ids)) {
      const map = new Map(dailyTasks.map((t) => [t.id, t]));
      dailyTasks = body.ids.map((id) => map.get(id)).filter(Boolean);
      saveTasks();
    }
    return sendJson(res, 200, { code: 0, msg: 'reordered', data: { tasks: dailyTasks } });
  }

  // ---- 后台：任务完成日志（参考站 契约）----
  if (pathname === '/api/admin/daily-tasks/logs' && req.method === 'GET') {
    if (!isAdmin(req)) return sendJson(res, 401, { code: 1, msg: '未登录' });
    const logs = actionLogs.filter((a) => String(a.action).startsWith('task_')).slice(-100).reverse();
    return sendJson(res, 200, { code: 0, data: { logs } });
  }

  // =====================================================================
  //  管理后台（运营侧，最小版）
  // =====================================================================
  if (pathname === '/api/admin/login' && req.method === 'POST') {
    const body = await readBody(req);
    const ip = req.socket.remoteAddress || '';
    const lockLeft = checkLoginLocked(ip);
    if (lockLeft > 0) {
      pushAdminLog('login_blocked', `IP ${ip} 登录失败过多，锁定剩余 ${lockLeft}s`);
      return sendJson(res, 429, { code: 1, msg: `尝试次数过多，请 ${Math.ceil(lockLeft / 60)} 分钟后再试` });
    }
    if (body.password !== ADMIN_PASSWORD) {
      recordLoginFail(ip);
      pushAdminLog('login_fail', `后台登录失败（IP ${ip}，第 ${loginFails.get(ip)?.count || 1} 次）`);
      return sendJson(res, 403, { code: 1, msg: '密码错误' });
    }
    clearLoginFails(ip);
    adminSession = {
      token: crypto.randomBytes(16).toString('hex'),
      ip,
      expiresAt: Date.now() + 12 * 3600 * 1000, // 12 小时
    };
    pushAdminLog('login', '管理员登录成功');
    res.writeHead(200, {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
      'Set-Cookie': `admin_token=${adminSession.token}; Path=/; Max-Age=43200; SameSite=Lax; HttpOnly`,
    });
    return res.end(JSON.stringify({ code: 0, msg: 'ok' }));
  }
  if (pathname === '/api/admin/auth-check' && req.method === 'GET') {
    return sendJson(res, 200, { code: 0, data: { authed: isAdmin(req) } });
  }
  if (pathname === '/api/admin/logout' && req.method === 'POST') {
    // 清空会话（登录态 cookie 由前端 HttpOnly 失效处理：后端把 token 置空即可）
    if (isAdmin(req)) { adminSession = null; pushAdminLog('logout', '管理员退出登录'); }
    res.writeHead(200, {
      'Content-Type': 'application/json; charset=utf-8',
      'Set-Cookie': 'admin_token=; Path=/; Max-Age=0; HttpOnly',
    });
    return res.end(JSON.stringify({ code: 0, msg: 'ok' }));
  }
  if (pathname === '/api/admin/overview' && req.method === 'GET') {
    if (!isAdmin(req)) return sendJson(res, 401, { code: 1, msg: '未登录' });
    const today = todayStr();
    const todayActions = actionLogs.filter((a) => new Date(a.ts).toDateString() === new Date().toDateString());
    const parseOk = todayActions.filter((a) => a.action === 'parse' && a.success).length;
    const parseFail = todayActions.filter((a) => a.action === 'parse' && !a.success).length;
    const byProvider = {};
    for (const a of todayActions) if (a.provider) byProvider[a.provider] = (byProvider[a.provider] || 0) + 1;
    // 2026-08-19：总览图表数据（用户要求：①15天访问柱状图(访问次数+访问用户分开) ②15天解析下载折线图 ③访客来源并入第一项）
    let days = 15;
    try {
      const qd = parseInt(new URL(req.url, 'http://x').searchParams.get('days') || '15', 10);
      if (!isNaN(qd)) days = qd;
    } catch {}
    days = Math.min(30, Math.max(7, days));
    const accessSeries = getAccessSeries(days);       // [{date, devices(用户), total(次数)}]
    const parseSeries = getParseSeries(days);          // [{date, ok, download, fail}]
    // 访客来源（并入第一项展示）
    const srcByHost = {};
    for (const v of visitorLogs) {
      const key = v.host || '(直接访问)';
      srcByHost[key] = (srcByHost[key] || 0) + 1;
    }
    const sourceTop = Object.entries(srcByHost).map(([host, count]) => ({ host, count }))
      .sort((a, b) => b.count - a.count).slice(0, 8);
    return sendJson(res, 200, {
      code: 0,
      data: {
        date: today,
        totalActions: todayActions.length,
        parseOk, parseFail,
        byProvider,
        activeDevices: new Set(todayActions.map((a) => a.deviceId)).size,
        siteSettings: sanitizeSettings(siteSettings),
        // 图表数据（2026-08-19）
        accessSeries,          // 柱状图：访问次数(total) + 访问用户(devices)
        parseSeries,           // 折线图：解析成功(ok) / 下载(download) / 失败(fail)
        accessTotal: accessSeries.reduce((s, d) => s + d.total, 0),
        // 已访问人数：近 N 天指纹去重（跨天不重复计数）
        accessUsers: countUniqueUsers(days),
        visitorSource: sourceTop,
      },
    });
  }
  // ---- 用户操作日志独立端点（内测版整体改善：对齐 参考站 /api/admin/user-action-logs）----
  if (pathname === '/api/admin/user-action-logs' && req.method === 'GET') {
    if (!isAdmin(req)) return sendJson(res, 401, { code: 1, msg: '未登录' });
    const list = actionLogs.slice(-200).reverse().map((a) => ({ time: new Date(a.ts).toLocaleString(), ...a }));
    return sendJson(res, 200, { code: 0, data: list });
  }
  // ---- 访客来源日志（内测版整体改善：页面访问来源埋点统计）----
  if (pathname === '/api/admin/visitor-source-logs' && req.method === 'GET') {
    if (!isAdmin(req)) return sendJson(res, 401, { code: 1, msg: '未登录' });
    const byHost = {};
    for (const v of visitorLogs) {
      const key = v.host || '(直接访问)';
      byHost[key] = (byHost[key] || 0) + 1;
    }
    const sourceTop = Object.entries(byHost).map(([host, count]) => ({ host, count }))
      .sort((a, b) => b.count - a.count).slice(0, 10);
    const mobile = visitorLogs.filter((v) => v.uaType === 'mobile').length;
    const recent = visitorLogs.slice(0, 100).map((v) => ({ time: new Date(v.ts).toLocaleString(), ...v }));
    return sendJson(res, 200, { code: 0, data: { total: visitorLogs.length, mobile, pc: visitorLogs.length - mobile, sourceTop, recent } });
  }
  // ---- 趋势分析（内测版整体改善：最近 24h 按小时聚合解析/下载）----
  if (pathname === '/api/admin/trend' && req.method === 'GET') {
    if (!isAdmin(req)) return sendJson(res, 401, { code: 1, msg: '未登录' });
    const now = Date.now();
    const hours = [];
    for (let i = 23; i >= 0; i--) {
      const start = now - i * 3600 * 1000;
      const end = start + 3600 * 1000;
      const inRange = (t) => t >= start && t < end;
      const bucket = actionLogs.filter((a) => inRange(a.ts));
      hours.push({
        hour: new Date(start).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        parse_ok: bucket.filter((a) => a.action === 'parse' && a.success).length,
        parse_fail: bucket.filter((a) => a.action === 'parse' && !a.success).length,
        fetch: bucket.filter((a) => a.action === 'fetch' || a.action === 'download').length,
      });
    }
    return sendJson(res, 200, { code: 0, data: hours });
  }
  if (pathname === '/api/admin/settings' && req.method === 'GET') {
    if (!isAdmin(req)) return sendJson(res, 401, { code: 1, msg: '未登录' });
    // 2026-08-19：刷新 123盘 token 状态缓存（节流 5 分钟，供状态面板）
    try { await refreshPan123TokenCache(); } catch {}
    // 不回显 Cookie 明文，只回显是否已配置
    return sendJson(res, 200, { code: 0, data: sanitizeSettings(siteSettings) });
  }
  if (pathname === '/api/admin/settings' && req.method === 'POST') {
    if (!isAdmin(req)) return sendJson(res, 401, { code: 1, msg: '未登录' });
    const body = await readBody(req);
    if (typeof body.parsePassword === 'string' && body.parsePassword) siteSettings.parsePassword = body.parsePassword;
    if (typeof body.sizeCapGB === 'number') siteSettings.sizeCapGB = body.sizeCapGB;
    if (typeof body.largeDailyLimit === 'number') siteSettings.largeDailyLimit = body.largeDailyLimit;
    if (typeof body.smallRewardMB === 'number') siteSettings.smallRewardMB = body.smallRewardMB;
    // 运营者会员账号 Cookie（6 网盘统一，留空 = 保持原值，不回显）
    // 支持显式清空：传 { clearCookies: ['quark'] } 或 cookies[p] === '__CLEAR__'
    if (body.cookies && typeof body.cookies === 'object') {
      for (const p of PROVIDERS) {
        if (body.cookies[p] === '__CLEAR__') siteSettings.cookies[p] = '';
        else if (typeof body.cookies[p] === 'string' && body.cookies[p].trim()) siteSettings.cookies[p] = body.cookies[p].trim();
      }
    }
    if (Array.isArray(body.clearCookies)) {
      for (const p of body.clearCookies) if (PROVIDERS.includes(p)) siteSettings.cookies[p] = '';
    }
    if (body.promo && typeof body.promo === 'object') {
      for (const p of PROVIDERS) {
        if (body.promo[p] && typeof body.promo[p] === 'object') {
          siteSettings.promo[p] = { ...siteSettings.promo[p], ...body.promo[p] };
        }
      }
    }
    // 2026-08-19：迅雷验证码 token 直填（浏览器 F12 抓 x-captcha-token，6-24h 有效）
    if (typeof body.xunleiCaptchaToken === 'string') {
      const t = body.xunleiCaptchaToken.trim();
      if (t) siteSettings.xunleiCaptchaToken = t;
      if (body.xunleiCaptchaTokenClear === true) siteSettings.xunleiCaptchaToken = '';
    }
    if (typeof body.xunleiDeviceId === 'string') {
      const d = body.xunleiDeviceId.trim();
      if (d) siteSettings.xunleiDeviceId = d;
    }
    // 2026-08-19：123盘 token 直填（登录被验证码风控时的替代方案；非空才处理）
    if (body.pan123Token && typeof body.pan123Token === 'string') {
      const tk = body.pan123Token.trim().replace(/^token=/, '').trim();
      if (tk) {
        const ok = await pan123CheckToken(tk);
        if (ok) {
          siteSettings.cookies.pan123 = 'token=' + tk;
          pan123LoginState = { ok: true, error: '', ts: Date.now() };
          pan123TokenState = { ok: true, msg: '✓ token 有效，已保存（每 6 小时自动续期）' };
          pushAdminLog('pan123_login', '123盘 token 直填验证通过，已保存');
        } else {
          pan123TokenState = { ok: false, msg: '✗ token 无效或已过期，请重新从网页复制' };
          pushAdminLog('pan123_login', '123盘 token 直填验证失败（无效 token）');
        }
        saveSettings();
      }
    }
    // 2026-08-19：123盘 账号密码登录（改登录后 cookie 过期自动重登，不再手动复制）
    if (body.pan123Account && typeof body.pan123Account === 'object') {
      const u = String(body.pan123Account.username || '').trim();
      const p = String(body.pan123Account.password || '');
      const prev = siteSettings.pan123Account || { username: '', password: '' };
      siteSettings.pan123Account = {
        username: u || prev.username,        // 空=保持原用户名
        password: p || prev.password,        // 空=保持原密码（不回显，前端留空=不改）
      };
      if (body.pan123Account.clear === true) siteSettings.pan123Account = { username: '', password: '' };
    }
    saveSettings(); // 写盘持久化（Cookie/推广重启不丢）
    // 若配置了 123盘 账号密码 → 立即 sign_in 换 token（token 存 cookies.pan123）
    if (siteSettings.pan123Account.username && siteSettings.pan123Account.password) {
      try {
        const t = await pan123SignIn(siteSettings.pan123Account.username, siteSettings.pan123Account.password);
        if (t) {
          siteSettings.cookies.pan123 = 'token=' + t;
          saveSettings();
          pan123LoginState = { ok: true, error: '', ts: Date.now() };
          pushAdminLog('pan123_login', '123盘账号登录成功，token 已更新');
        }
      } catch (e) {
        pan123LoginState = { ok: false, error: e.message, ts: Date.now() };
        pushAdminLog('pan123_login', '123盘账号登录失败: ' + e.message);
      }
    }
    pushAdminLog('settings', '更新站点设置');
    // 用户 2026-08-16 确认：勾选「启动每日自动化」保存后立即生成；当天已生成则幂等沿用（不重复上传）
    // 同步等待执行完毕 → 把结果（生成的密码+分享 / 失败原因）一并回给后台，让管理员立即看到反馈
    let dailyPwdRun = null;
    try {
      dailyPwdRun = await runDailyPasswordJob();
    } catch (e) {
      pushAdminLog('daily_pwd_err', e.message);
    }
    const dailyPwdInfo = loadDailyPasswords();
    return sendJson(res, 200, {
      code: 0,
      msg: 'saved',
      data: sanitizeSettings(siteSettings),
      daily_pwd: dailyPwdInfo,
      daily_pwd_run: dailyPwdRun,
    });
  }
  if (pathname === '/api/admin/logs' && req.method === 'GET') {
    if (!isAdmin(req)) return sendJson(res, 401, { code: 1, msg: '未登录' });
    // 支持 ?hour=YYYYMMDD-HH 读历史小时日志（纠错用）；缺省读内存最新
    const u = new URL(req.url, 'http://x');
    const hour = u.searchParams.get('hour') || '';
    if (hour) {
      const h = readLogHour(hour);
      if (!h) return sendJson(res, 200, { code: 0, data: { hour, admin: [], actions: [], downloads: [] } });
      const admin = (h.admin || []).slice(-100).reverse();
      const actions = (h.actions || []).slice(-200).reverse().map((a) => ({ time: new Date(a.ts).toLocaleString(), ...a }));
      return sendJson(res, 200, { code: 0, data: { hour, admin, actions } });
    }
    const admin = adminLogs.slice(-100).reverse().map((a) => ({ time: new Date(a.ts).toLocaleString(), ...a }));
    const actions = actionLogs.slice(-200).reverse().map((a) => ({ time: new Date(a.ts).toLocaleString(), ...a }));
    return sendJson(res, 200, { code: 0, data: { admin, actions } });
  }

  // ---- 反馈管理（后台「反馈管理」Tab：用户 2026-08-17 反馈后台管理不了用户反馈）----
  // GET 全部反馈；DELETE {id} 删除单条；CLEAR 清空
  if (pathname === '/api/admin/feedback' && req.method === 'GET') {
    if (!isAdmin(req)) return sendJson(res, 401, { code: 1, msg: '未登录' });
    const list = loadFeedbacks().map((f) => ({
      id: f.id, content: f.content || '', created_at: f.created_at || 0,
    }));
    return sendJson(res, 200, { code: 0, data: list });
  }
  if (pathname === '/api/admin/feedback/delete' && req.method === 'POST') {
    if (!isAdmin(req)) return sendJson(res, 401, { code: 1, msg: '未登录' });
    const body = await readBody(req);
    const id = String(body.id || '');
    if (!id) return sendJson(res, 400, { code: 1, msg: '缺少反馈 id' });
    const list = loadFeedbacks();
    const next = list.filter((f) => f.id !== id);
    if (next.length === list.length) return sendJson(res, 404, { code: 1, msg: '反馈不存在' });
    saveFeedbacks(next);
    pushAdminLog('feedback_mgmt', `删除反馈 ${id}`);
    return sendJson(res, 200, { code: 0, msg: '已删除' });
  }
  if (pathname === '/api/admin/feedback/clear' && req.method === 'POST') {
    if (!isAdmin(req)) return sendJson(res, 401, { code: 1, msg: '未登录' });
    saveFeedbacks([]);
    pushAdminLog('feedback_mgmt', '清空全部反馈');
    return sendJson(res, 200, { code: 0, msg: '已清空' });
  }

  // ---- 今日密码：查看状态（后台「账号与推广」展示）----
  if (pathname === '/api/admin/daily-password' && req.method === 'GET') {
    if (!isAdmin(req)) return sendJson(res, 401, { code: 1, msg: '未登录' });
    const info = loadDailyPasswords();
    return sendJson(res, 200, { code: 0, data: info || null });
  }
  // ---- 今日密码：手动补跑/重试（后台按钮）----
  // 用户 2026-08-16 强调：成功项绝不重生成（防误触作废已发分享）。
  // 本接口只补跑「今日未生成」或「今日失败」的网盘；已成功的一律跳过。
  if (pathname === '/api/admin/daily-password/run' && req.method === 'POST') {
    if (!isAdmin(req)) return sendJson(res, 401, { code: 1, msg: '未登录' });
    const runResult = await runDailyPasswordJob();
    const info = loadDailyPasswords();
    const failedNow = (runResult.generated || []).filter((g) => !g.ok);
    const okNow = (runResult.generated || []).filter((g) => g.ok);
    const failedTotal = Object.values((info && info.state) || {}).filter((s) => s && s.status === 'error');
    let msg = '';
    if (failedNow.length) msg = `补跑完成，仍有 ${failedNow.length} 个网盘失败（详见下方红色提醒）`;
    else if (okNow.length) msg = `补跑完成，成功 ${okNow.length} 个`;
    else if (runResult.skipped && runResult.skipped.length) msg = '没有需要补跑的网盘（已全部成功，或未启用自动化 / 未配置 Cookie）';
    else msg = '今日密码均已生成成功，无需重新生成';
    return sendJson(res, 200, {
      code: failedNow.length ? 1 : 0,
      msg,
      data: info,
      run: runResult,
      failed_total: failedTotal.length,
      error: failedNow.length ? failedNow.map((f) => `${f.provider}: ${f.error}`).join('；') : undefined,
    });
  }

  return sendJson(res, 404, { code: 1, msg: 'api_not_found' });
}

function quotaView(q) {
  return {
    unlocked: q.unlocked,
    largeCountLeft: q.largeCountLeft,
    smallFileUnlocked: q.smallFileUnlocked,
    smallSizeLeftMB: Math.round(q.smallSizeLeft / MB),
    sizeCapUnlocked: q.sizeCapUnlocked,
    sizeCapGB: q.sizeCapUnlocked ? 0 : siteSettings.sizeCapGB, // 解锁后不限制大小
    // 参考站 契约字段（/api/ip-quota 消费）
    count_limit: siteSettings.largeDailyLimit,
    count_used: Math.max(0, siteSettings.largeDailyLimit - q.largeCountLeft),
    count_left: q.largeCountLeft,
    daily_size_limit_bytes: 0, // 大文件按个数，无字节额度
    daily_size_left_bytes: 0,
    single_size_limit_bytes: q.sizeCapUnlocked ? 0 : LARGE_FILE_SIZE_CAP,
    large_file_size_unlocked: q.sizeCapUnlocked,
    small_file_split_enabled: true, // 参考站 前端 yh() 双轨判断开关
    small_file_parse_enabled: q.smallFileUnlocked,
    small_file_unlocked: q.smallFileUnlocked,
    small_file_max_size_bytes: SMALL_FILE_MAX,
    daily_small_size_limit_bytes: siteSettings.smallDailyLimitMB * MB,
    daily_small_size_left_bytes: Math.max(0, q.smallSizeLeft),
    task_bonus_small_size_bytes: siteSettings.smallRewardMB * MB,
  };
}

// 脱敏 siteSettings：cookies 明文替换成 cookieConfigured 布尔表（绝不回显 Cookie）
function sanitizeSettings(s) {
  const { cookies, pan123Account, ...safe } = s;
  const cookieConfigured = {};
  const cookiePreview = {};
  for (const p of PROVIDERS) {
    const v = (cookies && cookies[p]) || '';
    cookieConfigured[p] = !!(v);
    // 2026-08-20：脱敏预览（前 20 字符 + 长度），让后台能确认「已保存」，不回显完整明文
    cookiePreview[p] = v ? v.slice(0, 20) + '…(' + v.length + '字)' : '';
  }
  // 2026-08-19：账号密码登录字段脱敏——只回显用户名，密码绝不回显
  return {
    ...safe,
    cookieConfigured,
    cookiePreview,
    pan123Account: pan123Account ? { username: pan123Account.username || '', hasPassword: !!(pan123Account.password) } : { username: '', hasPassword: false },
    pan123LoginState,
    pan123TokenState,
    xunleiCaptchaToken: siteSettings.xunleiCaptchaToken ? { hasToken: true } : { hasToken: false },
    xunleiDeviceId: siteSettings.xunleiDeviceId || '',
    // 2026-08-19：123盘 状态面板（token 前缀脱敏）
    pan123Status: {
      accountConfigured: !!(pan123Account && pan123Account.username),
      hasPassword: !!(pan123Account && pan123Account.password),
      tokenConfigured: !!(siteSettings.cookies && extractToken(siteSettings.cookies.pan123 || '')),
      tokenOk: pan123TokenCache.ok,
      tokenPrefix: pan123TokenCache.prefix,
      tokenLen: pan123TokenCache.len,
      tokenError: pan123TokenCache.error,
      checkedAt: pan123TokenCache.checkedAt,
    },
  };
}

// 各网盘「推广口令」默认占位（后台 promo 未配置时回退用，避免墙/任务无口令可复制）
const DEFAULT_PROMO_PASSCODE = {
  quark: '复制口令到夸克网盘获取解析密码',
  baidu: '复制口令到百度网盘获取解析密码',
  xunlei: '复制口令到迅雷网盘获取解析密码',
  pan123: '复制口令到123盘获取解析密码',
  mcloud: '复制口令到移动云盘获取解析密码',
  uc: '复制口令到UC网盘获取解析密码',
};
// 返回某网盘的「推广口令 / 二维码」视图（密码墙展示用；promo 留空 → 回退默认口令，保证前端有内容）
function promoView(provider) {
  const p = siteSettings.promo[provider] || {};
  return {
    provider,
    passcode: p.passcode || DEFAULT_PROMO_PASSCODE[provider] || '复制口令到网盘获取解析密码',
    link: p.link || '',
    qrUrl: p.qrUrl || (p.link ? `/api/qrcode?text=${encodeURIComponent(p.link)}` : ''),
  };
}

// ---------- 静态托管 ----------
const MIME = {
  '.html': 'text/html; charset=utf-8',
  // 注意：ESM 模块对 MIME 严格，不能带 charset 参数（Chrome 拒绝）
  '.js': 'text/javascript',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
};
function serveStatic(req, res, pathname) {
  // 「问题反馈」是前端弹窗伪路由（/feedback 由 index.html 注入脚本拦截打开弹窗）；
  // 直接访问时回退到首页，避免 404
  let rel = pathname === '/' || pathname === '/feedback' ? '/index.html' : pathname;
  const filePath = path.join(PUBLIC_DIR, path.normalize(rel).replace(/^(\.\.[/\\])+/, ''));
  if (!filePath.startsWith(PUBLIC_DIR)) { res.writeHead(403); return res.end('forbidden'); }
  fs.stat(filePath, (statErr, st) => {
    if (statErr || !st.isFile()) { res.writeHead(404); return res.end('not found'); }
    const ext = path.extname(filePath);
    const isHtml = ext === '.html' || filePath.endsWith('index.html');
    // 文件名带内容指纹/日期版本号（如 .0820.js、-AbCd1234.js）→ 永久缓存是安全的：
    // 内容一变，文件名必然跟着变，URL 全新，不存在"改内容不更新"的问题。
    // 其余（admin.js / style.css / index-main.js 等无版本号文件）→ 协商缓存：
    // 靠 ETag 校验，内容变了返回 200 新文件，没变返回 304 用本地缓存 —— 改内容【永远不用改名】。
    const hasVersionFingerprint = /[.-][0-9a-f]{8,}[.]/.test(pathname) || /\.\d{4,}[.]/.test(pathname);
    const cacheHeader = isHtml
      ? 'no-cache, must-revalidate'  // HTML 必须实时
      : hasVersionFingerprint
        ? 'public, max-age=31536000, immutable'  // 带指纹文件名：永久缓存（安全）
        : 'no-cache, must-revalidate';           // 无指纹：每次协商，内容变自动更新
    // ETag（Weak，mtime+size）：无版本号文件的"改内容自动更新"靠它
    const etag = 'W/"' + st.size.toString(16) + '-' + st.mtimeMs.toString(16) + '"';
    if (req.headers['if-none-match'] === etag) {
      res.writeHead(304, {
        'ETag': etag,
        'Cache-Control': cacheHeader,
        'Content-Type': MIME[ext] || 'application/octet-stream',
      });
      return res.end();
    }
    fs.readFile(filePath, (err, buf) => {
      if (err) { res.writeHead(404); return res.end('not found'); }
      const isText = /\.(js|css|html|svg|json|txt|map)$/i.test(ext);
      const acceptGzip = /gzip/i.test(String(req.headers['accept-encoding'] || ''));
      const baseHeaders = {
        'Content-Type': MIME[ext] || 'application/octet-stream',
        'Cache-Control': cacheHeader,
        'ETag': etag,
      };
      // 2026-08-20：文本类静态资源 gzip（1.6MB JS 裸传公网是首屏慢主因，gzip 后 ~1/3）
      if (isText && acceptGzip) {
        zlib.gzip(buf, (gzErr, gz) => {
          if (gzErr || gz.length >= buf.length) {
            res.writeHead(200, baseHeaders);
            return res.end(buf);
          }
          res.writeHead(200, { ...baseHeaders, 'Content-Encoding': 'gzip', 'Vary': 'Accept-Encoding' });
          res.end(gz);
        });
      } else {
        res.writeHead(200, baseHeaders);
        res.end(buf);
      }
    });
  });
}

// ---------- 主服务器 ----------
const server = http.createServer(async (req, res) => {
  attachDevice(req, res);
  res._req = req; // 供 sendJson 做 CORS 白名单判断
  const u = new URL(req.url, 'http://x');
  const pathname = u.pathname;
  // 访客来源埋点：只记页面访问（HTML/SPA fallback），API 调用不记（避免噪音）
  if (req.method === 'GET' && (pathname === '/' || pathname === '/index.html' || pathname === '/feedback')) recordVisitor(req, pathname);
  // 2026-08-19：访问日志（设备指纹去重，供后台总览柱状图）
  // 2026-08-19 调优：只记「用户页面 + 业务 API」，排除后台管理/admin 接口/静态资源/预检
  // （否则后台刷新也计入访问，污染总览统计）
  const isStatic = pathname.startsWith('/assets/') || pathname.startsWith('/admin-vue.js') || pathname.startsWith('/admin.js') || pathname === '/favicon.svg' || pathname.startsWith('/style.css');
  if (!pathname.startsWith('/api/admin/') && !isStatic && req.method !== 'OPTIONS') {
    recordAccess(req.fingerprint);
  }
  // OPTIONS 预检：仅本站/回环来源放行，其余跨域预检直接 403（配合 CORS 白名单）
  if (req.method === 'OPTIONS') {
    const co = corsOrigin(req);
    if (co === false) { res.writeHead(403); return res.end(); }
    const headers = { 'Access-Control-Allow-Headers': 'Content-Type, X-Requested-With', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS' };
    if (co) headers['Access-Control-Allow-Origin'] = co;
    res.writeHead(204, headers);
    return res.end();
  }
  try {
    if (pathname.startsWith('/api/')) {
      await handleApi(req, res, pathname);
    } else if (pathname === ADMIN_PATH || pathname.startsWith(ADMIN_PATH + '/')) {
      // 隐蔽后台（路径仅管理员知道，不暴露在前端任何地方）
      serveStatic(req, res, '/admin.html');
    } else if (pathname === '/admin' || pathname.startsWith('/admin/')) {
      // 前台统一 404，不暴露后台存在（防止从网页界面扒出后台）
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not Found');
    } else {
      serveStatic(req, res, pathname);
    }
  } catch (e) {
    // readBody 拒绝（请求体过大/读取失败）等统一走这里
    if (!res.headersSent) sendJson(res, 400, { code: 1, msg: 'bad_request', error: e.message });
    else res.end();
  }
});

server.listen(PORT, () => {
  console.log(`coolink 运行中：http://localhost:${PORT}`);
  console.log(`demo 解析密码（压缩包四位密码）： ${PARSE_PASSWORD}`);
  console.log(`真实解析支持：夸克(需自己Cookie) / 百度(需自己BDUSS)`);
});
