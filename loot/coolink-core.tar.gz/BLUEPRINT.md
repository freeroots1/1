# Cool Link 完整蓝图（完整构建蓝图 + 底层逻辑）

> 目标：把同类网盘解析站的**构建方式**和**底层数据流**完整映射到我们自己的 demo。
> 证据来源：逆向出的真实源码（index / scanLinkCmd / admin 三套 JS + index.html）。
> 配套分析：`outputs/analysis.md`（原理与变现拆解）。
> 当前实现：本仓库 `coolink/`（已实现夸克/百度真实解析 + 解析免费/下载弹四道墙 + localStorage cookie）。

---

## 〇、一句话架构对照

```
参考站真实架构（逆向）                     coolink 映射
─────────────────────────────────          ─────────────────────────────────
Vue3 + Vite/Rolldown + Naive UI 前端  →  Vue3(global) + 原生 CSS（采用 emerald/slate 主题）
多 chunk 懒加载（admin/scanLinkCmd 独立） → 单 app.js（可后续拆模块）
Node 原生 http 后端（零依赖）          →  Node 原生 http 后端 server.js（已做，零依赖）
多网盘上游节点 + 健康探测             →  夸克/百度直连解析（已做，单节点）
四道墙限额 + 每日任务状态机            →  四道墙在 /api/download（已做核心逻辑）
aria2/Gopeed/Motrix JSON-RPC 推送       →  预留「推 aria2」按钮（前端有，后端待接）
网盘拉新/CPA 变现（密码=压缩包4位码）  →  仅建模为「解析密码墙」演示，不变现
```

---

## 一、构建逻辑（Build Logic）

| 维度 | 参考站真实做法（源码证据） | demo 建议 |
|---|---|---|
| 框架 | Vue 3 Composition API（`<script setup>` 风格，`_plugin-vue_export-helper` 证明） | 已用 Vue3 global build，逻辑一致 |
| 打包器 | **Vite + Rolldown**（`rolldown-runtime` 存在，非传统 Rollup） | demo 用原生 `<script>` 免打包，等价 |
| UI 库 | **Naive UI**（`naive-YwoEZiyN.js` 827KB） | 自写 CSS 还原主题（emerald `#10b981` / slate `#f8fafc` / 12px 圆角 / Inter） |
| 请求 | **axios**，`withCredentials:true`（依赖 Cookie 会话） | demo 用 fetch + 请求体带 cookie |
| 字体/图标 | **Inter** + **iconify-icon** 组件 | 已引 Inter；图标可用 emoji/iconify 平替 |
| 路由 | 前端路由：`/`（首页）、`/admin`（后台）、`/comments`、`/guide` | demo 用单页 + 弹窗（设置/密码/任务页） |
| 分块 | `modulepreload`：index / **admin**（懒） / **scanLinkCmd**（懒） / naive / vendor | 建议把「后台」和「每日任务/节点监控」拆成独立 JS 文件懒加载 |

**关键构建洞察**：参考站把**运营后台（admin）** 和 **扫链/每日任务/节点监控（scanLinkCmd）** 拆成独立 chunk 懒加载——这俩是站点运营方才用到的重逻辑，普通用户首屏不加载。demo 的「后端管理」和「节点监控」也应如此拆分，不进首屏包。

---

## 二、模块划分（按 chunk 拆，完全对照源码文件）

```
参考站源码文件（逆向）              demo 对应模块                   职责
─────────────────────────        ──────────────────────────     ──────────────────
index-Bm9aiG71.js  (197KB)   →    app.js（首页/搜索/解析/解锁/路由）  核心用户侧流程
scanLinkCmd-MWX1xjn1.js (37KB)→   tasks.js（每日任务 + 节点健康 + 各网盘 fetch） 运营/任务侧
admin-DiUcjfu3.js  (9.4KB)   →    admin.js（管理后台面板）           站点运营方
naive-YwoEZiyN.js (827KB)    →    （自写 CSS 替代，无需此文件）
vendor-BsW-i0j2.js (574KB)   →    vendor/vue.global.prod.js（仅 Vue）
rolldown-runtime  (158B)     →    无（免打包无需 runtime）
```

> demo 当前把首页逻辑全塞在 `app.js`（8KB），后续应把**每日任务系统**和**后台**拆出去，呼应对应站的懒加载结构。

---

## 三、后端 API 全景（从真实源码抠出的完整路由）

### 3.1 主程序接口（来自 index-Bm9aiG71.js）
```
/api/search                      多网盘资源搜索（聚合）
/api/search/parse-verify-status  解析前置校验（是否需 unlock）
/api/search/parse-admin-exempt   管理员豁免墙
/api/search/auth/status          查询解锁状态
/api/search/auth/unlock          提交解析密码解锁
/api/search/reveal-links         穿透防盗链 → 返回真实直链 + 提取码
/api/search/check-links          校验直链有效性
/api/search/track-action         埋点（关键词/来源/成败）
/api/encode                      短链/编码辅助
/api/hot-searches                热搜词
/api/qrcode                     生成二维码（扫码获取密码）
/api/scan-status                扫链状态
/api/v1                         版本/通用
```

### 3.2 扫链 / 任务 / 节点 接口（来自 scanLinkCmd-MWX1xjn1.js）
```
# —— 各网盘解析三件套（share→fetch→detail）——
/api/quark/share  /api/quark/fetch  /api/quark/detail  /api/quark/downloader-cookie
/api/baidu/share  /api/baidu/fetch  /api/baidu/detail
/api/mcloud/share /api/mcloud/fetch /api/mcloud/detail      （移动云盘）
/api/pan123/share /api/pan123/fetch /api/pan123/detail      （123盘）
/api/uc/share     /api/uc/fetch     /api/uc/list    /api/uc/detail   （UC网盘）
/api/xunlei/share /api/xunlei/detail /api/xunlei/restore-files    （迅雷）

# —— 每日任务系统 ——
/api/daily-tasks/today         今日任务列表
/api/daily-tasks/claim         领取奖励（task_id）
/api/daily-tasks/complete      完成任务上报
/api/daily-tasks/reveal-answer 答题任务揭晓
/api/admin/daily-tasks        后台任务 CRUD
/api/admin/daily-tasks/logs    任务完成日志
/api/admin/daily-tasks/reorder 任务排序

# —— 其他 ——
/api/parse/verify-password    密码校验（独立入口）
/api/downloader-push-log      下载器推送日志
/api/my-downloads             我的下载记录
/api/ip-quota                 IP 维度限额
```

### 3.3 管理后台接口（来自 admin-DiUcjfu3.js）
```
/api/admin/login  /api/admin/auth-check
/api/admin/overview  /api/admin/trend       运营总览/趋势
/api/admin/settings                   站点设置
/api/admin/logs                       操作日志
/api/admin/user-action-logs           用户行为日志
/api/admin/visitor-source-logs        访客来源日志
/api/admin/browser-bind-logs          浏览器绑定日志
/api/admin/share-link-logs           分享链接日志
/api/admin/downloader-push-logs       下载器推送日志
/api/admin/ip-blacklist              IP 黑名单 CRUD
/api/admin/search/plugins           搜索插件 CRUD + import/export
/api/admin/search/tg-channels       TG 频道源 CRUD + import/export
/api/admin/search/kdocs-docs        金山文档源 import/export
/api/admin/baidu/*                  百度账号维护：check-accounts / login-proxy/test
                                     / mars/link-status / mars/links
                                     / outbound-proxy/test / qr/start / qr/poll / qr/cancel
                                     / auto-maintain/status
/api/admin/pan123/login              123盘登录
/api/parse/scan-guide                扫码引导
/api/public/heartbeat  /api/public/meta   公开心跳/元信息
```

### 3.4 下载器对接（源码关键词证据）
```
aria2  ×21   Gopeed ×28   Motrix ×11   rpc/jsonrpc ×36   secret ×15
→ 标准做法：前端用 JSON-RPC 调本机 aria2/Gopeed 的 rpc 端口 + secret token，
  把 reveal-links 拿到的直链「推送下载」到用户本机客户端。
```

---

## 四、底层核心数据流（Pipeline，最关键）

还原参考站的真实调用顺序：

```
① 搜资源（免费，不拦）
   前端 → GET /api/search?kw=...&res=merged_by_type&src=...&conc=...&ext=...
   后端 → 并发打各网盘上游节点 → 融合去重 → 返回资源列表

② 埋点上报
   前端 → POST /api/search/track-action  {kw, provider, success}

③ 解析前置校验
   前端 → GET /api/search/parse-verify-status?log_id=...
   后端 → 返回 require_unlock / 是否已解锁 / 当前限额

④ 揭示直链（核心穿透）★解析免费，不在这步拦★
   前端 → POST /api/search/reveal-links  {refs, require_unlock}
   后端 → 穿透网盘防盗链 → 返回 {url(真实直链), password(提取码)}

⑤ 解锁墙（仅当用户未解锁时触发）
   前端 → POST /api/search/auth/unlock  {password}
   后端 → 校验解析密码（错误超上限 vc 次锁页面）→ 置 unlocked=true

⑥ 校验直链有效性
   前端 → POST /api/search/check-links

⑦ 下载（★四道墙在这步弹★，对应 demo 的 /api/download）
   - needPassword：未解锁 → 弹密码框
   - blocked[9]：large_locked / small_traffic / size_cap / small_locked → 跳每日任务
   - ok：扣减限额 → 返回直链 → 可复制 / 推 aria2 / 本地下载
```

> **关键设计**：解析（④）是「免费诱饵」，墙只挡在「下载」这一步。demo 的 `server.js` 已按此实现——`/api/parse` 不拦，`/api/download` 才弹四道墙。✅ 与我们之前修的 bug 一致。

---

## 五、四道墙 + 每日任务 状态机（商业核心）

```
第1道墙  解析密码（per-网盘）   GET/POST /api/search/auth/*    未解锁→下载时 needPassword
第2道墙  大文件每日次数          dailyLargeCountLeft            超额→「解析次数已用完，请明天再试」
第3道墙  小文件每日流量          dailySmallSizeLeftBytes        超额→ smallFileLocked
第4道墙  单文件大小上限          sizeCapExceeded                超额→ 需解除单文件大小限制

设备/IP 防刷：device_id 指纹 + ip_daily_count_exceeded + device_daily_count_exceeded

每日任务类型（type 枚举，源码实锤）：
  small_file_all_providers      解锁全平台小文件流量  → 奖励 GB 流量
  small_file_single_provider    解锁指定网盘小文件流量 → 奖励指定流量
  unlock_small_file             解除小文件锁           → 小文件解析权限
  unlock_large_file             解除大文件限制          → 大文件次数
  answer                       答题任务               → 额度
  external_link                 外部链接任务（去网盘保存）→ 额度   ← 变现钩子
  parse-password-qrcode         扫码任务（22次出现，最高频）→ 解析密码/额度
```

**闭环**：完成任务（去网盘保存/答题/扫码）→ claim → 限额 +N → 才能继续解析 → 次日重置 → 又得去保存 → 站点再吃一笔转存佣金。

---

## 六、变现模型（demo 只建模、不变现）

```
站点运营者（网盘推广合伙人）
   └ 把「解析密码」做成压缩包，放自己夸克/移动云盘分享
        └ 用户搜资源（免费看）→ 要解析 → 卡密码墙
             └ 引导去网盘App保存压缩包、解压得4位密码
                  └ 网盘后台判定：有效转存/拉新 → 平台给站点结算佣金
                     （老用户转存 0.3~0.85元/次；新用户拉新 5.5~13元/单；会员分成30%~60%）
                  └ 用户回填密码 → 解锁当日额度 → 次日重置 → 再保存 → 再赚
```

demo 把「4位密码墙」做成纯演示（不接真实网盘分享），仅用于展示**解锁→限额→下载**的闭环逻辑。

---

## 七、coolink 完成度对照表

| 模块 | 状态 | 说明 |
|---|---|---|
| Vue3 前端 + emerald/slate 主题 | ✅ 完成 | style.css + index.html 采用参考站真实 UI |
| 夸克真实解析（免转存直链） | ✅ 完成 | server.js quarkResolve + quarkListAll 递归列目录 |
| 百度真实解析（share→tplconfig→sharedownload） | ✅ 完成 | 返回真实 dlink |
| 解析免费 / 下载弹四道墙 | ✅ 完成 | /api/parse 不拦，/api/download 拦 |
| localStorage cookie 持久化 | ✅ 完成 | 刷新不丢 |
| 每日任务页（前端） | 🟡 部分 | 有页面框架，Reward/claim 逻辑未接后端 |
| 四道墙限额扣减 | 🟡 部分 | download 有 blocked 判定，但无「任务奖励注入限额」闭环 |
| aria2/Gopeed 推送 | 🟡 部分 | 前端有「推 aria2」按钮，后端未实现 JSON-RPC |
| 多网盘（迅雷/123/UC/移动云盘） | ❌ 缺失 | 仅夸克+百度 |
| 节点健康探测 + 多上游择优 | ❌ 缺失 | 单节点直连 |
| 管理后台 /admin | ❌ 缺失 | 无 admin 模块 |
| 埋点 track-action | ❌ 缺失 | 无 |
| 设备指纹 device_id 防刷 | ❌ 缺失 | 无 |
| 热搜/二维码/扫码解锁 | ❌ 缺失 | 无 |

---

## 八、建议下一步实现路线（按优先级）

1. **补「每日任务→限额」闭环**（最高优先）：把 reward 注入 `/api/download` 的限额，让 demo 四道墙真正可「做任务解锁」。
2. **接 aria2 JSON-RPC 推送**：前端「推 aria2」按钮 → 后端用 secret 调 `aria2.addUri`，打通「取链→本机下载」。
3. **拆模块**：把 tasks.js / admin.js 从 app.js 拆出，呼应对应站懒加载结构。
4. **加一个网盘**：优先 123盘 / 移动云盘（接口模式与夸克一致，复制成本最低）。
5. **管理后台最小版**：仅 `/api/admin/settings` + 限额/密码配置，演示运营侧。
6. **节点健康探测**：给每个网盘配 2~3 个上游，前端读 `*-node-http-status-*` 择优。

---

*本蓝图仅做技术架构映射与学习用途，不涉及任何具体资源获取/传播，亦不构成违规指导。*
