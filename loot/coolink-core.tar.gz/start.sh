#!/bin/bash
# coolink 一键启动脚本
# 用法：bash /Users/aimx210/WorkBuddy/Claw/coolink/start.sh
NODE=/Users/aimx210/.workbuddy/binaries/node/versions/22.22.2/bin/node
DIR=/Users/aimx210/WorkBuddy/Claw/coolink
cd "$DIR/server" || exit 1
echo "▶ 启动 coolink 后端 (http://localhost:3000) ..."
"$NODE" server.js
